"""FastAPI server entrypoint for Rateverse — multi-category review platform."""
from dotenv import load_dotenv
from pathlib import Path

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

import os
import logging

from fastapi import FastAPI, APIRouter
from starlette.middleware.cors import CORSMiddleware
from postgres_store import SQLDatabase


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("rateverse")

# ---- PostgreSQL ----
db = SQLDatabase()


# ---- App ----
app = FastAPI(title="Rateverse API")
api_router = APIRouter(prefix="/api")


@api_router.get("/")
async def root():
    return {"message": "Rateverse API", "status": "ok"}


# Register routers
from routes.auth_routes import router as auth_router  # noqa: E402
from routes.categories import router as categories_router  # noqa: E402
from routes.items import router as items_router  # noqa: E402
from routes.reviews import router as reviews_router  # noqa: E402
from routes.admin import router as admin_router  # noqa: E402
from routes.ai import router as ai_router  # noqa: E402
from routes.submissions import router as submissions_router  # noqa: E402
from routes.groups import router as groups_router  # noqa: E402
from routes.blog import router as blog_router  # noqa: E402
from routes.follows import router as follows_router  # noqa: E402
from routes.feed import router as feed_router  # noqa: E402
from routes.uploads import router as uploads_router  # noqa: E402
from routes.notifications import router as notifications_router  # noqa: E402
from routes.cast import router as cast_router  # noqa: E402

api_router.include_router(auth_router)
api_router.include_router(categories_router)
api_router.include_router(items_router)
api_router.include_router(reviews_router)
api_router.include_router(admin_router)
api_router.include_router(ai_router)
api_router.include_router(submissions_router)
api_router.include_router(groups_router)
api_router.include_router(blog_router)
api_router.include_router(follows_router)
api_router.include_router(feed_router)
api_router.include_router(uploads_router)
api_router.include_router(notifications_router)
api_router.include_router(cast_router)

app.include_router(api_router)

# ---- CORS ----
cors_origins_env = os.environ.get("CORS_ORIGINS", "*")
frontend_url = os.environ.get("FRONTEND_URL", "")
if cors_origins_env.strip() == "*" and frontend_url:
    cors_origins = [frontend_url, "http://localhost:3000"]
else:
    cors_origins = [o.strip() for o in cors_origins_env.split(",") if o.strip()]
    if frontend_url and frontend_url not in cors_origins:
        cors_origins.append(frontend_url)

app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins or ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"],
)


@app.on_event("startup")
async def on_startup():
    await db.connect()
    logger.info("Rateverse starting — seeding data if needed...")
    from seed import seed_all
    await seed_all(db)
    logger.info("Seed complete.")
    try:
        from routes.uploads import init_storage
        init_storage()
        logger.info("Object storage initialized.")
    except Exception as e:
        logger.exception("Object storage init failed: %s", e)
    # Backfill: mark all pre-existing seeded users as verified so demo/admin can post
    try:
        await db.users.update_many(
            {"email_verified": {"$exists": False}},
            {"$set": {"email_verified": True, "email_verified_at": None}},
        )
    except Exception as e:
        logger.exception("Backfill email_verified failed: %s", e)
@app.on_event("shutdown")
async def shutdown_db_client():
    await db.close()
