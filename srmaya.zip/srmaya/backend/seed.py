"""Seed sample data: categories, items, reviews, and admin user."""
import os
from datetime import datetime, timezone, timedelta

from auth import hash_password
from models import new_id, now_iso


CATEGORIES = [
    {
        "slug": "entertainment",
        "name": "Entertainment",
        "description": "Movies, TV shows, web series, games & more",
        "icon": "Film",
        "color": "#0055FF",
    },
    {
        "slug": "business",
        "name": "Business",
        "description": "Companies, startups & employers",
        "icon": "Building2",
        "color": "#10B981",
    },
    {
        "slug": "products",
        "name": "Products",
        "description": "Gadgets, cars, electronics & more",
        "icon": "Package",
        "color": "#F59E0B",
    },
    {
        "slug": "services",
        "name": "Services",
        "description": "Restaurants, hotels, hospitals & colleges",
        "icon": "Utensils",
        "color": "#EF4444",
    },
    {
        "slug": "digital",
        "name": "Digital",
        "description": "Apps, websites & SaaS tools",
        "icon": "Smartphone",
        "color": "#8B5CF6",
    },
]

ITEMS = [
    # Entertainment
    {
        "slug": "the-midnight-protocol",
        "name": "The Midnight Protocol",
        "category_slug": "entertainment",
        "description": "A gripping cyberpunk thriller about a rogue AI engineer racing against time to stop a synthetic uprising in neon-lit Tokyo.",
        "image_url": "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=800&q=80",
        "tags": ["thriller", "sci-fi", "cyberpunk"],
        "metadata": {
            "genre": "Sci-Fi Thriller",
            "release_date": "2025-08-14",
            "duration": "2h 18m",
            "director": "Naomi Tanaka",
            "cast": ["Idris Mensah", "Lily Cho", "Amir Reza"],
        },
        "featured": True,
    },
    {
        "slug": "stellar-drift",
        "name": "Stellar Drift",
        "category_slug": "entertainment",
        "description": "A meditative space epic following a colony ship crew unraveling a quiet conspiracy across light-years.",
        "image_url": "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&q=80",
        "tags": ["space", "drama", "mystery"],
        "metadata": {
            "genre": "Space Drama",
            "release_date": "2024-11-02",
            "duration": "Series · 8 episodes",
            "director": "Mira Okafor",
            "cast": ["Jessa Wynn", "Karim Patel", "Theo Lindqvist"],
        },
        "featured": True,
    },
    {
        "slug": "pale-horse-rising",
        "name": "Pale Horse Rising",
        "category_slug": "entertainment",
        "description": "A slow-burn western mystery set on the dust roads of New Mexico in the year 1899.",
        "image_url": "https://images.unsplash.com/photo-1542204165-65bf26472b9b?w=800&q=80",
        "tags": ["western", "mystery"],
        "metadata": {
            "genre": "Western",
            "release_date": "2025-03-21",
            "duration": "2h 04m",
            "director": "Eli Vance",
            "cast": ["Marisol Ortiz", "Ben Hawkins"],
        },
    },
    {
        "slug": "the-glass-quartet",
        "name": "The Glass Quartet",
        "category_slug": "entertainment",
        "description": "Four estranged classical musicians reunite for one final tour through a Europe coming apart at the seams.",
        "image_url": "https://images.unsplash.com/photo-1465847899084-d164df4dedc6?w=800&q=80",
        "tags": ["drama", "music"],
        "metadata": {
            "genre": "Drama",
            "release_date": "2024-06-10",
            "duration": "1h 56m",
        },
    },
    # Business
    {
        "slug": "northwind-labs",
        "name": "Northwind Labs",
        "category_slug": "business",
        "description": "AI infrastructure startup building developer tools for autonomous agent systems. Series B, ~340 employees.",
        "image_url": "https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&q=80",
        "tags": ["ai", "startup", "devtools"],
        "metadata": {
            "industry": "AI Infrastructure",
            "ceo": "Hannah Voss",
            "founded": "2019",
            "employees": "300-500",
            "headquarters": "San Francisco, USA",
            "ratings": {
                "work_culture": 4.6,
                "salary": 4.4,
                "growth": 4.2,
                "management": 4.0,
            },
        },
        "featured": True,
    },
    {
        "slug": "lattice-finance",
        "name": "Lattice Finance",
        "category_slug": "business",
        "description": "European fintech focused on cross-border payments for small and mid-sized businesses.",
        "image_url": "https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=800&q=80",
        "tags": ["fintech", "payments"],
        "metadata": {
            "industry": "Fintech",
            "ceo": "Marco Bianchi",
            "founded": "2017",
            "employees": "1000-2000",
            "headquarters": "Amsterdam, NL",
            "ratings": {
                "work_culture": 3.9,
                "salary": 4.1,
                "growth": 3.6,
                "management": 3.3,
            },
        },
    },
    {
        "slug": "kestrel-foods",
        "name": "Kestrel Foods",
        "category_slug": "business",
        "description": "Plant-based food brand with strong sustainability focus and a global retail footprint.",
        "image_url": "https://images.unsplash.com/photo-1542838132-92c53300491e?w=800&q=80",
        "tags": ["food", "sustainability"],
        "metadata": {
            "industry": "Consumer Goods",
            "ceo": "Aisha Bello",
            "founded": "2014",
            "employees": "2000+",
            "headquarters": "London, UK",
            "ratings": {
                "work_culture": 4.0,
                "salary": 3.5,
                "growth": 3.8,
                "management": 3.7,
            },
        },
    },
    {
        "slug": "verdant-mobility",
        "name": "Verdant Mobility",
        "category_slug": "business",
        "description": "Electric vehicle and charging-network company focused on commercial fleets.",
        "image_url": "https://images.unsplash.com/photo-1571987502227-9231b837d92a?w=800&q=80",
        "tags": ["ev", "automotive"],
        "metadata": {
            "industry": "Electric Vehicles",
            "ceo": "Jonas Eriksson",
            "founded": "2016",
            "employees": "5000+",
            "headquarters": "Stockholm, SE",
            "ratings": {
                "work_culture": 3.6,
                "salary": 4.2,
                "growth": 4.5,
                "management": 3.4,
            },
        },
    },
    # Products
    {
        "slug": "aura-x-headphones",
        "name": "Aura X Wireless Headphones",
        "category_slug": "products",
        "description": "Flagship wireless headphones with adaptive noise cancellation and 60-hour battery life.",
        "image_url": "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80",
        "tags": ["audio", "headphones", "wireless"],
        "metadata": {
            "brand": "Aura",
            "price": "$349",
            "release_date": "2025-04-01",
            "specs": {
                "battery": "60 hours",
                "weight": "248g",
                "connectivity": "Bluetooth 5.4",
            },
        },
        "featured": True,
    },
    {
        "slug": "horizon-ev-2",
        "name": "Horizon EV2",
        "category_slug": "products",
        "description": "Mid-size electric SUV with a 410-mile range and Level 3 driving assistance.",
        "image_url": "https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=800&q=80",
        "tags": ["car", "ev", "suv"],
        "metadata": {
            "brand": "Horizon Motors",
            "price": "$54,900",
            "release_date": "2025-01-15",
            "specs": {
                "range": "410 mi",
                "0-60": "4.2s",
                "seats": "5",
            },
        },
    },
    {
        "slug": "lumen-13-laptop",
        "name": "Lumen 13 Pro Laptop",
        "category_slug": "products",
        "description": "Ultraportable 13-inch laptop with custom ARM chip and a stunning OLED display.",
        "image_url": "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800&q=80",
        "tags": ["laptop", "computer"],
        "metadata": {
            "brand": "Lumen",
            "price": "$1,499",
            "release_date": "2024-09-22",
            "specs": {"display": "13.3\" OLED", "ram": "16GB", "battery": "22 hrs"},
        },
    },
    {
        "slug": "kettle-stove-original",
        "name": "Kettle Stove Original",
        "category_slug": "products",
        "description": "Compact induction cooktop designed for tiny kitchens and serious cooks.",
        "image_url": "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800&q=80",
        "tags": ["kitchen", "appliance"],
        "metadata": {
            "brand": "Kettle",
            "price": "$129",
            "release_date": "2024-02-12",
        },
    },
    # Services
    {
        "slug": "tartine-and-toast",
        "name": "Tartine & Toast",
        "category_slug": "services",
        "description": "Neighborhood bistro serving slow-fermented breads and seasonal small plates in Brooklyn, NY.",
        "image_url": "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80",
        "tags": ["restaurant", "bistro", "brunch"],
        "metadata": {
            "type": "Restaurant",
            "city": "Brooklyn, NY",
            "cuisine": "French · Bakery",
            "price_range": "$$",
            "hours": "8am – 10pm",
        },
        "featured": True,
    },
    {
        "slug": "ember-spa-resort",
        "name": "Ember Spa & Resort",
        "category_slug": "services",
        "description": "Mountain wellness retreat with thermal baths, treehouse cabins, and a 14-course tasting menu.",
        "image_url": "https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800&q=80",
        "tags": ["hotel", "spa", "resort"],
        "metadata": {
            "type": "Hotel",
            "city": "Banff, Canada",
            "stars": "5",
            "price_range": "$$$$",
        },
    },
    {
        "slug": "north-ridge-medical",
        "name": "North Ridge Medical Center",
        "category_slug": "services",
        "description": "Multi-specialty private hospital known for cardiology and oncology programs.",
        "image_url": "https://images.unsplash.com/photo-1538108149393-fbbd81895907?w=800&q=80",
        "tags": ["hospital", "healthcare"],
        "metadata": {
            "type": "Hospital",
            "city": "Denver, CO",
            "specialties": "Cardiology, Oncology, Orthopedics",
        },
    },
    {
        "slug": "westbrook-college",
        "name": "Westbrook College of Engineering",
        "category_slug": "services",
        "description": "Mid-sized private engineering college with strong robotics and AI research programs.",
        "image_url": "https://images.unsplash.com/photo-1562774053-701939374585?w=800&q=80",
        "tags": ["college", "education"],
        "metadata": {
            "type": "College",
            "city": "Boston, MA",
            "tuition": "$48,000/yr",
            "ranking": "#42 nationally",
        },
    },
    # Digital
    {
        "slug": "notebox-app",
        "name": "Notebox",
        "category_slug": "digital",
        "description": "Cross-platform note app with end-to-end encryption and a powerful daily journal mode.",
        "image_url": "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=800&q=80",
        "tags": ["productivity", "notes", "app"],
        "metadata": {
            "platform": "iOS, Android, Web",
            "developer": "Notebox Inc.",
            "pricing": "Free / $4.99 mo",
        },
        "featured": True,
    },
    {
        "slug": "loop-fitness",
        "name": "Loop Fitness",
        "category_slug": "digital",
        "description": "Fitness app that turns your training routine into a multiplayer game with friends.",
        "image_url": "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800&q=80",
        "tags": ["fitness", "app"],
        "metadata": {
            "platform": "iOS, Android",
            "developer": "Loop Labs",
            "pricing": "Free / $9.99 mo",
        },
    },
    {
        "slug": "harbor-cms",
        "name": "Harbor CMS",
        "category_slug": "digital",
        "description": "Headless CMS built for agencies. Visual editor, role-based workflows, on-prem option.",
        "image_url": "https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=800&q=80",
        "tags": ["saas", "cms", "developer"],
        "metadata": {
            "platform": "Web · SaaS",
            "developer": "Harbor Tech",
            "pricing": "$29 / user / mo",
        },
    },
    {
        "slug": "claro-budget",
        "name": "Claro Budget",
        "category_slug": "digital",
        "description": "Personal finance app focused on cash-flow forecasting and shared family budgets.",
        "image_url": "https://images.unsplash.com/photo-1554224154-22dec7ec8818?w=800&q=80",
        "tags": ["finance", "app"],
        "metadata": {
            "platform": "iOS, Android, Web",
            "developer": "Claro Studio",
            "pricing": "$5.99 mo",
        },
    },
]


# Sample reviewers (no real password — created via auth.hash_password fallback to a default)
SAMPLE_USERS = [
    {"email": "ava.matthews@demo.com", "name": "Ava Matthews", "avatar_url": "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=160&q=80"},
    {"email": "noah.bennett@demo.com", "name": "Noah Bennett", "avatar_url": "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=160&q=80"},
    {"email": "lara.kim@demo.com", "name": "Lara Kim", "avatar_url": "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=160&q=80"},
    {"email": "samir.adwani@demo.com", "name": "Samir Adwani", "avatar_url": "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=160&q=80"},
    {"email": "emma.dubois@demo.com", "name": "Emma Dubois", "avatar_url": "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160&q=80"},
    {"email": "kenji.tanaka@demo.com", "name": "Kenji Tanaka", "avatar_url": "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=160&q=80"},
]


# Reviews per item slug
REVIEWS = {
    "the-midnight-protocol": [
        (5, "A near-perfect cyberpunk thriller", "Visually stunning, tightly written, and the score is phenomenal. The pacing in the third act is razor-sharp.", ["Atmosphere", "Soundtrack", "Lead performance"], ["Some side characters under-served"]),
        (4, "Style over substance, but what style", "The world-building is so dense it hides a thin plot, but I didn't mind because every frame is gorgeous.", ["Cinematography", "Production design"], ["Plot holes"]),
        (5, "Best sci-fi of the year", "Genuine ideas, real tension, no wasted scenes. Watch it on the largest screen you can find.", ["Tight script", "Practical effects"], []),
        (3, "Loud and exhausting", "Beautiful but emotionally cold. The action scenes blur together by the end.", ["Visuals"], ["Emotionally distant", "Too long"]),
    ],
    "stellar-drift": [
        (5, "Slow burn, huge payoff", "Patience is rewarded — the final two episodes recontextualize everything you thought you knew.", ["Writing", "World-building"], ["Slow start"]),
        (4, "Quietly brilliant", "Not for everyone but I loved every meditative minute.", ["Atmosphere", "Performances"], ["Some episodes drag"]),
        (4, "Intelligent space drama", "Reminded me of the best of 70s sci-fi. Wish there was more episodes.", ["Mature writing"], []),
    ],
    "pale-horse-rising": [
        (4, "Patient and gorgeous", "A western that earns every minute of its runtime. The ending stuck with me for days.", ["Cinematography", "Score"], ["Pacing"]),
        (3, "Good, not great", "Looks beautiful but doesn't really say anything new.", ["Visuals"], ["Predictable plot"]),
    ],
    "the-glass-quartet": [
        (5, "Heartbreaking and beautifully acted", "Everyone in the ensemble is at the top of their game.", ["Performances", "Music"], []),
        (4, "Quietly devastating", "Final scene levelled me. Recommended.", ["Writing"], ["Slightly slow"]),
    ],
    "northwind-labs": [
        (5, "Best engineering culture I have worked in", "Smart people, real ownership, no politics. Compensation is well above market.", ["Compensation", "Culture", "Leadership"], ["Long hours during launches"]),
        (4, "Mostly great, some growing pains", "Engineering is amazing but operations and HR still feel like a 20-person startup.", ["Engineering culture"], ["Process maturity"]),
        (3, "Not for everyone", "If you don't thrive in ambiguity, this place will eat you alive.", [], ["Burnout risk", "Unclear roadmap"]),
    ],
    "lattice-finance": [
        (3, "Solid product, average culture", "Good benefits but management is hit or miss. Career growth feels slow.", ["Benefits"], ["Slow promotions"]),
        (4, "Great place to start your career", "Lots of training, supportive teammates, smart product.", ["Onboarding", "Mentorship"], ["Comp lags"]),
    ],
    "kestrel-foods": [
        (4, "Mission-driven and friendly", "Truly cares about sustainability — the work feels meaningful day to day.", ["Mission", "People"], ["Pay below market"]),
    ],
    "verdant-mobility": [
        (4, "Fast-moving and exciting", "Lots of opportunity to own large pieces of work.", ["Growth"], ["Chaotic"]),
        (3, "Promising but messy", "Good product, painful internal tools.", [], ["Tooling"]),
    ],
    "aura-x-headphones": [
        (5, "Beats my old Sony 1000XM5", "Noise cancellation is best-in-class and the comfort is incredible for long flights.", ["ANC", "Comfort", "Battery life"], ["Premium price"]),
        (4, "Excellent but pricey", "Sound is fantastic. App could use work.", ["Sound quality"], ["Companion app"]),
        (5, "Set and forget", "Battery actually delivers 60 hours. Game-changer for travel.", ["Battery"], []),
    ],
    "horizon-ev-2": [
        (4, "Range claims hold up", "Daily-drove 380 highway miles in cold weather. Software is rough on launch.", ["Range", "Comfort"], ["Software bugs"]),
        (3, "Beautiful but buggy", "The UI hangs occasionally and the auto-park is overconfident.", ["Design"], ["Software", "Service network"]),
    ],
    "lumen-13-laptop": [
        (5, "Replaces my 16-inch heavy machine", "Battery life and OLED are stunning. Compiles run shockingly fast for 13 inches.", ["Battery", "Display", "Performance"], []),
        (4, "Great laptop, mediocre keyboard", "Everything is fantastic except the shallow keyboard travel.", ["Display", "Build"], ["Keyboard"]),
    ],
    "kettle-stove-original": [
        (4, "Tiny, mighty, useful", "Lives on my counter. Heats faster than my old gas range.", ["Speed", "Compact"], ["Loud fan"]),
    ],
    "tartine-and-toast": [
        (5, "Bread alone is worth the trip", "The naturally leavened country loaf is genuinely top 5 in NYC.", ["Bread", "Service"], ["Long wait"]),
        (4, "Charming but cramped", "Wonderful food, tight room. Worth a brunch reservation.", ["Food"], ["Seating"]),
    ],
    "ember-spa-resort": [
        (5, "Bucket-list weekend", "Treehouse cabins are stunning and the thermal baths are otherworldly.", ["Setting", "Service", "Spa"], ["Expensive"]),
        (4, "Beautiful but pricey", "Genuine wellness escape. Save up for it.", ["Atmosphere"], ["Cost"]),
    ],
    "north-ridge-medical": [
        (4, "Top notch cardiology team", "Caring staff and very modern facilities. Insurance billing was confusing.", ["Doctors", "Facilities"], ["Billing"]),
    ],
    "westbrook-college": [
        (4, "Strong robotics program", "Hands-on projects from year one and excellent industry connections.", ["Faculty", "Labs"], ["Tuition"]),
        (3, "Great academics, poor housing", "On-campus housing is rough, food options limited.", ["Academics"], ["Housing"]),
    ],
    "notebox-app": [
        (5, "Finally a notes app I trust", "End-to-end encryption that just works. The journal mode is daily essential.", ["Encryption", "UX"], []),
        (4, "Almost perfect", "Sync is fast, search is excellent. Wish exports were better.", ["Performance"], ["Export options"]),
    ],
    "loop-fitness": [
        (4, "Workouts feel like a game", "My friends and I actually compete now. Fun, but the social pressure can be a lot.", ["Gamification"], ["Social pressure"]),
    ],
    "harbor-cms": [
        (5, "Saved our agency 40 hours a week", "Visual editor + role-based workflows mean clients can self-serve safely.", ["Workflows", "Performance"], ["Pricey for solo"]),
        (4, "Best headless CMS we've tried", "Migration was painful but worth it.", ["Flexibility"], ["Migration"]),
    ],
    "claro-budget": [
        (4, "Cash-flow forecasting is the killer feature", "First budgeting app that helped me actually plan ahead.", ["Forecasting", "Family budgets"], ["No desktop yet"]),
    ],
}


async def seed_all(db):
    # Categories
    for cat in CATEGORIES:
        await db.categories.update_one(
            {"slug": cat["slug"]},
            {"$setOnInsert": {**cat, "id": new_id(), "item_count": 0}},
            upsert=True,
        )

    # Admin user
    admin_email = os.environ.get("ADMIN_EMAIL", "admin@rateverse.com")
    admin = await db.users.find_one({"email": admin_email})
    admin_password = os.environ.get("ADMIN_PASSWORD")
    if not admin and admin_password:
        await db.users.insert_one({
            "id": new_id(),
            "email": admin_email,
            "name": "Site Admin",
            "password_hash": hash_password(admin_password),
            "role": "admin",
            "avatar_url": "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=160&q=80",
            "bio": "Platform administrator",
            "created_at": now_iso(),
        })

    # Sample users
    user_ids = {}
    for u in SAMPLE_USERS:
        existing = await db.users.find_one({"email": u["email"]})
        if existing:
            user_ids[u["email"]] = existing["id"]
            continue
        uid = new_id()
        await db.users.insert_one({
            "id": uid,
            "email": u["email"],
            "name": u["name"],
            "password_hash": hash_password("Demo@12345"),
            "role": "user",
            "avatar_url": u["avatar_url"],
            "bio": None,
            "created_at": now_iso(),
        })
        user_ids[u["email"]] = uid

    # Items
    cat_lookup = {c["slug"]: c["name"] for c in CATEGORIES}
    for it in ITEMS:
        existing = await db.items.find_one({"slug": it["slug"]})
        if existing:
            continue
        doc = {
            "id": new_id(),
            "slug": it["slug"],
            "name": it["name"],
            "description": it["description"],
            "category_slug": it["category_slug"],
            "category_name": cat_lookup.get(it["category_slug"], it["category_slug"]),
            "image_url": it.get("image_url"),
            "metadata": it.get("metadata", {}),
            "tags": it.get("tags", []),
            "avg_rating": 0.0,
            "review_count": 0,
            "rating_breakdown": {"1": 0, "2": 0, "3": 0, "4": 0, "5": 0},
            "trending_score": 0.0,
            "featured": it.get("featured", False),
            "created_at": now_iso(),
        }
        await db.items.insert_one(doc.copy())

    # Reviews
    user_emails = list(user_ids.keys())
    user_email_idx = 0
    for slug, reviews in REVIEWS.items():
        item = await db.items.find_one({"slug": slug}, {"_id": 0})
        if not item:
            continue
        # Skip if reviews exist
        existing_count = await db.reviews.count_documents({"item_id": item["id"]})
        if existing_count > 0:
            continue

        for idx, (rating, title, body, pros, cons) in enumerate(reviews):
            user_email = user_emails[user_email_idx % len(user_emails)]
            user_email_idx += 1
            user_doc = await db.users.find_one({"email": user_email}, {"_id": 0})

            created = (datetime.now(timezone.utc) - timedelta(days=idx * 3 + 1)).isoformat()
            review_doc = {
                "id": new_id(),
                "item_id": item["id"],
                "item_slug": item["slug"],
                "item_name": item["name"],
                "user_id": user_doc["id"],
                "user_name": user_doc["name"],
                "user_avatar": user_doc.get("avatar_url"),
                "rating": rating,
                "title": title,
                "body": body,
                "pros": pros,
                "cons": cons,
                "helpful_count": (5 - idx) * 2 if idx < 5 else 0,
                "helpful_user_ids": [],
                "reported": False,
                "verified": idx == 0,
                "created_at": created,
            }
            await db.reviews.insert_one(review_doc.copy())

        # Recompute item stats
        from routes.reviews import _recompute_item_stats
        await _recompute_item_stats(db, item["id"])

    # Seed feed posts so the social feed isn't empty
    existing_post = await db.feed_posts.find_one({}, {"_id": 0, "id": 1})
    if not existing_post:
        feed_seed_authors = ["ava.matthews@demo.com", "noah.bennett@demo.com", "lara.kim@demo.com", "samir.adwani@demo.com", "emma.dubois@demo.com", "kenji.tanaka@demo.com"]
        feed_seed_bodies = [
            ("Just watched Echoes of Saturn — easily my favorite sci-fi of the year. The third act lands a punch I didn't see coming.  #SciFi #Movies", None),
            ("Hot take: most 'remote-first' companies still run on synchronous expectations. Genuinely async culture is rare and worth searching for. #RemoteWork #Careers", None),
            ("Tested the new Aura X headphones for a week. Active noise cancellation is so good I forgot to take them off on a flight. Battery genuinely lasted 60+ hours. #Gadgets", "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=900&q=80"),
            ("Hidden gem in Brooklyn: Tartine & Toast. The naturally-leavened country loaf is genuinely top 5 in NYC. Worth the brunch wait. #Food #NYC", "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=900&q=80"),
            ("Notebox just shipped a new journal mode and I think it has overtaken Bear as my daily writing app. End-to-end encryption + clean UX. #ProductivityTools", None),
            ("Spent the weekend at Ember Spa in Banff. If you're burned out — and not just lightly tired — this is the kind of place that resets you. Treehouse cabins, thermal baths, and a 14-course tasting menu. #Travel", "https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=900&q=80"),
        ]
        import re as _re
        for i, (body, image) in enumerate(feed_seed_bodies):
            email = feed_seed_authors[i % len(feed_seed_authors)]
            udoc = await db.users.find_one({"email": email}, {"_id": 0})
            if not udoc:
                continue
            hashtags = list({h.lower() for h in _re.findall(r"#([A-Za-z0-9_]+)", body)})
            await db.feed_posts.insert_one({
                "id": new_id(),
                "user_id": udoc["id"],
                "user_name": udoc["name"],
                "user_avatar": udoc.get("avatar_url"),
                "body": body,
                "image_url": image,
                "link_url": None,
                "hashtags": hashtags,
                "mentions": [],
                "likes_count": (4 - i) if i < 4 else 0,
                "liked_user_ids": [],
                "comments_count": 0,
                "saved_user_ids": [],
                "repost_count": 0,
                "repost_of": None,
                "created_at": (datetime.now(timezone.utc) - timedelta(hours=i * 6 + 1)).isoformat(),
            })

        # Seed a few follow relationships so the "Following" tab has something for sample users
        emails_pairs = [
            ("ava.matthews@demo.com", ["noah.bennett@demo.com", "lara.kim@demo.com"]),
            ("noah.bennett@demo.com", ["ava.matthews@demo.com", "emma.dubois@demo.com"]),
            ("lara.kim@demo.com", ["samir.adwani@demo.com"]),
        ]
        for follower_email, targets in emails_pairs:
            fdoc = await db.users.find_one({"email": follower_email}, {"_id": 0})
            if not fdoc:
                continue
            for t_email in targets:
                tdoc = await db.users.find_one({"email": t_email}, {"_id": 0})
                if not tdoc:
                    continue
                existing_follow = await db.follows.find_one(
                    {"follower_id": fdoc["id"], "following_id": tdoc["id"]}, {"_id": 0, "id": 1}
                )
                if existing_follow:
                    continue
                await db.follows.insert_one({
                    "id": new_id(),
                    "follower_id": fdoc["id"],
                    "following_id": tdoc["id"],
                    "created_at": now_iso(),
                })

    seed_owner_email = SAMPLE_USERS[0]["email"]
    admin_doc_for_blog = await db.users.find_one({"email": admin_email}, {"_id": 0})
    if not admin_doc_for_blog:
        admin_doc_for_blog = await db.users.find_one({"email": seed_owner_email}, {"_id": 0})

    # Seed blog posts (editorial)
    blog_seeds = [
        {
            "slug": "how-to-spot-an-honest-review",
            "title": "How to spot an honest review in 30 seconds",
            "excerpt": "Three quick signals separate genuine reviews from astroturf and rage-bait. We break them down.",
            "tag": "Guides",
            "cover_url": "https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=1600&q=80",
            "body": "Reading reviews is now a skill. With so many incentives to gamify ratings, the signal-to-noise ratio is getting worse. Here are the three things our editorial team checks every time:\n\n1. **Specificity over superlatives.** Genuine reviews mention concrete details — a room number, a manager's name, a build date. Fake ones lean on adjectives.\n\n2. **A mix of pros AND cons.** Even loved products have shortcomings. Reviews with only glowing language deserve skepticism.\n\n3. **A pattern across reviewers.** One outlier means little. Three independent reviewers calling out the same flaw is a red flag worth weight.\n\nWhen you're reviewing on Rateverse yourself, lean into specificity. The community rewards it.",
        },
        {
            "slug": "rateverse-launch-notes-feb-2026",
            "title": "Launch notes — community + IMDb-style entertainment hub",
            "excerpt": "We shipped a community layer, IMDb-style entertainment detail pages, and YouTube/X/Facebook embedded trailers.",
            "tag": "Product",
            "cover_url": "https://images.unsplash.com/photo-1499209974431-9dddcece7f88?w=1600&q=80",
            "body": "This week we shipped three changes worth flagging:\n\n**Groups.** Anyone can spin up a community around a topic — sci-fi obsessives, remote-work skeptics, indie app makers. Members post discussions and recommend listings.\n\n**Entertainment is now IMDb-style.** Year inline with the title, cast cards with photos, embedded trailers from YouTube / X / Facebook — all directly on the listing.\n\n**Submit Post got smarter.** Auto-slug, dynamic per-category dropdowns, captcha, and an auto-saved draft. Five fewer abandoned submissions a day already.\n\nMore soon — including a Compare tool and per-user contributor badges.",
        },
    ]
    for b in blog_seeds:
        existing = await db.blog_posts.find_one({"slug": b["slug"]}, {"_id": 0})
        if existing:
            continue
        await db.blog_posts.insert_one({
            "id": new_id(),
            "slug": b["slug"],
            "title": b["title"],
            "excerpt": b["excerpt"],
            "body": b["body"],
            "cover_url": b["cover_url"],
            "tag": b["tag"],
            "author_id": admin_doc_for_blog["id"],
            "author_name": admin_doc_for_blog["name"],
            "author_avatar": admin_doc_for_blog.get("avatar_url"),
            "published": True,
            "views": 0,
            "likes_count": 0,
            "liked_user_ids": [],
            "created_at": now_iso(),
            "updated_at": now_iso(),
        })

    # Seed groups (3 starter communities)
    sample_groups = [
        {
            "slug": "sci-fi-storytellers",
            "name": "Sci-Fi Storytellers",
            "description": "Lovers of cerebral sci-fi — books to series. We post weekly picks and theory-spirals.",
            "cover_url": "https://images.unsplash.com/photo-1517976547714-720226b864c1?w=1200&q=80",
            "category_slug": "entertainment",
        },
        {
            "slug": "remote-work-real-talk",
            "name": "Remote Work Real Talk",
            "description": "Honest reviews and conversations about remote-first companies, hybrid pain, and async tooling.",
            "cover_url": "https://images.unsplash.com/photo-1521737711867-e3b97375f902?w=1200&q=80",
            "category_slug": "business",
        },
        {
            "slug": "indie-app-makers",
            "name": "Indie App Makers",
            "description": "A community for makers shipping small, mighty digital products. Share launches, get honest feedback.",
            "cover_url": "https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?w=1200&q=80",
            "category_slug": "digital",
        },
    ]

    admin_doc = await db.users.find_one({"email": admin_email}, {"_id": 0})
    if not admin_doc:
        admin_doc = await db.users.find_one({"email": seed_owner_email}, {"_id": 0})
    sample_email_to_id = {e: uid for e, uid in user_ids.items()}

    for g in sample_groups:
        existing = await db.groups.find_one({"slug": g["slug"]}, {"_id": 0})
        if existing:
            continue
        gid = new_id()
        await db.groups.insert_one({
            "id": gid,
            "slug": g["slug"],
            "name": g["name"],
            "description": g["description"],
            "cover_url": g["cover_url"],
            "category_slug": g.get("category_slug"),
            "creator_id": admin_doc["id"],
            "creator_name": admin_doc["name"],
            "member_count": 0,
            "post_count": 0,
            "created_at": now_iso(),
        })

        # Creator membership
        await db.group_memberships.insert_one({
            "id": new_id(),
            "group_id": gid,
            "user_id": admin_doc["id"],
            "user_name": admin_doc["name"],
            "user_avatar": admin_doc.get("avatar_url"),
            "role": "creator",
            "joined_at": now_iso(),
        })

        # Join 3-4 sample users
        for email in list(sample_email_to_id.keys())[:4]:
            if email == seed_owner_email:
                continue
            udoc = await db.users.find_one({"email": email}, {"_id": 0})
            await db.group_memberships.insert_one({
                "id": new_id(),
                "group_id": gid,
                "user_id": udoc["id"],
                "user_name": udoc["name"],
                "user_avatar": udoc.get("avatar_url"),
                "role": "member",
                "joined_at": now_iso(),
            })

        # Seed two posts
        posts = []
        if g["slug"] == "sci-fi-storytellers":
            posts = [
                {"type": "recommendation", "title": "Watched ‘The Midnight Protocol’ last night — phenomenal", "body": "Tight pacing, gorgeous Tokyo cyberpunk visuals. If you liked Blade Runner 2049, drop everything.", "item_slug": "the-midnight-protocol"},
                {"type": "discussion", "title": "Best sci-fi endings of the decade so far?", "body": "Trying to compile a list. My top three: Stellar Drift S1 finale, The Glass Quartet (yes I count it), and Annihilation. What would you add?"},
            ]
        elif g["slug"] == "remote-work-real-talk":
            posts = [
                {"type": "recommendation", "title": "Northwind Labs really is the real deal", "body": "Six months in. The async ownership culture they brag about isn't bullshit — surprising for an AI infra startup.", "item_slug": "northwind-labs"},
                {"type": "discussion", "title": "Hybrid 3 days in-office: actually working anywhere?", "body": "Curious what companies are doing 3-2 well. Lattice Finance gets close. Everywhere else feels like RTO theatre."},
            ]
        elif g["slug"] == "indie-app-makers":
            posts = [
                {"type": "recommendation", "title": "Notebox is genuinely my favorite indie launch this year", "body": "End-to-end encryption that 'just works' is rare. Worth a look if you write daily.", "item_slug": "notebox-app"},
                {"type": "discussion", "title": "What's your single best tool for pre-launch marketing?", "body": "Drop one tool that punched above its weight before launch. I'll start: ConvertKit for newsletter pre-signup."},
            ]

        author_emails = list(sample_email_to_id.keys())
        for i, p in enumerate(posts):
            uemail = author_emails[i % len(author_emails)]
            udoc = await db.users.find_one({"email": uemail}, {"_id": 0})
            doc = {
                "id": new_id(),
                "group_id": gid,
                "user_id": udoc["id"],
                "user_name": udoc["name"],
                "user_avatar": udoc.get("avatar_url"),
                "type": p["type"],
                "title": p["title"],
                "body": p["body"],
                "item_slug": None,
                "item_name": None,
                "item_image": None,
                "item_rating": None,
                "likes_count": (3 - i),
                "liked_user_ids": [],
                "created_at": now_iso(),
            }
            if p["type"] == "recommendation" and p.get("item_slug"):
                item = await db.items.find_one({"slug": p["item_slug"]}, {"_id": 0})
                if item:
                    doc["item_slug"] = item["slug"]
                    doc["item_name"] = item["name"]
                    doc["item_image"] = item.get("image_url")
                    doc["item_rating"] = item.get("avg_rating", 0)
            await db.group_posts.insert_one(doc)

        # Recalc counts
        members = await db.group_memberships.count_documents({"group_id": gid})
        post_count = await db.group_posts.count_documents({"group_id": gid})
        await db.groups.update_one({"id": gid}, {"$set": {"member_count": members, "post_count": post_count}})
