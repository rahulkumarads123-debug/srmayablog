"""Pydantic models."""
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any
import uuid

from pydantic import BaseModel, Field, EmailStr, ConfigDict


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_id() -> str:
    return str(uuid.uuid4())


# ---------- AUTH ----------
class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=6, max_length=100)
    name: str = Field(min_length=1, max_length=80)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class UserPublic(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    email: str
    name: str
    role: str = "user"
    avatar_url: Optional[str] = None
    bio: Optional[str] = None
    email_verified: bool = False
    email_verified_at: Optional[str] = None
    created_at: str


# ---------- CATEGORY ----------
class Category(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=new_id)
    slug: str
    name: str
    description: str
    icon: str
    color: str
    item_count: int = 0


# ---------- ITEM ----------
class ItemCreate(BaseModel):
    name: str
    slug: str
    description: str
    category_slug: str
    image_url: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    tags: List[str] = Field(default_factory=list)
    featured: bool = False


class Item(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=new_id)
    slug: str
    name: str
    description: str
    category_slug: str
    category_name: str
    image_url: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    tags: List[str] = Field(default_factory=list)
    avg_rating: float = 0.0
    review_count: int = 0
    rating_breakdown: Dict[str, int] = Field(
        default_factory=lambda: {"1": 0, "2": 0, "3": 0, "4": 0, "5": 0}
    )
    trending_score: float = 0.0
    featured: bool = False
    created_at: str = Field(default_factory=now_iso)


# ---------- REVIEW ----------
class ReviewCreate(BaseModel):
    rating: int = Field(ge=1, le=5)
    title: str = Field(min_length=2, max_length=120)
    body: str = Field(min_length=10, max_length=4000)
    pros: List[str] = Field(default_factory=list)
    cons: List[str] = Field(default_factory=list)


class Review(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=new_id)
    item_id: str
    item_slug: str
    item_name: str
    user_id: str
    user_name: str
    user_avatar: Optional[str] = None
    rating: int
    title: str
    body: str
    pros: List[str] = Field(default_factory=list)
    cons: List[str] = Field(default_factory=list)
    helpful_count: int = 0
    helpful_user_ids: List[str] = Field(default_factory=list)
    reported: bool = False
    verified: bool = False
    created_at: str = Field(default_factory=now_iso)


# ---------- ADMIN ----------
class UserUpdate(BaseModel):
    role: Optional[str] = None
    name: Optional[str] = None
    bio: Optional[str] = None


class CategoryCreate(BaseModel):
    slug: str
    name: str
    description: str
    icon: str
    color: str
