"""Tests for image uploads + PATCH /auth/me (avatar_url)."""
import io
import os
import struct
import zlib
import random
import requests
import pytest

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://rateverse-1.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"

DEMO_EMAIL = os.environ.get("TEST_DEMO_EMAIL", "ava.matthews@demo.com")
DEMO_PASSWORD = os.environ.get("TEST_DEMO_PASSWORD", "Demo@12345")


def _tiny_png() -> bytes:
    """Minimal valid 1x1 PNG."""
    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = b"IHDR" + struct.pack(">IIBBBBB", 1, 1, 8, 2, 0, 0, 0)
    ihdr_chunk = struct.pack(">I", 13) + ihdr + struct.pack(">I", zlib.crc32(ihdr) & 0xffffffff)
    raw = b"\x00\xff\x00\x00"  # 1 filter byte + RGB pixel
    comp = zlib.compress(raw)
    idat = b"IDAT" + comp
    idat_chunk = struct.pack(">I", len(comp)) + idat + struct.pack(">I", zlib.crc32(idat) & 0xffffffff)
    iend = b"IEND"
    iend_chunk = struct.pack(">I", 0) + iend + struct.pack(">I", zlib.crc32(iend) & 0xffffffff)
    return sig + ihdr_chunk + idat_chunk + iend_chunk


@pytest.fixture(scope="module")
def user_session():
    s = requests.Session()
    r = s.post(f"{API}/auth/login", json={"email": DEMO_EMAIL, "password": DEMO_PASSWORD})
    assert r.status_code == 200, r.text
    return s


class TestUploadImage:
    def test_anon_upload_rejected(self):
        png = _tiny_png()
        r = requests.post(
            f"{API}/uploads/image",
            files={"file": ("t.png", png, "image/png")},
        )
        assert r.status_code in (401, 403), f"Expected 401/403, got {r.status_code}: {r.text}"

    def test_valid_png_upload(self, user_session):
        png = _tiny_png()
        r = user_session.post(
            f"{API}/uploads/image",
            files={"file": ("test.png", png, "image/png")},
        )
        assert r.status_code == 200, f"Upload failed: {r.status_code} {r.text}"
        data = r.json()
        assert "id" in data
        assert "url" in data
        assert "storage_path" in data
        assert data["size"] == len(png)
        assert data["content_type"] == "image/png"
        # URL must be absolute preview host, NOT internal cluster
        assert data["url"].startswith("http"), data["url"]
        assert "emergentcf.cloud" not in data["url"], f"Internal host leaked: {data['url']}"
        # store on class for next test
        TestUploadImage.uploaded_url = data["url"]
        TestUploadImage.storage_path = data["storage_path"]

    def test_read_uploaded_file_public(self):
        url = getattr(TestUploadImage, "uploaded_url", None)
        if not url:
            pytest.skip("Upload test did not run")
        r = requests.get(url)
        assert r.status_code == 200, f"Read failed: {r.status_code}"
        assert r.headers.get("content-type", "").startswith("image/png")
        assert "cache-control" in {k.lower() for k in r.headers.keys()}
        assert len(r.content) > 0

    def test_wrong_mime_rejected(self, user_session):
        r = user_session.post(
            f"{API}/uploads/image",
            files={"file": ("t.txt", b"hello world", "text/plain")},
        )
        assert r.status_code == 400, f"Expected 400, got {r.status_code}: {r.text}"

    def test_empty_file_rejected(self, user_session):
        r = user_session.post(
            f"{API}/uploads/image",
            files={"file": ("t.png", b"", "image/png")},
        )
        assert r.status_code == 400, f"Expected 400, got {r.status_code}: {r.text}"

    def test_oversize_rejected(self, user_session):
        # 11MB junk with image/png content-type (server checks size AFTER read)
        big = b"\x89PNG\r\n\x1a\n" + b"\x00" * (11 * 1024 * 1024)
        r = user_session.post(
            f"{API}/uploads/image",
            files={"file": ("big.png", big, "image/png")},
        )
        assert r.status_code == 413, f"Expected 413, got {r.status_code}: {r.text}"

    def test_file_record_persisted(self, user_session):
        # We can't hit Mongo directly here; verify via public read of newly uploaded file
        png = _tiny_png()
        r = user_session.post(
            f"{API}/uploads/image",
            files={"file": ("persist.png", png, "image/png")},
        )
        assert r.status_code == 200
        url = r.json()["url"]
        g = requests.get(url)
        assert g.status_code == 200


class TestPatchMe:
    def test_patch_avatar_url(self, user_session):
        new_url = "https://placehold.co/200x200/TEST"
        r = user_session.patch(f"{API}/auth/me", json={"avatar_url": new_url})
        assert r.status_code == 200, r.text
        data = r.json()
        assert data.get("avatar_url") == new_url
        # verify persisted
        me = user_session.get(f"{API}/auth/me")
        assert me.status_code == 200
        assert me.json().get("avatar_url") == new_url

    def test_patch_empty_payload_rejected(self, user_session):
        r = user_session.patch(f"{API}/auth/me", json={})
        assert r.status_code == 400, f"Expected 400, got {r.status_code}: {r.text}"

    def test_patch_requires_auth(self):
        r = requests.patch(f"{API}/auth/me", json={"avatar_url": "https://x.com/a.png"})
        assert r.status_code in (401, 403)
