"""
Regression tests for the newly added features:
- Groups / Communities
- Editorial Blog
- Social Feed (posts, comments, likes)
- Follows / Followers
- Public user profile aggregator
"""
import os
import random
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
API = f"{BASE_URL}/api"

ADMIN_EMAIL = os.environ.get("TEST_ADMIN_EMAIL", "admin@rateverse.com")
ADMIN_PASSWORD = os.environ.get("TEST_ADMIN_PASSWORD", "Admin@12345")
DEMO1 = (
    os.environ.get("TEST_DEMO1_EMAIL", "ava.matthews@demo.com"),
    os.environ.get("TEST_DEMO_PASSWORD", "Demo@12345"),
)
DEMO2 = (
    os.environ.get("TEST_DEMO2_EMAIL", "noah.bennett@demo.com"),
    os.environ.get("TEST_DEMO_PASSWORD", "Demo@12345"),
)


@pytest.fixture(scope="module")
def admin_s():
    s = requests.Session()
    r = s.post(f"{API}/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
    assert r.status_code == 200, r.text
    return s


@pytest.fixture(scope="module")
def user1_s():
    s = requests.Session()
    r = s.post(f"{API}/auth/login", json={"email": DEMO1[0], "password": DEMO1[1]})
    assert r.status_code == 200, r.text
    me = s.get(f"{API}/auth/me").json()
    return s, me


@pytest.fixture(scope="module")
def user2_s():
    s = requests.Session()
    r = s.post(f"{API}/auth/login", json={"email": DEMO2[0], "password": DEMO2[1]})
    assert r.status_code == 200, r.text
    me = s.get(f"{API}/auth/me").json()
    return s, me


# ----------------- Groups -----------------
class TestGroups:
    def test_list_groups_public(self):
        r = requests.get(f"{API}/groups")
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_create_group_requires_auth(self):
        r = requests.post(f"{API}/groups", json={
            "name": "Anon Group", "description": "Too short to allow."
        })
        assert r.status_code in (401, 403)

    def test_group_full_lifecycle(self, user1_s, user2_s):
        s1, me1 = user1_s
        s2, me2 = user2_s
        suffix = random.randint(100000, 999999)
        payload = {
            "name": f"TEST_Group_{suffix}",
            "description": "Automated test group for regression suite.",
            "category_slug": "business",
        }
        r = s1.post(f"{API}/groups", json=payload)
        assert r.status_code in (200, 201), r.text
        g = r.json()
        assert g["name"] == payload["name"]
        gid = g["id"]
        slug = g["slug"]
        assert g["member_count"] == 1  # creator auto-joined

        # GET by slug
        gr = requests.get(f"{API}/groups/{slug}")
        assert gr.status_code == 200
        assert gr.json()["id"] == gid

        # Second user joins
        j = s2.post(f"{API}/groups/{gid}/join")
        assert j.status_code in (200, 201), j.text

        # is-member should be true for user2
        m = s2.get(f"{API}/groups/{gid}/is-member")
        assert m.status_code == 200
        assert m.json().get("is_member") is True

        # Members list grows
        mem = requests.get(f"{API}/groups/{gid}/members")
        assert mem.status_code == 200
        assert len(mem.json()) >= 2

        # Create a discussion post inside group
        post_payload = {
            "title": f"TEST_Post_{suffix}",
            "body": "Automated discussion body for test.",
            "type": "discussion",
        }
        pr = s2.post(f"{API}/groups/{gid}/posts", json=post_payload)
        assert pr.status_code in (200, 201), pr.text
        post = pr.json()
        pid = post["id"]

        # List posts
        lp = requests.get(f"{API}/groups/{gid}/posts")
        assert lp.status_code == 200
        assert any(p["id"] == pid for p in lp.json())

        # Like post
        lk = s1.post(f"{API}/groups/posts/{pid}/like")
        assert lk.status_code in (200, 201), lk.text

        # User2 (post author) deletes post
        d = s2.delete(f"{API}/groups/posts/{pid}")
        assert d.status_code in (200, 204), d.text

        # User2 leaves group
        lv = s2.post(f"{API}/groups/{gid}/leave")
        assert lv.status_code in (200, 204), lv.text


# ----------------- Blog -----------------
class TestBlog:
    def test_blog_list_public(self):
        r = requests.get(f"{API}/blog")
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_blog_tags(self):
        r = requests.get(f"{API}/blog/tags")
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_blog_create_requires_admin(self, user1_s):
        s1, _ = user1_s
        r = s1.post(f"{API}/blog", json={
            "title": "Forbidden", "excerpt": "x" * 20,
            "body": "x" * 30, "tag": "Test"
        })
        assert r.status_code in (401, 403)

    def test_blog_full_lifecycle(self, admin_s, user1_s):
        s1, _ = user1_s
        suffix = random.randint(100000, 999999)
        payload = {
            "title": f"TEST_Blog_{suffix}",
            "excerpt": "Excerpt for the automated regression test blog post.",
            "body": "# Body\n\nThis is the body of the automated test blog post." * 3,
            "tag": "TestingTag",
            "published": True,
        }
        r = admin_s.post(f"{API}/blog", json=payload)
        assert r.status_code in (200, 201), r.text
        post = r.json()
        slug = post["slug"]
        pid = post["id"]

        # Public read
        g = requests.get(f"{API}/blog/{slug}")
        assert g.status_code == 200
        assert g.json()["id"] == pid

        # User likes post
        lk = s1.post(f"{API}/blog/{pid}/like")
        assert lk.status_code in (200, 201), lk.text
        assert lk.json()["likes_count"] >= 1

        # Update
        u = admin_s.patch(f"{API}/blog/{pid}", json={"title": f"TEST_Blog_{suffix}_v2"})
        assert u.status_code in (200, 201), u.text

        # Delete
        d = admin_s.delete(f"{API}/blog/{pid}")
        assert d.status_code in (200, 204), d.text

        # Now should 404
        g2 = requests.get(f"{API}/blog/{slug}")
        assert g2.status_code == 404


# ----------------- Feed -----------------
class TestFeed:
    def test_feed_list_public(self):
        r = requests.get(f"{API}/feed")
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_feed_following_requires_auth(self):
        r = requests.get(f"{API}/feed", params={"sort": "following"})
        assert r.status_code in (401, 403)

    def test_feed_trending(self):
        r = requests.get(f"{API}/feed", params={"sort": "trending"})
        assert r.status_code == 200

    def test_trending_hashtags(self):
        r = requests.get(f"{API}/feed/hashtags/trending")
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_feed_post_lifecycle(self, user1_s, user2_s):
        s1, me1 = user1_s
        s2, _ = user2_s

        suffix = random.randint(100000, 999999)
        body = f"TEST_post_{suffix} sharing thoughts on #rateverse and #testing"
        r = s1.post(f"{API}/feed/posts", json={"body": body})
        assert r.status_code in (200, 201), r.text
        post = r.json()
        pid = post["id"]
        assert "rateverse" in (post.get("hashtags") or []) or post.get("hashtags") is not None

        # Get single
        g = requests.get(f"{API}/feed/posts/{pid}")
        assert g.status_code == 200

        # Like
        lk = s2.post(f"{API}/feed/posts/{pid}/like")
        assert lk.status_code in (200, 201), lk.text
        assert lk.json().get("liked_by_me") in (True, False)

        # Save (toggle)
        sv = s2.post(f"{API}/feed/posts/{pid}/save")
        assert sv.status_code in (200, 201), sv.text

        # Comment
        cm = s2.post(f"{API}/feed/posts/{pid}/comments", json={"body": "Great post! TEST"})
        assert cm.status_code in (200, 201), cm.text
        cid = cm.json()["id"]

        # List comments
        lc = requests.get(f"{API}/feed/posts/{pid}/comments")
        assert lc.status_code == 200
        assert any(c["id"] == cid for c in lc.json())

        # Like comment
        clk = s1.post(f"{API}/feed/comments/{cid}/like")
        assert clk.status_code in (200, 201), clk.text

        # Author deletes comment
        dc = s2.delete(f"{API}/feed/comments/{cid}")
        assert dc.status_code in (200, 204), dc.text

        # Author deletes post
        dp = s1.delete(f"{API}/feed/posts/{pid}")
        assert dp.status_code in (200, 204), dp.text


# ----------------- Follows -----------------
class TestFollows:
    def test_follow_self_rejected(self, user1_s):
        s1, me1 = user1_s
        r = s1.post(f"{API}/follows/{me1['id']}")
        assert r.status_code == 400

    def test_follow_nonexistent(self, user1_s):
        s1, _ = user1_s
        r = s1.post(f"{API}/follows/nonexistent-user-xyz")
        assert r.status_code == 404

    def test_follow_unfollow_cycle(self, user1_s, user2_s):
        s1, me1 = user1_s
        s2, me2 = user2_s
        tid = me2["id"]

        # Follow
        r = s1.post(f"{API}/follows/{tid}")
        assert r.status_code in (200, 201), r.text
        assert r.json().get("following") is True

        # Status reflects
        st = s1.get(f"{API}/follows/status/{tid}")
        assert st.status_code == 200
        sj = st.json()
        assert sj["is_following"] is True
        assert sj["followers_count"] >= 1

        # Followers list contains me1
        flw = requests.get(f"{API}/follows/{tid}/followers")
        assert flw.status_code == 200
        assert any(u["id"] == me1["id"] for u in flw.json())

        # Following list of me1 contains tid
        fol = requests.get(f"{API}/follows/{me1['id']}/following")
        assert fol.status_code == 200
        assert any(u["id"] == tid for u in fol.json())

        # Unfollow
        u = s1.delete(f"{API}/follows/{tid}")
        assert u.status_code in (200, 204)

        st2 = s1.get(f"{API}/follows/status/{tid}")
        assert st2.json()["is_following"] is False


# ----------------- User Profile Aggregator -----------------
class TestUserProfile:
    def test_profile_aggregator(self, user1_s, user2_s):
        s1, me1 = user1_s
        s2, me2 = user2_s
        r = s1.get(f"{API}/feed/users/{me2['id']}/profile")
        assert r.status_code == 200, r.text
        data = r.json()
        assert "user" in data
        assert "stats" in data
        for k in ("followers", "following", "posts", "reviews"):
            assert k in data["stats"]

    def test_profile_404(self):
        r = requests.get(f"{API}/feed/users/nonexistent-xyz/profile")
        assert r.status_code == 404
