"""
Comprehensive backend regression tests for Rateverse.
Covers: auth, categories, items, reviews, AI summary, admin, submissions.
"""
import os
import time
import random
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://rateverse-1.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"

ADMIN_EMAIL = os.environ.get("TEST_ADMIN_EMAIL", "admin@rateverse.com")
ADMIN_PASSWORD = os.environ.get("TEST_ADMIN_PASSWORD", "Admin@12345")
DEMO_EMAIL = os.environ.get("TEST_DEMO_EMAIL", "ava.matthews@demo.com")
DEMO_PASSWORD = os.environ.get("TEST_DEMO_PASSWORD", "Demo@12345")


# ---------- Fixtures ----------
@pytest.fixture(scope="session")
def admin_session():
    s = requests.Session()
    r = s.post(f"{API}/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
    assert r.status_code == 200, f"Admin login failed: {r.status_code} {r.text}"
    return s


@pytest.fixture(scope="session")
def user_session():
    s = requests.Session()
    r = s.post(f"{API}/auth/login", json={"email": DEMO_EMAIL, "password": DEMO_PASSWORD})
    assert r.status_code == 200, f"Demo user login failed: {r.status_code} {r.text}"
    return s


@pytest.fixture(scope="session")
def fresh_user_session():
    """Register a fresh user for write tests (avoids hitting rate limits on demo accounts)."""
    s = requests.Session()
    suffix = random.randint(100000, 999999)
    email = f"TEST_user_{suffix}@example.com"
    r = s.post(f"{API}/auth/register", json={
        "email": email, "password": "TestPass@123", "name": f"Test User {suffix}"
    })
    assert r.status_code in (200, 201), f"Register failed: {r.status_code} {r.text}"
    return s, email


# ---------- Auth ----------
class TestAuth:
    def test_register_and_me(self):
        s = requests.Session()
        suffix = random.randint(100000, 999999)
        email = f"TEST_reg_{suffix}@example.com"
        r = s.post(f"{API}/auth/register", json={
            "email": email, "password": "TestPass@123", "name": "Reg Tester"
        })
        assert r.status_code in (200, 201), r.text
        body = r.json()
        assert "user" in body or "id" in body or "email" in body
        # cookies should be set
        assert any("access" in c.name.lower() or "token" in c.name.lower() for c in s.cookies), \
            f"No auth cookie set: {s.cookies}"
        me = s.get(f"{API}/auth/me")
        assert me.status_code == 200
        assert me.json().get("email", "").lower() == email.lower()

    def test_login_admin(self, admin_session):
        me = admin_session.get(f"{API}/auth/me")
        assert me.status_code == 200
        data = me.json()
        assert data.get("email") == ADMIN_EMAIL
        assert data.get("role") == "admin"

    def test_login_invalid(self):
        r = requests.post(f"{API}/auth/login", json={"email": ADMIN_EMAIL, "password": "wrong"})
        assert r.status_code in (400, 401)

    def test_logout(self):
        s = requests.Session()
        r = s.post(f"{API}/auth/login", json={"email": DEMO_EMAIL, "password": DEMO_PASSWORD})
        assert r.status_code == 200
        out = s.post(f"{API}/auth/logout")
        assert out.status_code in (200, 204)
        # me should now fail
        me = s.get(f"{API}/auth/me")
        assert me.status_code in (401, 403)


# ---------- Categories ----------
class TestCategories:
    def test_list_categories(self):
        r = requests.get(f"{API}/categories")
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)
        assert len(data) >= 5, f"Expected >=5 seeded categories, got {len(data)}"
        slugs = {c["slug"] for c in data}
        assert {"business", "entertainment", "digital"}.issubset(slugs)

    def test_get_category_by_slug(self):
        r = requests.get(f"{API}/categories/business")
        assert r.status_code == 200
        assert r.json().get("slug") == "business"

    def test_get_category_404(self):
        r = requests.get(f"{API}/categories/nonexistent-xyz")
        assert r.status_code == 404


# ---------- Items ----------
class TestItems:
    def test_list_items(self):
        r = requests.get(f"{API}/items", params={"limit": 10})
        assert r.status_code == 200
        body = r.json()
        # Could be list or paginated dict
        items = body if isinstance(body, list) else body.get("items", [])
        assert len(items) >= 1
        # ensure no _id leaked
        for it in items:
            assert "_id" not in it

    def test_items_search_query(self):
        r = requests.get(f"{API}/items", params={"q": "a", "limit": 5})
        assert r.status_code == 200

    def test_items_filter_category(self):
        r = requests.get(f"{API}/items", params={"category": "business", "limit": 20})
        assert r.status_code == 200

    def test_trending(self):
        r = requests.get(f"{API}/items/trending")
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_top(self):
        r = requests.get(f"{API}/items/top")
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_featured(self):
        r = requests.get(f"{API}/items/featured")
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_item_detail_and_related(self):
        r = requests.get(f"{API}/items", params={"limit": 1})
        body = r.json()
        items = body if isinstance(body, list) else body.get("items", [])
        assert items
        slug = items[0]["slug"]
        d = requests.get(f"{API}/items/{slug}")
        assert d.status_code == 200, d.text
        assert d.json().get("slug") == slug
        rel = requests.get(f"{API}/items/{slug}/related")
        assert rel.status_code == 200
        assert isinstance(rel.json(), list)


# ---------- Reviews ----------
class TestReviews:
    def _get_first_item_id(self):
        r = requests.get(f"{API}/items", params={"limit": 1})
        body = r.json()
        items = body if isinstance(body, list) else body.get("items", [])
        return items[0]["id"], items[0]["slug"]

    def test_list_reviews_for_item(self):
        item_id, slug = self._get_first_item_id()
        r = requests.get(f"{API}/items/{item_id}/reviews")
        assert r.status_code == 200, r.text
        assert isinstance(r.json(), list)

    def test_create_review_and_helpful_and_delete(self, fresh_user_session):
        s, _ = fresh_user_session
        item_id, _ = self._get_first_item_id()
        payload = {
            "rating": 4,
            "title": "TEST_review_title",
            "body": "This is a TEST review body for automated regression testing.",
            "pros": ["good"],
            "cons": ["minor issues"]
        }
        r = s.post(f"{API}/items/{item_id}/reviews", json=payload)
        # User may already have reviewed in a previous run; accept 200/201/400
        assert r.status_code in (200, 201, 400), r.text
        if r.status_code in (200, 201):
            rev = r.json()
            review_id = rev.get("id")
            assert review_id
            assert rev["rating"] == 4

            # helpful toggle
            h = s.post(f"{API}/reviews/{review_id}/helpful")
            assert h.status_code in (200, 201), h.text

            # report
            rep = s.post(f"{API}/reviews/{review_id}/report")
            assert rep.status_code in (200, 201), rep.text

            # owner delete
            d = s.delete(f"{API}/reviews/{review_id}")
            assert d.status_code in (200, 204)

    def test_my_reviews_requires_auth(self):
        r = requests.get(f"{API}/users/me/reviews")
        assert r.status_code in (401, 403)

    def test_my_reviews_authed(self, user_session):
        r = user_session.get(f"{API}/users/me/reviews")
        assert r.status_code == 200
        assert isinstance(r.json(), list)


# ---------- AI Summary ----------
class TestAI:
    def test_ai_summary(self):
        r = requests.get(f"{API}/items", params={"limit": 1})
        body = r.json()
        items = body if isinstance(body, list) else body.get("items", [])
        item_id = items[0]["id"]
        resp = requests.post(f"{API}/ai/summary/{item_id}", timeout=60)
        assert resp.status_code == 200, f"AI summary failed: {resp.status_code} {resp.text[:300]}"
        data = resp.json()
        # Expect non-empty summary text
        text = data.get("summary") or data.get("content") or ""
        assert isinstance(text, str) and len(text) > 5, f"Empty AI summary: {data}"


# ---------- Admin ----------
class TestAdmin:
    def test_admin_stats(self, admin_session):
        r = admin_session.get(f"{API}/admin/stats")
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, dict)

    def test_admin_users(self, admin_session):
        r = admin_session.get(f"{API}/admin/users")
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_admin_reviews_list(self, admin_session):
        r = admin_session.get(f"{API}/admin/reviews")
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_admin_requires_admin(self, user_session):
        r = user_session.get(f"{API}/admin/stats")
        assert r.status_code in (401, 403)


# ---------- Submissions ----------
class TestSubmissions:
    def _solve_captcha(self, s):
        cap = s.get(f"{API}/submissions/captcha")
        assert cap.status_code == 200, cap.text
        data = cap.json()
        q = (data.get("question") or data.get("q") or "").replace(" ", "")
        answer = None
        try:
            if "+" in q:
                a, b = q.split("+"); answer = int(a) + int(b)
            elif "-" in q:
                a, b = q.split("-"); answer = int(a) - int(b)
            elif "*" in q or "x" in q.lower():
                a, b = q.replace("x","*").replace("X","*").split("*"); answer = int(a) * int(b)
            else:
                pytest.skip(f"Unknown captcha op: {q}")
        except Exception as e:
            pytest.skip(f"Cannot parse captcha {q}: {e}")
        return q, answer

    def test_captcha_endpoint(self):
        r = requests.get(f"{API}/submissions/captcha")
        assert r.status_code == 200
        data = r.json()
        assert "question" in data or "q" in data

    def test_check_slug(self):
        r = requests.get(f"{API}/submissions/check-slug", params={"title": "Some New Item Title", "slug": ""})
        assert r.status_code == 200
        body = r.json()
        # must contain slug suggestion or available flag
        assert "slug" in body or "available" in body

    def test_submission_requires_auth(self):
        r = requests.post(f"{API}/submissions", json={
            "title": "X", "category": "business", "captcha_q": "1+1", "captcha_a": 2
        })
        assert r.status_code in (401, 403)

    def test_full_submission_admin_approve(self, fresh_user_session, admin_session):
        s, _ = fresh_user_session
        q, ans = self._solve_captcha(s)
        suffix = random.randint(100000, 999999)
        title = f"TEST_Submission_{suffix}"
        payload = {
            "title": title,
            "category_slug": "business",
            "short_description": "Short test description for regression suite.",
            "full_description": "This is the full description body for the automated test submission for regression suite verification.",
            "image_url": "https://placehold.co/600x400",
            "captcha_q": q,
            "captcha_a": str(ans),
            "industry": "Software",
            "ceo": "Test CEO",
            "founded": 2020,
            "website": "https://example.com"
        }
        r = s.post(f"{API}/submissions", json=payload)
        assert r.status_code in (200, 201), f"Submission failed: {r.status_code} {r.text}"
        sub = r.json()
        sub_id = sub.get("id")
        assert sub_id
        slug = sub.get("slug")
        assert slug

        # owner can fetch own
        own = s.get(f"{API}/submissions/{sub_id}")
        assert own.status_code == 200

        # my submissions
        mine = s.get(f"{API}/submissions/me")
        assert mine.status_code == 200
        assert any(x["id"] == sub_id for x in mine.json())

        # admin lists all
        adm_list = admin_session.get(f"{API}/submissions/admin/all", params={"status": "pending"})
        assert adm_list.status_code == 200, adm_list.text
        assert any(x["id"] == sub_id for x in adm_list.json())

        # admin approves
        appr = admin_session.post(f"{API}/submissions/admin/{sub_id}/approve")
        assert appr.status_code in (200, 201), appr.text

        # public item should now be available by slug
        time.sleep(1)
        pub = requests.get(f"{API}/items/{slug}")
        assert pub.status_code == 200, f"Approved item not public: {pub.status_code} {pub.text}"
        assert pub.json().get("slug") == slug

    def test_invalid_captcha_rejected(self, fresh_user_session):
        s, _ = fresh_user_session
        suffix = random.randint(100000, 999999)
        r = s.post(f"{API}/submissions", json={
            "title": f"TEST_BadCaptcha_{suffix}",
            "category_slug": "business",
            "short_description": "x" * 30,
            "full_description": "x" * 60,
            "captcha_q": "1+1",
            "captcha_a": "99"
        })
        assert r.status_code in (400, 422), f"Expected captcha rejection, got {r.status_code} {r.text}"
