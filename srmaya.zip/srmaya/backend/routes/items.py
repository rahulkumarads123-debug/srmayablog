"""Item endpoints."""
from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional

from models import Item, ItemCreate, new_id, now_iso
from auth import require_admin

router = APIRouter(prefix="/items", tags=["items"])


def _clean(doc: dict) -> dict:
    doc.pop("_id", None)
    return doc


@router.get("/trending", response_model=List[Item])
async def trending_items(limit: int = 8):
    from server import db

    items = (
        await db.items.find({}, {"_id": 0})
        .sort([("trending_score", -1), ("review_count", -1)])
        .to_list(limit)
    )
    return items


@router.get("/top", response_model=List[Item])
async def top_items(limit: int = 10, category: Optional[str] = None):
    from server import db

    q = {"review_count": {"$gte": 1}}
    if category:
        q["category_slug"] = category
    items = (
        await db.items.find(q, {"_id": 0})
        .sort([("avg_rating", -1), ("review_count", -1)])
        .to_list(limit)
    )
    return items


@router.get("/featured", response_model=List[Item])
async def featured_items(limit: int = 6):
    from server import db

    items = await db.items.find({"featured": True}, {"_id": 0}).to_list(limit)
    return items


@router.get("", response_model=dict)
async def list_items(
    q: Optional[str] = None,
    category: Optional[str] = None,
    sort: str = "trending",
    page: int = 1,
    limit: int = 12,
):
    from server import db

    query = {}
    if category:
        query["category_slug"] = category
    if q:
        query["$or"] = [
            {"name": {"$regex": q, "$options": "i"}},
            {"description": {"$regex": q, "$options": "i"}},
            {"tags": {"$regex": q, "$options": "i"}},
        ]

    sort_map = {
        "rating": [("avg_rating", -1), ("review_count", -1)],
        "newest": [("created_at", -1)],
        "trending": [("trending_score", -1), ("review_count", -1)],
        "reviews": [("review_count", -1)],
    }
    sort_spec = sort_map.get(sort, sort_map["trending"])

    total = await db.items.count_documents(query)
    skip = max(0, (page - 1) * limit)
    items = (
        await db.items.find(query, {"_id": 0})
        .sort(sort_spec)
        .skip(skip)
        .limit(limit)
        .to_list(limit)
    )
    return {"items": items, "total": total, "page": page, "limit": limit}


@router.get("/{slug}", response_model=Item)
async def get_item(slug: str):
    from server import db

    item = await db.items.find_one({"slug": slug}, {"_id": 0})
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    return item


@router.get("/{slug}/related", response_model=List[Item])
async def related_items(slug: str, limit: int = 4):
    from server import db

    item = await db.items.find_one({"slug": slug}, {"_id": 0})
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    related = (
        await db.items.find(
            {"category_slug": item["category_slug"], "slug": {"$ne": slug}}, {"_id": 0}
        )
        .sort([("avg_rating", -1)])
        .to_list(limit)
    )
    return related


@router.post("", response_model=Item)
async def create_item(payload: ItemCreate, _admin=Depends(require_admin)):
    from server import db

    if await db.items.find_one({"slug": payload.slug}):
        raise HTTPException(status_code=400, detail="Item slug already exists")
    cat = await db.categories.find_one({"slug": payload.category_slug}, {"_id": 0})
    if not cat:
        raise HTTPException(status_code=400, detail="Category not found")

    doc = Item(
        id=new_id(),
        slug=payload.slug,
        name=payload.name,
        description=payload.description,
        category_slug=payload.category_slug,
        category_name=cat["name"],
        image_url=payload.image_url,
        metadata=payload.metadata,
        tags=payload.tags,
        featured=payload.featured,
        created_at=now_iso(),
    ).model_dump()
    await db.items.insert_one(doc.copy())
    return doc


@router.patch("/{item_id}", response_model=Item)
async def update_item(item_id: str, payload: dict, _admin=Depends(require_admin)):
    from server import db

    allowed = {"name", "description", "image_url", "metadata", "tags", "featured", "category_slug"}
    update = {k: v for k, v in payload.items() if k in allowed}
    if "category_slug" in update:
        cat = await db.categories.find_one({"slug": update["category_slug"]}, {"_id": 0})
        if not cat:
            raise HTTPException(status_code=400, detail="Invalid category")
        update["category_name"] = cat["name"]
    res = await db.items.update_one({"id": item_id}, {"$set": update})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Item not found")
    item = await db.items.find_one({"id": item_id}, {"_id": 0})
    return item


@router.delete("/{item_id}")
async def delete_item(item_id: str, _admin=Depends(require_admin)):
    from server import db

    item = await db.items.find_one({"id": item_id}, {"_id": 0})
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    await db.items.delete_one({"id": item_id})
    await db.reviews.delete_many({"item_id": item_id})
    return {"message": "Item deleted"}
