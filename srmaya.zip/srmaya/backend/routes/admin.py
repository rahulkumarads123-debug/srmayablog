"""Admin endpoints."""
from fastapi import APIRouter, HTTPException, Depends
from typing import List

from auth import require_admin
from models import UserUpdate, UserPublic, Review

router = APIRouter(prefix="/admin", tags=["admin"])


@router.get("/stats")
async def admin_stats(_admin=Depends(require_admin)):
    from server import db

    users = await db.users.count_documents({})
    items = await db.items.count_documents({})
    reviews = await db.reviews.count_documents({})
    reported = await db.reviews.count_documents({"reported": True})
    cats = await db.categories.count_documents({})

    avg_pipe = [{"$group": {"_id": None, "avg": {"$avg": "$rating"}}}]
    avg = 0.0
    async for row in await db.reviews.aggregate(avg_pipe):
        avg = round(row.get("avg", 0) or 0, 2)

    # Reviews per category
    by_cat_cursor = await db.reviews.aggregate([
        {
            "$lookup": {
                "from": "items",
                "localField": "item_id",
                "foreignField": "id",
                "as": "item",
            }
        },
        {"$unwind": "$item"},
        {"$group": {"_id": "$item.category_name", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
    ])
    by_cat = await by_cat_cursor.to_list(20)
    by_cat = [{"category": r["_id"] or "Other", "count": r["count"]} for r in by_cat]

    # Recent reviews
    recent_reviews = (
        await db.reviews.find({}, {"_id": 0})
        .sort([("created_at", -1)])
        .to_list(8)
    )

    # Top items
    top_items = (
        await db.items.find({"review_count": {"$gte": 1}}, {"_id": 0})
        .sort([("avg_rating", -1)])
        .to_list(5)
    )

    return {
        "users": users,
        "items": items,
        "reviews": reviews,
        "reported": reported,
        "categories": cats,
        "average_rating": avg,
        "by_category": by_cat,
        "recent_reviews": recent_reviews,
        "top_items": top_items,
    }


@router.get("/users", response_model=List[UserPublic])
async def list_users(_admin=Depends(require_admin)):
    from server import db

    users = await db.users.find({}, {"_id": 0, "password_hash": 0}).sort([("created_at", -1)]).to_list(500)
    return users


@router.patch("/users/{user_id}", response_model=UserPublic)
async def update_user(user_id: str, payload: UserUpdate, _admin=Depends(require_admin)):
    from server import db

    update = {k: v for k, v in payload.model_dump(exclude_none=True).items()}
    if not update:
        raise HTTPException(status_code=400, detail="No fields to update")
    res = await db.users.update_one({"id": user_id}, {"$set": update})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    user = await db.users.find_one({"id": user_id}, {"_id": 0, "password_hash": 0})
    return user


@router.delete("/users/{user_id}")
async def delete_user(user_id: str, _admin=Depends(require_admin)):
    from server import db

    user = await db.users.find_one({"id": user_id}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if user.get("role") == "admin":
        raise HTTPException(status_code=400, detail="Cannot delete admin user")
    await db.users.delete_one({"id": user_id})
    await db.reviews.delete_many({"user_id": user_id})
    return {"message": "User deleted"}


@router.get("/reviews", response_model=List[Review])
async def list_all_reviews(reported: bool = False, _admin=Depends(require_admin)):
    from server import db

    q = {"reported": True} if reported else {}
    reviews = await db.reviews.find(q, {"_id": 0}).sort([("created_at", -1)]).to_list(500)
    return reviews


@router.post("/reviews/{review_id}/unreport")
async def unreport(review_id: str, _admin=Depends(require_admin)):
    from server import db

    res = await db.reviews.update_one({"id": review_id}, {"$set": {"reported": False}})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Review not found")
    return {"message": "Review restored"}


@router.delete("/reviews/{review_id}")
async def admin_delete_review(review_id: str, _admin=Depends(require_admin)):
    from server import db
    from routes.reviews import _recompute_item_stats

    review = await db.reviews.find_one({"id": review_id}, {"_id": 0})
    if not review:
        raise HTTPException(status_code=404, detail="Review not found")
    await db.reviews.delete_one({"id": review_id})
    await _recompute_item_stats(db, review["item_id"])
    return {"message": "Review deleted"}


@router.patch("/items/{item_id}/feature")
async def toggle_feature(item_id: str, _admin=Depends(require_admin)):
    from server import db

    item = await db.items.find_one({"id": item_id}, {"_id": 0})
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    new_val = not item.get("featured", False)
    await db.items.update_one({"id": item_id}, {"$set": {"featured": new_val}})
    return {"featured": new_val}
