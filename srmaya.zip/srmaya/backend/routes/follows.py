"""Followers / following system."""
from fastapi import APIRouter, HTTPException, Depends

from auth import get_current_user
from models import new_id, now_iso
from routes.notifications import create_notification

router = APIRouter(prefix="/follows", tags=["follows"])


@router.post("/{target_user_id}")
async def follow_user(target_user_id: str, user: dict = Depends(get_current_user)):
    from server import db

    if target_user_id == user["id"]:
        raise HTTPException(status_code=400, detail="You cannot follow yourself")
    target = await db.users.find_one({"id": target_user_id}, {"_id": 0, "id": 1, "name": 1})
    if not target:
        raise HTTPException(status_code=404, detail="User not found")

    existing = await db.follows.find_one(
        {"follower_id": user["id"], "following_id": target_user_id}, {"_id": 0}
    )
    if existing:
        return {"following": True, "message": "Already following"}

    await db.follows.insert_one({
        "id": new_id(),
        "follower_id": user["id"],
        "following_id": target_user_id,
        "created_at": now_iso(),
    })
    await create_notification(
        db,
        recipient_id=target_user_id,
        actor_id=user["id"],
        actor_name=user["name"],
        actor_avatar=user.get("avatar_url"),
        type="follow",
        message=f"{user['name']} started following you.",
        link=f"/u/{user['id']}",
        target_type="user",
        target_id=user["id"],
    )
    return {"following": True, "message": "Followed"}


@router.delete("/{target_user_id}")
async def unfollow_user(target_user_id: str, user: dict = Depends(get_current_user)):
    from server import db

    res = await db.follows.delete_one(
        {"follower_id": user["id"], "following_id": target_user_id}
    )
    return {"following": False, "deleted": res.deleted_count}


@router.get("/{user_id}/followers")
async def list_followers(user_id: str):
    from server import db

    rows = await db.follows.find({"following_id": user_id}, {"_id": 0}).to_list(1000)
    if not rows:
        return []
    ids = [r["follower_id"] for r in rows]
    users = await db.users.find({"id": {"$in": ids}}, {"_id": 0, "password_hash": 0}).to_list(1000)
    return users


@router.get("/{user_id}/following")
async def list_following(user_id: str):
    from server import db

    rows = await db.follows.find({"follower_id": user_id}, {"_id": 0}).to_list(1000)
    if not rows:
        return []
    ids = [r["following_id"] for r in rows]
    users = await db.users.find({"id": {"$in": ids}}, {"_id": 0, "password_hash": 0}).to_list(1000)
    return users


@router.get("/status/{target_user_id}")
async def follow_status(target_user_id: str, user: dict = Depends(get_current_user)):
    from server import db

    existing = await db.follows.find_one(
        {"follower_id": user["id"], "following_id": target_user_id}, {"_id": 0}
    )
    followers_count = await db.follows.count_documents({"following_id": target_user_id})
    following_count = await db.follows.count_documents({"follower_id": target_user_id})
    return {
        "is_following": bool(existing),
        "followers_count": followers_count,
        "following_count": following_count,
    }
