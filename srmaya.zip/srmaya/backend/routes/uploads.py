"""Image / file upload endpoints backed by Emergent Object Storage."""
import os
import uuid
from datetime import datetime, timezone
from typing import Optional

import requests
from fastapi import APIRouter, HTTPException, UploadFile, File, Depends, Response, Request

from auth import get_current_user
from models import new_id, now_iso


router = APIRouter(prefix="/uploads", tags=["uploads"])


# ---- Storage config ----
STORAGE_BASE = (os.environ.get("INTEGRATION_PROXY_URL") or "").strip() or "https://integrations.emergentagent.com"
STORAGE_URL = STORAGE_BASE.rstrip("/") + "/objstore/api/v1/storage"
EMERGENT_KEY = os.environ.get("EMERGENT_LLM_KEY")
APP_NAME = "rateverse"

ALLOWED_MIME = {"image/jpeg", "image/png", "image/webp", "image/gif"}
EXT_BY_MIME = {
    "image/jpeg": "jpg",
    "image/png": "png",
    "image/webp": "webp",
    "image/gif": "gif",
}
MAX_SIZE = 10 * 1024 * 1024  # 10 MB

_storage_key: Optional[str] = None


def init_storage(force: bool = False) -> str:
    global _storage_key
    if _storage_key and not force:
        return _storage_key
    if not EMERGENT_KEY:
        raise HTTPException(status_code=500, detail="Storage key not configured on server")
    resp = requests.post(
        f"{STORAGE_URL}/init",
        json={"emergent_key": EMERGENT_KEY},
        timeout=30,
    )
    resp.raise_for_status()
    _storage_key = resp.json()["storage_key"]
    return _storage_key


def _put_object(path: str, data: bytes, content_type: str) -> dict:
    key = init_storage()
    resp = requests.put(
        f"{STORAGE_URL}/objects/{path}",
        headers={"X-Storage-Key": key, "Content-Type": content_type},
        data=data,
        timeout=120,
    )
    if resp.status_code == 404:
        # storage_key expired — force refresh once
        key = init_storage(force=True)
        resp = requests.put(
            f"{STORAGE_URL}/objects/{path}",
            headers={"X-Storage-Key": key, "Content-Type": content_type},
            data=data,
            timeout=120,
        )
    resp.raise_for_status()
    return resp.json()


def _get_object(path: str) -> tuple[bytes, str]:
    key = init_storage()
    resp = requests.get(
        f"{STORAGE_URL}/objects/{path}",
        headers={"X-Storage-Key": key},
        timeout=60,
    )
    if resp.status_code == 404:
        # try refreshing key once
        key = init_storage(force=True)
        resp = requests.get(
            f"{STORAGE_URL}/objects/{path}",
            headers={"X-Storage-Key": key},
            timeout=60,
        )
    resp.raise_for_status()
    return resp.content, resp.headers.get("Content-Type", "application/octet-stream")


# ---- Endpoints ----
@router.post("/image")
async def upload_image(
    request: Request,
    file: UploadFile = File(...),
    user: dict = Depends(get_current_user),
):
    """Upload an image (jpg/png/webp/gif, ≤ 10 MB). Returns a URL usable in <img src>."""
    from server import db

    content_type = (file.content_type or "").lower()
    if content_type not in ALLOWED_MIME:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type: {content_type or 'unknown'}. Use JPG, PNG, WEBP or GIF.",
        )

    data = await file.read()
    size = len(data)
    if size == 0:
        raise HTTPException(status_code=400, detail="Empty file")
    if size > MAX_SIZE:
        raise HTTPException(status_code=413, detail="File too large — max 10 MB")

    ext = EXT_BY_MIME[content_type]
    storage_path = f"{APP_NAME}/uploads/{user['id']}/{uuid.uuid4()}.{ext}"

    try:
        result = _put_object(storage_path, data, content_type)
    except requests.HTTPError as e:
        code = e.response.status_code if e.response is not None else 500
        raise HTTPException(status_code=502, detail=f"Storage upload failed (HTTP {code})")

    stored_path = result.get("path") or storage_path

    file_doc = {
        "id": new_id(),
        "user_id": user["id"],
        "storage_path": stored_path,
        "original_filename": file.filename,
        "content_type": content_type,
        "size": size,
        "is_deleted": False,
        "created_at": now_iso(),
    }
    await db.files.insert_one(file_doc.copy())

    # Construct an absolute URL that survives the k8s reverse proxy hop.
    # Prefer X-Forwarded-* (set by the ingress) so the returned URL matches the
    # public origin the frontend reached us on, not the internal cluster host.
    fwd_proto = request.headers.get("x-forwarded-proto") or request.url.scheme
    fwd_host = request.headers.get("x-forwarded-host") or request.headers.get("host") or request.url.netloc
    base = f"{fwd_proto}://{fwd_host}".rstrip("/")
    absolute_url = f"{base}/api/uploads/file/{stored_path}"

    return {
        "id": file_doc["id"],
        "url": absolute_url,
        "storage_path": stored_path,
        "size": size,
        "content_type": content_type,
    }


@router.get("/file/{path:path}")
async def get_file(path: str):
    """Public read proxy — images on Rateverse are meant to be publicly viewable."""
    from server import db

    record = await db.files.find_one({"storage_path": path, "is_deleted": False}, {"_id": 0})
    if not record:
        raise HTTPException(status_code=404, detail="File not found")
    try:
        data, ctype = _get_object(path)
    except requests.HTTPError as e:
        code = e.response.status_code if e.response is not None else 500
        raise HTTPException(status_code=502, detail=f"Storage read failed (HTTP {code})")
    return Response(
        content=data,
        media_type=record.get("content_type") or ctype,
        headers={"Cache-Control": "public, max-age=86400"},
    )
