"""User-submitted listing endpoints (pending → approved → published)."""
from datetime import datetime, timezone, timedelta
from typing import List, Optional
import re

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field

from auth import get_current_user, require_admin, require_verified
from models import new_id, now_iso, Item

router = APIRouter(prefix="/submissions", tags=["submissions"])


SLUG_RE = re.compile(r"[^a-z0-9]+")

VIDEO_HOSTS = {
    # YouTube
    "youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be", "www.youtu.be",
    "youtube-nocookie.com", "www.youtube-nocookie.com",
    # Facebook
    "facebook.com", "www.facebook.com", "m.facebook.com", "fb.watch", "www.fb.watch",
    # X / Twitter
    "twitter.com", "www.twitter.com", "mobile.twitter.com", "x.com", "www.x.com",
}


def _validate_video_url(url: Optional[str]) -> Optional[str]:
    """Video URL must be from YouTube, Facebook or X/Twitter."""
    if not url:
        return None
    url = url.strip()
    if not url:
        return None
    if not (url.startswith("http://") or url.startswith("https://")):
        raise HTTPException(status_code=400, detail="Video URL must start with http(s)://")
    try:
        from urllib.parse import urlparse
        host = (urlparse(url).hostname or "").lower()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid video URL")
    if host not in VIDEO_HOSTS:
        raise HTTPException(
            status_code=400,
            detail="Video URL must be from YouTube, Facebook or X (Twitter)",
        )
    return url


def slugify(text: str) -> str:
    text = (text or "").strip().lower()
    text = SLUG_RE.sub("-", text)
    return text.strip("-") or "untitled"


# ---- Models ----
class SubmissionCreate(BaseModel):
    title: str = Field(min_length=2, max_length=120)
    slug: Optional[str] = None
    category_slug: str
    subcategory: Optional[str] = None
    short_description: str = Field(min_length=10, max_length=240)
    full_description: str = Field(min_length=20, max_length=4000)
    featured_image: Optional[str] = None
    gallery_images: List[str] = Field(default_factory=list)
    logo_url: Optional[str] = None
    video_url: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    extra: dict = Field(default_factory=dict)  # category-specific fields
    captcha_q: Optional[str] = None
    captcha_a: Optional[str] = None


class SubmissionEditRequest(BaseModel):
    title: Optional[str] = None
    slug: Optional[str] = None
    category_slug: Optional[str] = None
    subcategory: Optional[str] = None
    short_description: Optional[str] = None
    full_description: Optional[str] = None
    featured_image: Optional[str] = None
    gallery_images: Optional[List[str]] = None
    logo_url: Optional[str] = None
    video_url: Optional[str] = None
    tags: Optional[List[str]] = None
    extra: Optional[dict] = None
    admin_notes: Optional[str] = None


class RejectRequest(BaseModel):
    notes: Optional[str] = None


# ---- Helpers ----
def _validate_url(url: Optional[str]) -> Optional[str]:
    if not url:
        return None
    url = url.strip()
    if not url:
        return None
    if not (url.startswith("http://") or url.startswith("https://")):
        raise HTTPException(status_code=400, detail=f"Invalid URL: {url}")
    if len(url) > 800:
        raise HTTPException(status_code=400, detail="URL too long")
    return url


def _verify_captcha(q: Optional[str], a: Optional[str]):
    if not q or a is None:
        raise HTTPException(status_code=400, detail="Captcha required")
    try:
        # Q format: "3+5" or "12-7"
        q = q.replace(" ", "")
        m = re.match(r"^(\d{1,3})([+\-x*])(\d{1,3})$", q)
        if not m:
            raise ValueError("Bad captcha question")
        x, op, y = int(m.group(1)), m.group(2), int(m.group(3))
        expected = x + y if op == "+" else (x - y if op == "-" else x * y)
        if int(str(a).strip()) != expected:
            raise HTTPException(status_code=400, detail="Captcha incorrect")
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=400, detail="Captcha invalid")


async def _check_rate_limit(db, user_id: str):
    """Max 5 submissions per user per hour."""
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
    recent = await db.user_submissions.count_documents(
        {"user_id": user_id, "created_at": {"$gte": cutoff}}
    )
    if recent >= 5:
        raise HTTPException(status_code=429, detail="Rate limit: max 5 submissions per hour. Try again later.")


async def _ensure_unique_slug(db, slug: str, exclude_submission_id: Optional[str] = None) -> str:
    """Returns a unique slug across both items + pending/approved submissions."""
    base = slug
    n = 1
    while True:
        item_clash = await db.items.find_one({"slug": slug}, {"_id": 0})
        sub_q = {"slug": slug, "status": {"$in": ["pending", "approved"]}}
        if exclude_submission_id:
            sub_q["id"] = {"$ne": exclude_submission_id}
        sub_clash = await db.user_submissions.find_one(sub_q, {"_id": 0})
        if not item_clash and not sub_clash:
            return slug
        n += 1
        slug = f"{base}-{n}"


def _strip(doc: dict) -> dict:
    doc.pop("_id", None)
    return doc


# ---- Public endpoints ----
@router.get("/check-slug")
async def check_slug(title: str = "", slug: str = ""):
    from server import db

    proposed = slug.strip() or slugify(title)
    if not proposed:
        return {"slug": "", "available": False}
    item = await db.items.find_one({"slug": proposed}, {"_id": 0, "id": 1})
    sub = await db.user_submissions.find_one(
        {"slug": proposed, "status": {"$in": ["pending", "approved"]}}, {"_id": 0, "id": 1}
    )
    return {"slug": proposed, "available": not (item or sub)}


@router.get("/captcha")
async def get_captcha():
    """Generate a simple math captcha question."""
    import secrets
    a = secrets.randbelow(18) + 2  # 2..19
    b = secrets.randbelow(18) + 2  # 2..19
    op = secrets.choice(["+", "-"])
    q = f"{a}{op}{b}"
    return {"question": q, "label": f"What is {a} {op} {b}?"}


@router.post("")
async def create_submission(payload: SubmissionCreate, user: dict = Depends(require_verified)):
    from server import db

    _verify_captcha(payload.captcha_q, payload.captcha_a)
    await _check_rate_limit(db, user["id"])

    cat = await db.categories.find_one({"slug": payload.category_slug}, {"_id": 0})
    if not cat:
        raise HTTPException(status_code=400, detail="Category not found")

    # URLs validation
    featured = _validate_url(payload.featured_image)
    logo = _validate_url(payload.logo_url)
    video = _validate_video_url(payload.video_url)
    gallery = [_validate_url(g) for g in (payload.gallery_images or []) if _validate_url(g)]

    # Slug
    desired_slug = (payload.slug or slugify(payload.title)).strip().lower()
    desired_slug = slugify(desired_slug)
    final_slug = await _ensure_unique_slug(db, desired_slug)

    doc = {
        "id": new_id(),
        "user_id": user["id"],
        "user_name": user["name"],
        "user_email": user.get("email"),
        "title": payload.title.strip(),
        "slug": final_slug,
        "category_slug": payload.category_slug,
        "category_name": cat["name"],
        "subcategory": (payload.subcategory or "").strip() or None,
        "short_description": payload.short_description.strip(),
        "full_description": payload.full_description.strip(),
        "featured_image": featured,
        "gallery_images": gallery,
        "logo_url": logo,
        "video_url": video,
        "tags": [t.strip() for t in (payload.tags or []) if t.strip()],
        "extra": payload.extra or {},
        "status": "pending",
        "admin_notes": None,
        "created_at": now_iso(),
        "updated_at": now_iso(),
    }
    await db.user_submissions.insert_one(doc.copy())
    return _strip(doc)


@router.get("/me")
async def list_my_submissions(user: dict = Depends(get_current_user)):
    from server import db

    subs = (
        await db.user_submissions.find({"user_id": user["id"]}, {"_id": 0})
        .sort([("created_at", -1)])
        .to_list(200)
    )
    return subs


@router.get("/{submission_id}")
async def get_submission(submission_id: str, user: dict = Depends(get_current_user)):
    from server import db

    sub = await db.user_submissions.find_one({"id": submission_id}, {"_id": 0})
    if not sub:
        raise HTTPException(status_code=404, detail="Submission not found")
    if sub["user_id"] != user["id"] and user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Not allowed")
    return sub


# ---- Admin endpoints ----
@router.get("/admin/all")
async def admin_list(status: Optional[str] = None, _admin=Depends(require_admin)):
    from server import db

    q = {}
    if status:
        q["status"] = status
    subs = (
        await db.user_submissions.find(q, {"_id": 0})
        .sort([("created_at", -1)])
        .to_list(500)
    )
    return subs


@router.patch("/admin/{submission_id}")
async def admin_edit(submission_id: str, payload: SubmissionEditRequest, _admin=Depends(require_admin)):
    from server import db

    update = {k: v for k, v in payload.model_dump(exclude_none=True).items()}
    if "category_slug" in update:
        cat = await db.categories.find_one({"slug": update["category_slug"]}, {"_id": 0})
        if not cat:
            raise HTTPException(status_code=400, detail="Invalid category")
        update["category_name"] = cat["name"]
    if "slug" in update:
        update["slug"] = slugify(update["slug"])
    update["updated_at"] = now_iso()
    res = await db.user_submissions.update_one({"id": submission_id}, {"$set": update})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Submission not found")
    sub = await db.user_submissions.find_one({"id": submission_id}, {"_id": 0})
    return sub


@router.post("/admin/{submission_id}/approve")
async def admin_approve(submission_id: str, _admin=Depends(require_admin)):
    from server import db

    sub = await db.user_submissions.find_one({"id": submission_id}, {"_id": 0})
    if not sub:
        raise HTTPException(status_code=404, detail="Submission not found")
    if sub["status"] == "approved":
        raise HTTPException(status_code=400, detail="Already approved")

    # Build metadata from extra + subcategory
    metadata = dict(sub.get("extra") or {})
    if sub.get("subcategory"):
        metadata["subcategory"] = sub["subcategory"]
    if sub.get("video_url"):
        metadata["video_url"] = sub["video_url"]
    if sub.get("logo_url"):
        metadata["logo_url"] = sub["logo_url"]
    if sub.get("gallery_images"):
        metadata["gallery"] = sub["gallery_images"]
    metadata["short_description"] = sub.get("short_description")

    # Make sure slug is unique against items at approval time
    final_slug = await _ensure_unique_slug(db, sub["slug"], exclude_submission_id=sub["id"])

    item = Item(
        id=new_id(),
        slug=final_slug,
        name=sub["title"],
        description=sub["full_description"],
        category_slug=sub["category_slug"],
        category_name=sub["category_name"],
        image_url=sub.get("featured_image"),
        metadata=metadata,
        tags=sub.get("tags", []),
        featured=False,
        created_at=now_iso(),
    ).model_dump()
    await db.items.insert_one(item.copy())

    await db.user_submissions.update_one(
        {"id": submission_id},
        {
            "$set": {
                "status": "approved",
                "slug": final_slug,
                "approved_item_id": item["id"],
                "updated_at": now_iso(),
            }
        },
    )
    return {"message": "Approved and published", "item_slug": final_slug, "item_id": item["id"]}


@router.post("/admin/{submission_id}/reject")
async def admin_reject(submission_id: str, payload: RejectRequest, _admin=Depends(require_admin)):
    from server import db

    res = await db.user_submissions.update_one(
        {"id": submission_id},
        {
            "$set": {
                "status": "rejected",
                "admin_notes": payload.notes,
                "updated_at": now_iso(),
            }
        },
    )
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Submission not found")
    return {"message": "Rejected"}


@router.delete("/admin/{submission_id}")
async def admin_delete(submission_id: str, _admin=Depends(require_admin)):
    from server import db

    res = await db.user_submissions.delete_one({"id": submission_id})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Submission not found")
    return {"message": "Deleted"}
