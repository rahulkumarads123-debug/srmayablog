"""Category endpoints."""
from fastapi import APIRouter, HTTPException, Depends
from typing import List

from models import Category, CategoryCreate, new_id
from auth import require_admin

router = APIRouter(prefix="/categories", tags=["categories"])


@router.get("", response_model=List[Category])
async def list_categories():
    from server import db

    cats = await db.categories.find({}, {"_id": 0}).to_list(100)
    # populate live item counts
    for c in cats:
        c["item_count"] = await db.items.count_documents({"category_slug": c["slug"]})
    cats.sort(key=lambda x: x["name"])
    return cats


@router.get("/{slug}", response_model=Category)
async def get_category(slug: str):
    from server import db

    cat = await db.categories.find_one({"slug": slug}, {"_id": 0})
    if not cat:
        raise HTTPException(status_code=404, detail="Category not found")
    cat["item_count"] = await db.items.count_documents({"category_slug": slug})
    return cat


@router.post("", response_model=Category)
async def create_category(payload: CategoryCreate, _admin=Depends(require_admin)):
    from server import db

    if await db.categories.find_one({"slug": payload.slug}):
        raise HTTPException(status_code=400, detail="Category slug already exists")
    doc = Category(id=new_id(), **payload.model_dump()).model_dump()
    await db.categories.insert_one(doc.copy())
    return doc
