"""Community Groups & Group Posts."""
from datetime import datetime, timezone
from typing import List, Optional
import re

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field

from auth import get_current_user, require_admin
from models import new_id, now_iso

router = APIRouter(prefix="/groups", tags=["groups"])

SLUG_RE = re.compile(r"[^a-z0-9]+")


def slugify(text: str) -> str:
    s = SLUG_RE.sub("-", (text or "").lower()).strip("-")
    return s or "group"


# ---- Models ----
class GroupCreate(BaseModel):
    name: str = Field(min_length=3, max_length=80)
    slug: Optional[str] = None
    description: str = Field(min_length=10, max_length=600)
    cover_url: Optional[str] = None
    category_slug: Optional[str] = None  # optional anchor category


class GroupUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    cover_url: Optional[str] = None
    category_slug: Optional[str] = None


class PostCreate(BaseModel):
    title: str = Field(min_length=2, max_length=140)
    body: str = Field(min_length=2, max_length=4000)
    type: str = Field(default="discussion")  # "discussion" or "recommendation"
    item_slug: Optional[str] = None  # required when type == "recommendation"


def _strip(doc: dict) -> dict:
    doc.pop("_id", None)
    return doc


async def _ensure_unique_group_slug(db, slug: str) -> str:
    base, n = slug, 1
    while await db.groups.find_one({"slug": slug}, {"_id": 0, "id": 1}):
        n += 1
        slug = f"{base}-{n}"
    return slug


async def _is_member(db, group_id: str, user_id: str) -> bool:
    m = await db.group_memberships.find_one({"group_id": group_id, "user_id": user_id}, {"_id": 0, "id": 1})
    return bool(m)


async def _recalc_group_counts(db, group_id: str):
    members = await db.group_memberships.count_documents({"group_id": group_id})
    posts = await db.group_posts.count_documents({"group_id": group_id})
    await db.groups.update_one({"id": group_id}, {"$set": {"member_count": members, "post_count": posts}})


# ---- Group CRUD ----
@router.get("")
async def list_groups(q: Optional[str] = None, category: Optional[str] = None, sort: str = "popular"):
    from server import db

    query = {}
    if category:
        query["category_slug"] = category
    if q:
        query["$or"] = [
            {"name": {"$regex": q, "$options": "i"}},
            {"description": {"$regex": q, "$options": "i"}},
        ]
    sort_spec = {
        "popular": [("member_count", -1), ("post_count", -1)],
        "newest": [("created_at", -1)],
        "active": [("post_count", -1)],
    }.get(sort, [("member_count", -1)])
    groups = await db.groups.find(query, {"_id": 0}).sort(sort_spec).to_list(200)
    return groups


@router.get("/me")
async def my_groups(user: dict = Depends(get_current_user)):
    from server import db

    memberships = await db.group_memberships.find({"user_id": user["id"]}, {"_id": 0}).to_list(200)
    if not memberships:
        return []
    ids = [m["group_id"] for m in memberships]
    groups = await db.groups.find({"id": {"$in": ids}}, {"_id": 0}).to_list(200)
    return groups


@router.post("")
async def create_group(payload: GroupCreate, user: dict = Depends(get_current_user)):
    from server import db

    desired_slug = slugify(payload.slug or payload.name)
    final_slug = await _ensure_unique_group_slug(db, desired_slug)

    if payload.category_slug:
        cat = await db.categories.find_one({"slug": payload.category_slug}, {"_id": 0, "id": 1})
        if not cat:
            raise HTTPException(status_code=400, detail="Category not found")

    cover = (payload.cover_url or "").strip() or None
    if cover and not (cover.startswith("http://") or cover.startswith("https://")):
        raise HTTPException(status_code=400, detail="Cover URL must start with http(s)://")

    doc = {
        "id": new_id(),
        "slug": final_slug,
        "name": payload.name.strip(),
        "description": payload.description.strip(),
        "cover_url": cover,
        "category_slug": payload.category_slug,
        "creator_id": user["id"],
        "creator_name": user["name"],
        "member_count": 1,
        "post_count": 0,
        "created_at": now_iso(),
    }
    await db.groups.insert_one(doc.copy())

    # Creator auto-joins as member (role = "creator")
    await db.group_memberships.insert_one({
        "id": new_id(),
        "group_id": doc["id"],
        "user_id": user["id"],
        "user_name": user["name"],
        "user_avatar": user.get("avatar_url"),
        "role": "creator",
        "joined_at": now_iso(),
    })
    return _strip(doc)


@router.get("/{slug}")
async def get_group(slug: str):
    from server import db

    g = await db.groups.find_one({"slug": slug}, {"_id": 0})
    if not g:
        raise HTTPException(status_code=404, detail="Group not found")
    return g


@router.patch("/{group_id}")
async def update_group(group_id: str, payload: GroupUpdate, user: dict = Depends(get_current_user)):
    from server import db

    g = await db.groups.find_one({"id": group_id}, {"_id": 0})
    if not g:
        raise HTTPException(status_code=404, detail="Group not found")
    if g["creator_id"] != user["id"] and user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Only the creator or admin can edit")

    update = {k: v for k, v in payload.model_dump(exclude_none=True).items()}
    if "category_slug" in update and update["category_slug"]:
        cat = await db.categories.find_one({"slug": update["category_slug"]}, {"_id": 0, "id": 1})
        if not cat:
            raise HTTPException(status_code=400, detail="Category not found")
    await db.groups.update_one({"id": group_id}, {"$set": update})
    g = await db.groups.find_one({"id": group_id}, {"_id": 0})
    return g


@router.delete("/{group_id}")
async def delete_group(group_id: str, user: dict = Depends(get_current_user)):
    from server import db

    g = await db.groups.find_one({"id": group_id}, {"_id": 0})
    if not g:
        raise HTTPException(status_code=404, detail="Group not found")
    if g["creator_id"] != user["id"] and user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Only the creator or admin can delete")
    await db.groups.delete_one({"id": group_id})
    await db.group_memberships.delete_many({"group_id": group_id})
    await db.group_posts.delete_many({"group_id": group_id})
    return {"message": "Group deleted"}


# ---- Membership ----
@router.post("/{group_id}/join")
async def join_group(group_id: str, user: dict = Depends(get_current_user)):
    from server import db

    g = await db.groups.find_one({"id": group_id}, {"_id": 0})
    if not g:
        raise HTTPException(status_code=404, detail="Group not found")
    existing = await db.group_memberships.find_one({"group_id": group_id, "user_id": user["id"]}, {"_id": 0})
    if existing:
        return {"message": "Already a member", "joined": True}
    await db.group_memberships.insert_one({
        "id": new_id(),
        "group_id": group_id,
        "user_id": user["id"],
        "user_name": user["name"],
        "user_avatar": user.get("avatar_url"),
        "role": "member",
        "joined_at": now_iso(),
    })
    await _recalc_group_counts(db, group_id)
    return {"message": "Joined", "joined": True}


@router.post("/{group_id}/leave")
async def leave_group(group_id: str, user: dict = Depends(get_current_user)):
    from server import db

    g = await db.groups.find_one({"id": group_id}, {"_id": 0})
    if not g:
        raise HTTPException(status_code=404, detail="Group not found")
    if g["creator_id"] == user["id"]:
        raise HTTPException(status_code=400, detail="Creators cannot leave their own group — delete it instead.")
    res = await db.group_memberships.delete_one({"group_id": group_id, "user_id": user["id"]})
    if res.deleted_count == 0:
        return {"message": "Not a member", "joined": False}
    await _recalc_group_counts(db, group_id)
    return {"message": "Left group", "joined": False}


@router.get("/{group_id}/members")
async def list_members(group_id: str):
    from server import db

    members = (
        await db.group_memberships.find({"group_id": group_id}, {"_id": 0})
        .sort([("role", 1), ("joined_at", 1)])
        .to_list(500)
    )
    return members


@router.get("/{group_id}/is-member")
async def is_member(group_id: str, user: dict = Depends(get_current_user)):
    from server import db

    member = await db.group_memberships.find_one({"group_id": group_id, "user_id": user["id"]}, {"_id": 0})
    return {"is_member": bool(member), "role": (member or {}).get("role")}


# ---- Posts ----
@router.get("/{group_id}/posts")
async def list_posts(group_id: str, sort: str = "newest"):
    from server import db

    sort_spec = {
        "newest": [("created_at", -1)],
        "popular": [("likes_count", -1), ("created_at", -1)],
    }.get(sort, [("created_at", -1)])
    posts = await db.group_posts.find({"group_id": group_id}, {"_id": 0}).sort(sort_spec).to_list(500)
    return posts


@router.post("/{group_id}/posts")
async def create_post(group_id: str, payload: PostCreate, user: dict = Depends(get_current_user)):
    from server import db

    g = await db.groups.find_one({"id": group_id}, {"_id": 0})
    if not g:
        raise HTTPException(status_code=404, detail="Group not found")
    if not await _is_member(db, group_id, user["id"]):
        raise HTTPException(status_code=403, detail="Join the group to post")

    post_type = payload.type if payload.type in ("discussion", "recommendation") else "discussion"
    doc = {
        "id": new_id(),
        "group_id": group_id,
        "user_id": user["id"],
        "user_name": user["name"],
        "user_avatar": user.get("avatar_url"),
        "type": post_type,
        "title": payload.title.strip(),
        "body": payload.body.strip(),
        "item_slug": None,
        "item_name": None,
        "item_image": None,
        "item_rating": None,
        "likes_count": 0,
        "liked_user_ids": [],
        "created_at": now_iso(),
    }

    if post_type == "recommendation":
        if not payload.item_slug:
            raise HTTPException(status_code=400, detail="Recommendations require an item_slug")
        item = await db.items.find_one({"slug": payload.item_slug}, {"_id": 0})
        if not item:
            raise HTTPException(status_code=400, detail="Recommended item not found")
        doc["item_slug"] = item["slug"]
        doc["item_name"] = item["name"]
        doc["item_image"] = item.get("image_url")
        doc["item_rating"] = item.get("avg_rating", 0)

    await db.group_posts.insert_one(doc.copy())
    await _recalc_group_counts(db, group_id)
    return _strip(doc)


@router.post("/posts/{post_id}/like")
async def toggle_like(post_id: str, user: dict = Depends(get_current_user)):
    from server import db

    post = await db.group_posts.find_one({"id": post_id}, {"_id": 0})
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    liked = list(post.get("liked_user_ids") or [])
    if user["id"] in liked:
        liked.remove(user["id"])
    else:
        liked.append(user["id"])
    await db.group_posts.update_one({"id": post_id}, {"$set": {"liked_user_ids": liked, "likes_count": len(liked)}})
    post["liked_user_ids"] = liked
    post["likes_count"] = len(liked)
    return post


@router.delete("/posts/{post_id}")
async def delete_post(post_id: str, user: dict = Depends(get_current_user)):
    from server import db

    post = await db.group_posts.find_one({"id": post_id}, {"_id": 0})
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    group = await db.groups.find_one({"id": post["group_id"]}, {"_id": 0})
    is_owner = post["user_id"] == user["id"]
    is_creator = group and group["creator_id"] == user["id"]
    is_admin = user.get("role") == "admin"
    if not (is_owner or is_creator or is_admin):
        raise HTTPException(status_code=403, detail="Not allowed")
    await db.group_posts.delete_one({"id": post_id})
    await _recalc_group_counts(db, post["group_id"])
    return {"message": "Post deleted"}
