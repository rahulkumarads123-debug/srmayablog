"""Notifications — new follower, comment, like, review."""
from typing import List, Optional
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel

from auth import get_current_user
from models import new_id, now_iso

router = APIRouter(prefix="/notifications", tags=["notifications"])


NOTIF_TYPES = {"follow", "like_post", "comment_post", "like_comment", "review", "group_post_like"}


async def create_notification(
    db,
    *,
    recipient_id: str,
    actor_id: str,
    actor_name: str,
    actor_avatar: Optional[str],
    type: str,
    message: str,
    link: str,
    target_type: Optional[str] = None,
    target_id: Optional[str] = None,
):
    """Insert a notification. Never notify self. De-dup on (recipient, actor, type, target)."""
    if recipient_id == actor_id:
        return None
    if type not in NOTIF_TYPES:
        return None

    # De-dup within 24h — avoid spamming for repeated like/unlike toggles.
    existing = await db.notifications.find_one({
        "recipient_id": recipient_id,
        "actor_id": actor_id,
        "type": type,
        "target_type": target_type,
        "target_id": target_id,
    }, {"_id": 0, "id": 1})
    if existing:
        await db.notifications.update_one(
            {"id": existing["id"]},
            {"$set": {"created_at": now_iso(), "read": False, "message": message, "link": link}},
        )
        return existing["id"]

    doc = {
        "id": new_id(),
        "recipient_id": recipient_id,
        "actor_id": actor_id,
        "actor_name": actor_name,
        "actor_avatar": actor_avatar,
        "type": type,
        "message": message,
        "link": link,
        "target_type": target_type,
        "target_id": target_id,
        "read": False,
        "created_at": now_iso(),
    }
    await db.notifications.insert_one(doc.copy())
    return doc["id"]


class MarkReadRequest(BaseModel):
    ids: List[str]


@router.get("")
async def list_notifications(
    limit: int = 20,
    skip: int = 0,
    only_unread: bool = False,
    user: dict = Depends(get_current_user),
):
    from server import db

    q: dict = {"recipient_id": user["id"]}
    if only_unread:
        q["read"] = False
    rows = (
        await db.notifications.find(q, {"_id": 0})
        .sort([("created_at", -1)])
        .skip(skip)
        .limit(limit)
        .to_list(limit)
    )
    total = await db.notifications.count_documents(q)
    unread = await db.notifications.count_documents({"recipient_id": user["id"], "read": False})
    return {"items": rows, "total": total, "unread": unread}


@router.get("/unread-count")
async def unread_count(user: dict = Depends(get_current_user)):
    from server import db

    unread = await db.notifications.count_documents({"recipient_id": user["id"], "read": False})
    return {"unread": unread}


@router.post("/{notif_id}/read")
async def mark_read(notif_id: str, user: dict = Depends(get_current_user)):
    from server import db

    res = await db.notifications.update_one(
        {"id": notif_id, "recipient_id": user["id"]},
        {"$set": {"read": True}},
    )
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Notification not found")
    return {"read": True}


@router.post("/read-all")
async def mark_all_read(user: dict = Depends(get_current_user)):
    from server import db

    res = await db.notifications.update_many(
        {"recipient_id": user["id"], "read": False},
        {"$set": {"read": True}},
    )
    return {"marked": res.modified_count}


@router.delete("/{notif_id}")
async def delete_notification(notif_id: str, user: dict = Depends(get_current_user)):
    from server import db

    res = await db.notifications.delete_one({"id": notif_id, "recipient_id": user["id"]})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Notification not found")
    return {"deleted": True}
