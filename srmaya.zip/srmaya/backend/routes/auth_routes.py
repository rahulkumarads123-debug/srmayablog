"""Auth endpoints."""
import secrets
from fastapi import APIRouter, HTTPException, Request, Response, Depends
from datetime import datetime, timezone, timedelta
from typing import Optional
from pydantic import BaseModel, Field, EmailStr

from auth import (
    hash_password,
    verify_password,
    create_access_token,
    create_refresh_token,
    decode_token,
    set_auth_cookies,
    clear_auth_cookies,
    get_current_user,
)
from models import RegisterRequest, LoginRequest, UserPublic, new_id, now_iso

router = APIRouter(prefix="/auth", tags=["auth"])

VERIFY_TOKEN_TTL_HOURS = 24
RESET_TOKEN_TTL_MINUTES = 60


def _iso_in(minutes: int = 0, hours: int = 0) -> str:
    return (datetime.now(timezone.utc) + timedelta(minutes=minutes, hours=hours)).isoformat()


def _iso_past(iso_str: str) -> bool:
    try:
        return datetime.now(timezone.utc) > datetime.fromisoformat(iso_str)
    except Exception:
        return True


async def _issue_verification_token(db, user_id: str, email: str) -> str:
    token = secrets.token_urlsafe(32)
    await db.email_verification_tokens.delete_many({"user_id": user_id})
    await db.email_verification_tokens.insert_one({
        "id": new_id(),
        "user_id": user_id,
        "email": email,
        "token": token,
        "expires_at": _iso_in(hours=VERIFY_TOKEN_TTL_HOURS),
        "used": False,
        "created_at": now_iso(),
    })
    return token


async def _issue_reset_token(db, user_id: str, email: str) -> str:
    token = secrets.token_urlsafe(32)
    await db.password_reset_tokens.delete_many({"user_id": user_id, "used": False})
    await db.password_reset_tokens.insert_one({
        "id": new_id(),
        "user_id": user_id,
        "email": email,
        "token": token,
        "expires_at": _iso_in(minutes=RESET_TOKEN_TTL_MINUTES),
        "used": False,
        "created_at": now_iso(),
    })
    return token



def _strip_user(user: dict) -> dict:
    user.pop("_id", None)
    user.pop("password_hash", None)
    return user


@router.post("/register")
async def register(payload: RegisterRequest, response: Response):
    from server import db

    email = payload.email.lower().strip()
    existing = await db.users.find_one({"email": email})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    user_doc = {
        "id": new_id(),
        "email": email,
        "name": payload.name.strip(),
        "password_hash": hash_password(payload.password),
        "role": "user",
        "avatar_url": None,
        "bio": None,
        "email_verified": False,
        "email_verified_at": None,
        "created_at": now_iso(),
    }
    await db.users.insert_one(user_doc.copy())

    # Issue verification token — since we don't have a real email provider yet,
    # we return the token directly to the client so it can complete the flow.
    token = await _issue_verification_token(db, user_doc["id"], email)

    access = create_access_token(user_doc["id"], user_doc["email"], user_doc["role"])
    refresh = create_refresh_token(user_doc["id"])
    set_auth_cookies(response, access, refresh)

    out = UserPublic(**user_doc).model_dump()
    out["verification_token"] = token  # dev-mode hint; safe to strip when email provider is wired
    return out


@router.post("/login", response_model=UserPublic)
async def login(payload: LoginRequest, response: Response):
    from server import db

    email = payload.email.lower().strip()
    user = await db.users.find_one({"email": email})
    if not user or not verify_password(payload.password, user.get("password_hash", "")):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    access = create_access_token(user["id"], user["email"], user.get("role", "user"))
    refresh = create_refresh_token(user["id"])
    set_auth_cookies(response, access, refresh)

    return UserPublic(**_strip_user(user))


@router.post("/logout")
async def logout(response: Response):
    clear_auth_cookies(response)
    return {"message": "Logged out"}


@router.get("/me", response_model=UserPublic)
async def me(user: dict = Depends(get_current_user)):
    return UserPublic(**user)


class UpdateMeRequest(BaseModel):
    name: Optional[str] = Field(default=None, min_length=2, max_length=80)
    avatar_url: Optional[str] = Field(default=None, max_length=800)
    bio: Optional[str] = Field(default=None, max_length=500)


@router.patch("/me", response_model=UserPublic)
async def update_me(payload: UpdateMeRequest, user: dict = Depends(get_current_user)):
    from server import db

    update = {k: v for k, v in payload.model_dump(exclude_none=True).items()}
    if not update:
        raise HTTPException(status_code=400, detail="No fields to update")
    await db.users.update_one({"id": user["id"]}, {"$set": update})
    fresh = await db.users.find_one({"id": user["id"]}, {"_id": 0, "password_hash": 0})
    return UserPublic(**fresh)


@router.post("/refresh")
async def refresh(request: Request, response: Response):
    from server import db

    refresh_token = request.cookies.get("refresh_token")
    if not refresh_token:
        raise HTTPException(status_code=401, detail="No refresh token")
    try:
        payload = decode_token(refresh_token)
        if payload.get("type") != "refresh":
            raise HTTPException(status_code=401, detail="Invalid token type")
        user = await db.users.find_one({"id": payload["sub"]}, {"_id": 0, "password_hash": 0})
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        access = create_access_token(user["id"], user["email"], user.get("role", "user"))
        new_refresh = create_refresh_token(user["id"])
        set_auth_cookies(response, access, new_refresh)
        return {"message": "Refreshed"}
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid refresh token")


# ---------- Email verification ----------
@router.post("/verify/send")
async def send_verification(user: dict = Depends(get_current_user)):
    """Issue a fresh verification token. In production this would email it; today it returns it."""
    from server import db

    if user.get("email_verified"):
        return {"already_verified": True}

    # Rate limit: at most 3 new tokens per 15 min
    cutoff = _iso_in(minutes=-15)
    recent = await db.email_verification_tokens.count_documents({
        "user_id": user["id"], "created_at": {"$gte": cutoff}
    })
    if recent >= 3:
        raise HTTPException(status_code=429, detail="Too many verification requests. Try again in 15 minutes.")

    token = await _issue_verification_token(db, user["id"], user["email"])
    # Dev mode: return the token so the frontend can auto-fill or expose a click-through link
    return {"sent": True, "token": token, "message": "Verification token issued."}


class VerifyRequest(BaseModel):
    token: str


@router.post("/verify/confirm")
async def confirm_verification(payload: VerifyRequest):
    from server import db

    row = await db.email_verification_tokens.find_one({"token": payload.token}, {"_id": 0})
    if not row:
        raise HTTPException(status_code=400, detail="Invalid verification link")
    if row.get("used"):
        raise HTTPException(status_code=400, detail="This link has already been used")
    if _iso_past(row["expires_at"]):
        raise HTTPException(status_code=400, detail="This verification link has expired. Request a new one.")

    verified_at = now_iso()
    await db.users.update_one(
        {"id": row["user_id"]},
        {"$set": {"email_verified": True, "email_verified_at": verified_at}},
    )
    await db.email_verification_tokens.update_one(
        {"id": row["id"]}, {"$set": {"used": True, "used_at": verified_at}}
    )
    user = await db.users.find_one({"id": row["user_id"]}, {"_id": 0, "password_hash": 0})
    return {"verified": True, "user": user}


# ---------- Forgot / reset password ----------
class ForgotPasswordRequest(BaseModel):
    email: EmailStr


@router.post("/password/forgot")
async def forgot_password(payload: ForgotPasswordRequest):
    """Never reveal whether an email exists. Always return the same message."""
    from server import db

    email = payload.email.lower().strip()
    user = await db.users.find_one({"email": email}, {"_id": 0})

    # Rate limit — max 5 reset requests per 30 min per email
    cutoff = _iso_in(minutes=-30)
    recent = await db.password_reset_tokens.count_documents({
        "email": email, "created_at": {"$gte": cutoff}
    })
    generic = {
        "sent": True,
        "message": "If an account exists for that email, a password reset link was issued.",
    }
    if recent >= 5:
        return generic

    if user:
        token = await _issue_reset_token(db, user["id"], email)
        # Dev mode: return the token so the frontend can show or auto-open the reset URL
        generic["token"] = token
    return generic


class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str = Field(min_length=6, max_length=100)


@router.post("/password/reset")
async def reset_password(payload: ResetPasswordRequest, response: Response):
    from server import db

    row = await db.password_reset_tokens.find_one({"token": payload.token}, {"_id": 0})
    if not row:
        raise HTTPException(status_code=400, detail="Invalid or already-used reset link")
    if row.get("used"):
        raise HTTPException(status_code=400, detail="This reset link has already been used")
    if _iso_past(row["expires_at"]):
        raise HTTPException(status_code=400, detail="This reset link has expired. Please request a new one.")

    new_hash = hash_password(payload.new_password)
    await db.users.update_one(
        {"id": row["user_id"]}, {"$set": {"password_hash": new_hash}}
    )
    await db.password_reset_tokens.update_one(
        {"id": row["id"]}, {"$set": {"used": True, "used_at": now_iso()}}
    )
    # Invalidate any other outstanding reset tokens for this user
    await db.password_reset_tokens.update_many(
        {"user_id": row["user_id"], "used": False},
        {"$set": {"used": True, "used_at": now_iso()}},
    )
    return {"reset": True, "message": "Password updated. You can now sign in with the new password."}
