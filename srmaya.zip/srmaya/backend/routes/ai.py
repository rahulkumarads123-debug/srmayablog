"""AI review summary endpoint using Emergent LLM key + Claude Sonnet 4.5."""
import os
from fastapi import APIRouter, HTTPException

router = APIRouter(prefix="/ai", tags=["ai"])


@router.post("/summary/{item_id}")
async def summarize_reviews(item_id: str):
    from server import db

    item = await db.items.find_one({"id": item_id}, {"_id": 0})
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")

    reviews = (
        await db.reviews.find(
            {"item_id": item_id, "reported": {"$ne": True}}, {"_id": 0}
        )
        .sort([("helpful_count", -1)])
        .to_list(20)
    )
    if not reviews:
        return {"summary": "No reviews yet to summarize.", "based_on": 0}

    # Cache check
    cache = await db.ai_summaries.find_one({"item_id": item_id}, {"_id": 0})
    if cache and cache.get("review_count") == len(reviews):
        return {"summary": cache["summary"], "based_on": len(reviews), "cached": True}

    bullet_reviews = "\n".join(
        [
            f"- ({r['rating']}/5) {r['title']}: {r['body'][:400]}" for r in reviews[:15]
        ]
    )
    prompt = f"""Summarize the following user reviews for "{item['name']}" into a concise, balanced summary.

Format the response in 3 short paragraphs:
1. Overall sentiment (1 sentence)
2. What users love (key positives, max 2 sentences)
3. Common complaints (key negatives, max 2 sentences)

Keep it neutral, factual, and under 120 words. Do not include star ratings.

Reviews:
{bullet_reviews}
"""

    summary = ""
    try:
        from emergentintegrations.llm.chat import LlmChat, UserMessage

        api_key = os.environ["EMERGENT_LLM_KEY"]
        chat = LlmChat(
            api_key=api_key,
            session_id=f"summary-{item_id}",
            system_message="You are a concise, neutral review summarization assistant.",
        ).with_model("anthropic", "claude-sonnet-4-5-20250929")

        msg = UserMessage(text=prompt)
        response = await chat.send_message(msg)
        summary = (response or "").strip()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"AI summary failed: {e}")

    await db.ai_summaries.update_one(
        {"item_id": item_id},
        {"$set": {"item_id": item_id, "summary": summary, "review_count": len(reviews)}},
        upsert=True,
    )
    return {"summary": summary, "based_on": len(reviews), "cached": False}
