"""Review endpoints."""
from fastapi import APIRouter, HTTPException, Depends
from typing import List, Optional

from models import Review, ReviewCreate, new_id, now_iso
from auth import get_current_user, require_admin, require_verified
from routes.notifications import create_notification

router = APIRouter(tags=["reviews"])


async def _recompute_item_stats(db, item_id: str):
    pipeline = [
        {"$match": {"item_id": item_id, "reported": {"$ne": True}}},
        {
            "$group": {
                "_id": "$rating",
                "count": {"$sum": 1},
            }
        },
    ]
    breakdown = {"1": 0, "2": 0, "3": 0, "4": 0, "5": 0}
    total = 0
    rating_sum = 0
    helpful_sum = 0
    async for row in await db.reviews.aggregate(pipeline):
        breakdown[str(row["_id"])] = row["count"]
        total += row["count"]
        rating_sum += row["_id"] * row["count"]

    avg = (rating_sum / total) if total else 0.0

    helpful_cursor = await db.reviews.aggregate([
        {"$match": {"item_id": item_id}},
        {"$group": {"_id": None, "h": {"$sum": "$helpful_count"}}},
    ])
    helpful_total = await helpful_cursor.to_list(1)
    if helpful_total:
        helpful_sum = helpful_total[0].get("h", 0)

    trending_score = (avg * total) + (helpful_sum * 0.5)

    await db.items.update_one(
        {"id": item_id},
        {
            "$set": {
                "avg_rating": round(avg, 2),
                "review_count": total,
                "rating_breakdown": breakdown,
                "trending_score": round(trending_score, 2),
            }
        },
    )


@router.get("/items/{item_id}/reviews", response_model=List[Review])
async def list_reviews(item_id: str, sort: str = "newest"):
    from server import db

    sort_map = {
        "newest": [("created_at", -1)],
        "oldest": [("created_at", 1)],
        "helpful": [("helpful_count", -1)],
        "highest": [("rating", -1)],
        "lowest": [("rating", 1)],
    }
    spec = sort_map.get(sort, sort_map["newest"])
    reviews = (
        await db.reviews.find({"item_id": item_id, "reported": {"$ne": True}}, {"_id": 0})
        .sort(spec)
        .to_list(500)
    )
    return reviews


@router.post("/items/{item_id}/reviews", response_model=Review)
async def create_review(
    item_id: str, payload: ReviewCreate, user: dict = Depends(require_verified)
):
    from server import db

    item = await db.items.find_one({"id": item_id}, {"_id": 0})
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")

    existing = await db.reviews.find_one({"item_id": item_id, "user_id": user["id"]})
    if existing:
        raise HTTPException(status_code=400, detail="You already reviewed this item")

    doc = Review(
        id=new_id(),
        item_id=item_id,
        item_slug=item["slug"],
        item_name=item["name"],
        user_id=user["id"],
        user_name=user["name"],
        user_avatar=user.get("avatar_url"),
        rating=payload.rating,
        title=payload.title,
        body=payload.body,
        pros=payload.pros,
        cons=payload.cons,
        verified=False,
        created_at=now_iso(),
    ).model_dump()

    await db.reviews.insert_one(doc.copy())
    await _recompute_item_stats(db, item_id)

    # Notify original submitter (if any) that someone reviewed their listing
    submission = await db.user_submissions.find_one(
        {"approved_item_id": item_id, "status": "approved"},
        {"_id": 0, "user_id": 1},
    )
    if submission and submission.get("user_id"):
        await create_notification(
            db,
            recipient_id=submission["user_id"],
            actor_id=user["id"],
            actor_name=user["name"],
            actor_avatar=user.get("avatar_url"),
            type="review",
            message=f"{user['name']} reviewed your listing “{item['name']}”.",
            link=f"/item/{item['slug']}",
            target_type="item",
            target_id=item["id"],
        )
    return doc


@router.post("/reviews/{review_id}/helpful", response_model=Review)
async def toggle_helpful(review_id: str, user: dict = Depends(get_current_user)):
    from server import db

    review = await db.reviews.find_one({"id": review_id}, {"_id": 0})
    if not review:
        raise HTTPException(status_code=404, detail="Review not found")

    helpful_users = review.get("helpful_user_ids", [])
    if user["id"] in helpful_users:
        helpful_users.remove(user["id"])
    else:
        helpful_users.append(user["id"])

    await db.reviews.update_one(
        {"id": review_id},
        {"$set": {"helpful_user_ids": helpful_users, "helpful_count": len(helpful_users)}},
    )
    await _recompute_item_stats(db, review["item_id"])
    review["helpful_user_ids"] = helpful_users
    review["helpful_count"] = len(helpful_users)
    return review


@router.post("/reviews/{review_id}/report")
async def report_review(review_id: str, user: dict = Depends(get_current_user)):
    from server import db

    res = await db.reviews.update_one({"id": review_id}, {"$set": {"reported": True}})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Review not found")
    return {"message": "Review reported"}


@router.delete("/reviews/{review_id}")
async def delete_review(review_id: str, user: dict = Depends(get_current_user)):
    from server import db

    review = await db.reviews.find_one({"id": review_id}, {"_id": 0})
    if not review:
        raise HTTPException(status_code=404, detail="Review not found")
    if review["user_id"] != user["id"] and user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Not allowed")
    await db.reviews.delete_one({"id": review_id})
    await _recompute_item_stats(db, review["item_id"])
    return {"message": "Review deleted"}


@router.get("/users/me/reviews", response_model=List[Review])
async def my_reviews(user: dict = Depends(get_current_user)):
    from server import db

    reviews = (
        await db.reviews.find({"user_id": user["id"]}, {"_id": 0})
        .sort([("created_at", -1)])
        .to_list(500)
    )
    return reviews
