"""Cast & Crew (film professionals) database + autocomplete + film filmography."""
import re
from typing import List, Optional
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field

from auth import get_current_user, require_admin, get_optional_user
from models import new_id, now_iso

router = APIRouter(prefix="/cast", tags=["cast"])

SLUG_RE = re.compile(r"[^a-z0-9]+")


def slugify(text: str) -> str:
    text = (text or "").strip().lower()
    text = SLUG_RE.sub("-", text)
    return text.strip("-") or "person"


async def _ensure_unique_slug(db, base: str, exclude_id: Optional[str] = None) -> str:
    slug = base
    n = 1
    while True:
        q = {"slug": slug}
        if exclude_id:
            q["id"] = {"$ne": exclude_id}
        clash = await db.cast_members.find_one(q, {"_id": 0, "id": 1})
        if not clash:
            return slug
        n += 1
        slug = f"{base}-{n}"


class CastCreate(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    profession: Optional[str] = None
    bio: Optional[str] = Field(default=None, max_length=2000)
    photo_url: Optional[str] = None
    date_of_birth: Optional[str] = None
    place_of_birth: Optional[str] = None
    social_links: Optional[dict] = None


class CastUpdate(BaseModel):
    name: Optional[str] = None
    profession: Optional[str] = None
    bio: Optional[str] = Field(default=None, max_length=2000)
    photo_url: Optional[str] = None
    date_of_birth: Optional[str] = None
    place_of_birth: Optional[str] = None
    social_links: Optional[dict] = None


def _strip(doc: dict) -> dict:
    doc.pop("_id", None)
    return doc


@router.get("")
async def list_or_search(q: str = "", limit: int = 20):
    """Autocomplete search — case-insensitive partial name match."""
    from server import db

    limit = max(1, min(limit, 50))
    query: dict = {}
    if q.strip():
        # Escape regex special chars
        pattern = re.escape(q.strip())
        query["name"] = {"$regex": pattern, "$options": "i"}
    rows = (
        await db.cast_members.find(query, {"_id": 0})
        .sort([("name", 1)])
        .limit(limit)
        .to_list(limit)
    )
    return rows


@router.get("/{slug}")
async def get_by_slug(slug: str):
    """Public profile page — returns person + filmography."""
    from server import db

    person = await db.cast_members.find_one({"slug": slug}, {"_id": 0})
    if not person:
        raise HTTPException(status_code=404, detail="Person not found")

    # Filmography: any item whose metadata.cast_members includes this cast_id
    films = await db.items.find(
        {"metadata.cast_members.cast_id": person["id"]},
        {"_id": 0, "id": 1, "slug": 1, "name": 1, "image_url": 1, "avg_rating": 1, "category_slug": 1, "category_name": 1, "metadata": 1},
    ).to_list(200)

    # Extract this person's role in each film
    filmography = []
    for f in films:
        members = (f.get("metadata") or {}).get("cast_members") or []
        for m in members:
            if m.get("cast_id") == person["id"]:
                filmography.append({
                    "item_id": f["id"],
                    "item_slug": f["slug"],
                    "item_name": f["name"],
                    "item_image": f.get("image_url"),
                    "item_rating": f.get("avg_rating", 0),
                    "category_slug": f.get("category_slug"),
                    "role": m.get("role"),
                    "character": m.get("character"),
                })
                break

    filmography.sort(key=lambda x: -(x.get("item_rating") or 0))
    return {"person": person, "filmography": filmography}


@router.post("")
async def create_person(payload: CastCreate, user: dict = Depends(get_current_user)):
    """Any signed-in user can create a person; admins can edit/delete."""
    from server import db

    name = payload.name.strip()
    # Duplicate prevention on name (case-insensitive)
    existing = await db.cast_members.find_one(
        {"name": {"$regex": f"^{re.escape(name)}$", "$options": "i"}},
        {"_id": 0},
    )
    if existing:
        return existing  # Return existing so caller can link to it — better UX than 400

    slug = await _ensure_unique_slug(db, slugify(name))
    doc = {
        "id": new_id(),
        "slug": slug,
        "name": name,
        "profession": (payload.profession or "").strip() or None,
        "bio": (payload.bio or "").strip() or None,
        "photo_url": (payload.photo_url or "").strip() or None,
        "date_of_birth": payload.date_of_birth,
        "place_of_birth": payload.place_of_birth,
        "social_links": payload.social_links or {},
        "created_by": user["id"],
        "created_at": now_iso(),
        "updated_at": now_iso(),
    }
    await db.cast_members.insert_one(doc.copy())
    return _strip(doc)


@router.patch("/{cast_id}")
async def update_person(cast_id: str, payload: CastUpdate, _admin=Depends(require_admin)):
    from server import db

    update = {k: v for k, v in payload.model_dump(exclude_none=True).items()}
    if not update:
        raise HTTPException(status_code=400, detail="No fields to update")
    update["updated_at"] = now_iso()
    if "name" in update:
        base = slugify(update["name"])
        update["slug"] = await _ensure_unique_slug(db, base, exclude_id=cast_id)
    res = await db.cast_members.update_one({"id": cast_id}, {"$set": update})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Person not found")
    doc = await db.cast_members.find_one({"id": cast_id}, {"_id": 0})
    return doc


@router.delete("/{cast_id}")
async def delete_person(cast_id: str, _admin=Depends(require_admin)):
    from server import db

    res = await db.cast_members.delete_one({"id": cast_id})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Person not found")
    # Do NOT delete cast_members references from items — orphaned refs won't hurt reads.
    return {"deleted": True}


class MergeRequest(BaseModel):
    source_id: str
    target_id: str


@router.post("/merge")
async def merge_persons(payload: MergeRequest, _admin=Depends(require_admin)):
    """Merge source into target: rewrites every item's cast_members entry, then deletes source."""
    from server import db

    if payload.source_id == payload.target_id:
        raise HTTPException(status_code=400, detail="Cannot merge a person with themselves")
    src = await db.cast_members.find_one({"id": payload.source_id}, {"_id": 0})
    tgt = await db.cast_members.find_one({"id": payload.target_id}, {"_id": 0})
    if not src or not tgt:
        raise HTTPException(status_code=404, detail="Source or target not found")

    # Rewrite items
    affected = 0
    async for it in db.items.find({"metadata.cast_members.cast_id": payload.source_id}):
        members = (it.get("metadata") or {}).get("cast_members") or []
        new_members = []
        for m in members:
            if m.get("cast_id") == payload.source_id:
                m["cast_id"] = payload.target_id
                m["name"] = tgt["name"]
                m["photo_url"] = tgt.get("photo_url")
            new_members.append(m)
        await db.items.update_one(
            {"id": it["id"]},
            {"$set": {"metadata.cast_members": new_members}},
        )
        affected += 1

    await db.cast_members.delete_one({"id": payload.source_id})
    return {"merged": True, "items_updated": affected}
