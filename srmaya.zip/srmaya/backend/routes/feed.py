"""Personal social feed — text posts, likes, threaded comments, save, repost."""
import re
from datetime import datetime, timezone, timedelta
from typing import List, Optional

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field

from auth import get_current_user, get_optional_user, require_verified
from models import new_id, now_iso
from routes.notifications import create_notification

router = APIRouter(prefix="/feed", tags=["feed"])

HASHTAG_RE = re.compile(r"#([A-Za-z0-9_]{2,40})")
MENTION_RE = re.compile(r"@([A-Za-z0-9_.]{2,40})")


def _extract_hashtags(body: str) -> List[str]:
    return list({m.lower() for m in HASHTAG_RE.findall(body or "")})


def _extract_mentions(body: str) -> List[str]:
    return list({m for m in MENTION_RE.findall(body or "")})


# ---- Models ----
class PostCreate(BaseModel):
    body: str = Field(min_length=1, max_length=4000)
    image_url: Optional[str] = None
    link_url: Optional[str] = None
    repost_of: Optional[str] = None


class CommentCreate(BaseModel):
    body: str = Field(min_length=1, max_length=2000)
    parent_comment_id: Optional[str] = None


def _strip(doc: dict) -> dict:
    doc.pop("_id", None)
    return doc


# ---- Posts ----
@router.get("")
async def list_feed(
    sort: str = "latest",
    user_id: Optional[str] = None,
    hashtag: Optional[str] = None,
    user: Optional[dict] = Depends(get_optional_user),
):
    from server import db

    query: dict = {}
    if user_id:
        query["user_id"] = user_id
    if hashtag:
        query["hashtags"] = hashtag.lower().lstrip("#")

    if sort == "following":
        if not user:
            raise HTTPException(status_code=401, detail="Sign in to view following feed")
        following = await db.follows.find({"follower_id": user["id"]}, {"_id": 0}).to_list(2000)
        ids = [f["following_id"] for f in following] + [user["id"]]
        query["user_id"] = {"$in": ids}
        sort_spec = [("created_at", -1)]
    elif sort == "trending":
        # Posts from the last 7 days, sorted by likes + comments
        cutoff = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()
        query.setdefault("created_at", {})
        query["created_at"]["$gte"] = cutoff
        sort_spec = [("likes_count", -1), ("comments_count", -1), ("created_at", -1)]
    else:
        sort_spec = [("created_at", -1)]

    posts = await db.feed_posts.find(query, {"_id": 0}).sort(sort_spec).to_list(80)

    # Pre-populate "liked_by_me" + "saved_by_me" flags for the requesting user
    me_id = user["id"] if user else None
    for p in posts:
        liked = p.get("liked_user_ids") or []
        saved = p.get("saved_user_ids") or []
        p["liked_by_me"] = me_id in liked
        p["saved_by_me"] = me_id in saved
        # don't leak the full user-id arrays
        p.pop("liked_user_ids", None)
        p.pop("saved_user_ids", None)
    return posts


@router.get("/saved")
async def saved_posts(user: dict = Depends(get_current_user)):
    from server import db

    posts = await db.feed_posts.find({"saved_user_ids": user["id"]}, {"_id": 0}).sort([("created_at", -1)]).to_list(200)
    for p in posts:
        p["liked_by_me"] = user["id"] in (p.get("liked_user_ids") or [])
        p["saved_by_me"] = True
        p.pop("liked_user_ids", None)
        p.pop("saved_user_ids", None)
    return posts


@router.get("/hashtags/trending")
async def trending_hashtags(limit: int = 10):
    from server import db

    cutoff = (datetime.now(timezone.utc) - timedelta(days=14)).isoformat()
    pipeline = [
        {"$match": {"created_at": {"$gte": cutoff}, "hashtags": {"$exists": True, "$ne": []}}},
        {"$unwind": "$hashtags"},
        {"$group": {"_id": "$hashtags", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
        {"$limit": limit},
    ]
    tags = []
    async for row in await db.feed_posts.aggregate(pipeline):
        tags.append({"tag": row["_id"], "count": row["count"]})
    return tags


@router.post("/posts")
async def create_post(payload: PostCreate, user: dict = Depends(require_verified)):
    from server import db

    body = payload.body.strip()
    if not body:
        raise HTTPException(status_code=400, detail="Empty post")

    image_url = (payload.image_url or "").strip() or None
    link_url = (payload.link_url or "").strip() or None
    if image_url and not (image_url.startswith("http://") or image_url.startswith("https://")):
        raise HTTPException(status_code=400, detail="Image URL must start with http(s)://")
    if link_url and not (link_url.startswith("http://") or link_url.startswith("https://")):
        raise HTTPException(status_code=400, detail="Link URL must start with http(s)://")

    repost_source = None
    if payload.repost_of:
        source = await db.feed_posts.find_one({"id": payload.repost_of}, {"_id": 0})
        if not source:
            raise HTTPException(status_code=404, detail="Original post not found")
        repost_source = {
            "id": source["id"],
            "user_id": source["user_id"],
            "user_name": source["user_name"],
            "user_avatar": source.get("user_avatar"),
            "body": source["body"],
            "image_url": source.get("image_url"),
            "created_at": source["created_at"],
        }

    doc = {
        "id": new_id(),
        "user_id": user["id"],
        "user_name": user["name"],
        "user_avatar": user.get("avatar_url"),
        "body": body,
        "image_url": image_url,
        "link_url": link_url,
        "hashtags": _extract_hashtags(body),
        "mentions": _extract_mentions(body),
        "likes_count": 0,
        "liked_user_ids": [],
        "comments_count": 0,
        "saved_user_ids": [],
        "repost_count": 0,
        "repost_of": repost_source,
        "created_at": now_iso(),
    }
    await db.feed_posts.insert_one(doc.copy())

    if repost_source:
        await db.feed_posts.update_one({"id": repost_source["id"]}, {"$inc": {"repost_count": 1}})

    out = _strip(doc)
    out["liked_by_me"] = False
    out["saved_by_me"] = False
    out.pop("liked_user_ids", None)
    out.pop("saved_user_ids", None)
    return out


@router.get("/posts/{post_id}")
async def get_post(post_id: str, user: Optional[dict] = Depends(get_optional_user)):
    from server import db

    p = await db.feed_posts.find_one({"id": post_id}, {"_id": 0})
    if not p:
        raise HTTPException(status_code=404, detail="Post not found")
    me_id = user["id"] if user else None
    p["liked_by_me"] = me_id in (p.get("liked_user_ids") or [])
    p["saved_by_me"] = me_id in (p.get("saved_user_ids") or [])
    p.pop("liked_user_ids", None)
    p.pop("saved_user_ids", None)
    return p


@router.delete("/posts/{post_id}")
async def delete_post(post_id: str, user: dict = Depends(get_current_user)):
    from server import db

    p = await db.feed_posts.find_one({"id": post_id}, {"_id": 0})
    if not p:
        raise HTTPException(status_code=404, detail="Post not found")
    if p["user_id"] != user["id"] and user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Not allowed")
    await db.feed_posts.delete_one({"id": post_id})
    await db.feed_comments.delete_many({"post_id": post_id})
    return {"message": "Post deleted"}


@router.post("/posts/{post_id}/like")
async def toggle_post_like(post_id: str, user: dict = Depends(get_current_user)):
    from server import db

    p = await db.feed_posts.find_one({"id": post_id}, {"_id": 0})
    if not p:
        raise HTTPException(status_code=404, detail="Post not found")
    liked = list(p.get("liked_user_ids") or [])
    if user["id"] in liked:
        liked.remove(user["id"])
        liked_by_me = False
    else:
        liked.append(user["id"])
        liked_by_me = True
    await db.feed_posts.update_one(
        {"id": post_id},
        {"$set": {"liked_user_ids": liked, "likes_count": len(liked)}},
    )
    if liked_by_me:
        await create_notification(
            db,
            recipient_id=p["user_id"],
            actor_id=user["id"],
            actor_name=user["name"],
            actor_avatar=user.get("avatar_url"),
            type="like_post",
            message=f"{user['name']} liked your post.",
            link=f"/feed",
            target_type="feed_post",
            target_id=post_id,
        )
    return {"liked_by_me": liked_by_me, "likes_count": len(liked)}


@router.post("/posts/{post_id}/save")
async def toggle_post_save(post_id: str, user: dict = Depends(get_current_user)):
    from server import db

    p = await db.feed_posts.find_one({"id": post_id}, {"_id": 0})
    if not p:
        raise HTTPException(status_code=404, detail="Post not found")
    saved = list(p.get("saved_user_ids") or [])
    if user["id"] in saved:
        saved.remove(user["id"])
        saved_by_me = False
    else:
        saved.append(user["id"])
        saved_by_me = True
    await db.feed_posts.update_one(
        {"id": post_id}, {"$set": {"saved_user_ids": saved}}
    )
    return {"saved_by_me": saved_by_me}


# ---- Comments (threaded one level) ----
@router.get("/posts/{post_id}/comments")
async def list_comments(post_id: str, user: Optional[dict] = Depends(get_optional_user)):
    from server import db

    comments = await db.feed_comments.find({"post_id": post_id}, {"_id": 0}).sort([("created_at", 1)]).to_list(1000)
    me_id = user["id"] if user else None
    for c in comments:
        c["liked_by_me"] = me_id in (c.get("liked_user_ids") or [])
        c.pop("liked_user_ids", None)
    return comments


@router.post("/posts/{post_id}/comments")
async def add_comment(post_id: str, payload: CommentCreate, user: dict = Depends(require_verified)):
    from server import db

    p = await db.feed_posts.find_one({"id": post_id}, {"_id": 0, "id": 1, "user_id": 1})
    if not p:
        raise HTTPException(status_code=404, detail="Post not found")
    if payload.parent_comment_id:
        parent = await db.feed_comments.find_one(
            {"id": payload.parent_comment_id, "post_id": post_id}, {"_id": 0, "id": 1}
        )
        if not parent:
            raise HTTPException(status_code=404, detail="Parent comment not found")

    doc = {
        "id": new_id(),
        "post_id": post_id,
        "user_id": user["id"],
        "user_name": user["name"],
        "user_avatar": user.get("avatar_url"),
        "body": payload.body.strip(),
        "parent_comment_id": payload.parent_comment_id,
        "likes_count": 0,
        "liked_user_ids": [],
        "created_at": now_iso(),
    }
    await db.feed_comments.insert_one(doc.copy())
    total = await db.feed_comments.count_documents({"post_id": post_id})
    await db.feed_posts.update_one({"id": post_id}, {"$set": {"comments_count": total}})

    await create_notification(
        db,
        recipient_id=p["user_id"],
        actor_id=user["id"],
        actor_name=user["name"],
        actor_avatar=user.get("avatar_url"),
        type="comment_post",
        message=f"{user['name']} commented on your post.",
        link=f"/feed",
        target_type="feed_post",
        target_id=post_id,
    )

    out = _strip(doc)
    out["liked_by_me"] = False
    out.pop("liked_user_ids", None)
    return out


@router.delete("/comments/{comment_id}")
async def delete_comment(comment_id: str, user: dict = Depends(get_current_user)):
    from server import db

    c = await db.feed_comments.find_one({"id": comment_id}, {"_id": 0})
    if not c:
        raise HTTPException(status_code=404, detail="Comment not found")
    if c["user_id"] != user["id"] and user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Not allowed")
    await db.feed_comments.delete_one({"id": comment_id})
    # Cascade delete replies
    await db.feed_comments.delete_many({"parent_comment_id": comment_id})
    total = await db.feed_comments.count_documents({"post_id": c["post_id"]})
    await db.feed_posts.update_one({"id": c["post_id"]}, {"$set": {"comments_count": total}})
    return {"message": "Deleted"}


@router.post("/comments/{comment_id}/like")
async def toggle_comment_like(comment_id: str, user: dict = Depends(get_current_user)):
    from server import db

    c = await db.feed_comments.find_one({"id": comment_id}, {"_id": 0})
    if not c:
        raise HTTPException(status_code=404, detail="Comment not found")
    liked = list(c.get("liked_user_ids") or [])
    if user["id"] in liked:
        liked.remove(user["id"])
        liked_by_me = False
    else:
        liked.append(user["id"])
        liked_by_me = True
    await db.feed_comments.update_one(
        {"id": comment_id}, {"$set": {"liked_user_ids": liked, "likes_count": len(liked)}}
    )
    return {"liked_by_me": liked_by_me, "likes_count": len(liked)}


# ---- Public user profile aggregator ----
@router.get("/users/{user_id}/profile")
async def user_profile(user_id: str, user: Optional[dict] = Depends(get_optional_user)):
    from server import db

    target = await db.users.find_one({"id": user_id}, {"_id": 0, "password_hash": 0})
    if not target:
        raise HTTPException(status_code=404, detail="User not found")

    followers = await db.follows.count_documents({"following_id": user_id})
    following = await db.follows.count_documents({"follower_id": user_id})
    posts_count = await db.feed_posts.count_documents({"user_id": user_id})
    reviews_count = await db.reviews.count_documents({"user_id": user_id})

    is_following = False
    if user and user["id"] != user_id:
        existing = await db.follows.find_one(
            {"follower_id": user["id"], "following_id": user_id}, {"_id": 0, "id": 1}
        )
        is_following = bool(existing)

    return {
        "user": target,
        "stats": {
            "followers": followers,
            "following": following,
            "posts": posts_count,
            "reviews": reviews_count,
        },
        "is_following": is_following,
        "is_self": bool(user and user["id"] == user_id),
    }
