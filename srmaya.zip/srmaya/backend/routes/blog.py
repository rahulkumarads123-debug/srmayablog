"""Editorial blog — admin authored, public reading, logged-in likes."""
from typing import List, Optional
import re

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field

from auth import get_current_user, get_optional_user, require_admin
from models import new_id, now_iso

router = APIRouter(prefix="/blog", tags=["blog"])

SLUG_RE = re.compile(r"[^a-z0-9]+")


def slugify(text: str) -> str:
    s = SLUG_RE.sub("-", (text or "").lower()).strip("-")
    return s or "post"


# ---- Models ----
class BlogCreate(BaseModel):
    title: str = Field(min_length=4, max_length=160)
    slug: Optional[str] = None
    excerpt: str = Field(min_length=10, max_length=300)
    body: str = Field(min_length=20)
    cover_url: Optional[str] = None
    tag: str = Field(default="General", max_length=40)  # primary tag
    published: bool = True


class BlogUpdate(BaseModel):
    title: Optional[str] = None
    excerpt: Optional[str] = None
    body: Optional[str] = None
    cover_url: Optional[str] = None
    tag: Optional[str] = None
    published: Optional[bool] = None


def _strip(doc: dict) -> dict:
    doc.pop("_id", None)
    return doc


async def _unique_blog_slug(db, slug: str) -> str:
    base, n = slug, 1
    while await db.blog_posts.find_one({"slug": slug}, {"_id": 0, "id": 1}):
        n += 1
        slug = f"{base}-{n}"
    return slug


# ---- Public ----
@router.get("")
async def list_posts(
    q: Optional[str] = None,
    tag: Optional[str] = None,
    include_drafts: bool = False,
    limit: int = 24,
    user: Optional[dict] = Depends(get_optional_user),
):
    from server import db

    query = {}
    if not (include_drafts and user and user.get("role") == "admin"):
        query["published"] = True
    if tag:
        query["tag"] = tag
    if q:
        query["$or"] = [
            {"title": {"$regex": q, "$options": "i"}},
            {"excerpt": {"$regex": q, "$options": "i"}},
            {"body": {"$regex": q, "$options": "i"}},
        ]
    posts = await db.blog_posts.find(query, {"_id": 0}).sort([("created_at", -1)]).to_list(limit)
    return posts


@router.get("/tags")
async def list_tags():
    from server import db

    tags = await db.blog_posts.distinct("tag", {"published": True})
    return sorted([t for t in tags if t])


@router.get("/{slug}")
async def get_post(slug: str, user: Optional[dict] = Depends(get_optional_user)):
    from server import db

    post = await db.blog_posts.find_one({"slug": slug}, {"_id": 0})
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    if not post.get("published") and (not user or user.get("role") != "admin"):
        raise HTTPException(status_code=404, detail="Post not found")
    # Bump view count (best-effort)
    await db.blog_posts.update_one({"id": post["id"]}, {"$inc": {"views": 1}})
    post["views"] = (post.get("views") or 0) + 1
    return post


@router.post("/{post_id}/like")
async def toggle_like(post_id: str, user: dict = Depends(get_current_user)):
    from server import db

    post = await db.blog_posts.find_one({"id": post_id}, {"_id": 0})
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    liked = list(post.get("liked_user_ids") or [])
    if user["id"] in liked:
        liked.remove(user["id"])
    else:
        liked.append(user["id"])
    await db.blog_posts.update_one({"id": post_id}, {"$set": {"liked_user_ids": liked, "likes_count": len(liked)}})
    post["liked_user_ids"] = liked
    post["likes_count"] = len(liked)
    return post


# ---- Admin ----
@router.post("")
async def create_post(payload: BlogCreate, _admin: dict = Depends(require_admin)):
    from server import db

    slug = slugify(payload.slug or payload.title)
    final = await _unique_blog_slug(db, slug)
    cover = (payload.cover_url or "").strip() or None
    if cover and not (cover.startswith("http://") or cover.startswith("https://")):
        raise HTTPException(status_code=400, detail="Cover URL must start with http(s)://")
    doc = {
        "id": new_id(),
        "slug": final,
        "title": payload.title.strip(),
        "excerpt": payload.excerpt.strip(),
        "body": payload.body,
        "cover_url": cover,
        "tag": (payload.tag or "General").strip() or "General",
        "author_id": _admin["id"],
        "author_name": _admin["name"],
        "author_avatar": _admin.get("avatar_url"),
        "published": bool(payload.published),
        "views": 0,
        "likes_count": 0,
        "liked_user_ids": [],
        "created_at": now_iso(),
        "updated_at": now_iso(),
    }
    await db.blog_posts.insert_one(doc.copy())
    return _strip(doc)


@router.patch("/{post_id}")
async def update_post(post_id: str, payload: BlogUpdate, _admin: dict = Depends(require_admin)):
    from server import db

    update = {k: v for k, v in payload.model_dump(exclude_none=True).items()}
    if not update:
        raise HTTPException(status_code=400, detail="No fields to update")
    update["updated_at"] = now_iso()
    res = await db.blog_posts.update_one({"id": post_id}, {"$set": update})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Post not found")
    post = await db.blog_posts.find_one({"id": post_id}, {"_id": 0})
    return post


@router.delete("/{post_id}")
async def delete_post(post_id: str, _admin: dict = Depends(require_admin)):
    from server import db

    res = await db.blog_posts.delete_one({"id": post_id})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Post not found")
    return {"message": "Deleted"}
