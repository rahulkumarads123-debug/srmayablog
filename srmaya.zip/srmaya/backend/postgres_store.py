"""Small async PostgreSQL-backed document adapter for the existing API layer.

Each API resource has its own PostgreSQL table and JSONB payload. SQL filters,
updates, uniqueness, and search indexes are used by the adapter; JSONB keeps
the app's category-specific metadata flexible while routes retain their current
response shapes.
"""

import json
import os
import re
from copy import deepcopy
from types import SimpleNamespace

import asyncpg


COLLECTIONS = {
    "ai_summaries", "blog_posts", "cast_members", "categories",
    "email_verification_tokens", "feed_comments", "feed_posts", "files",
    "follows", "group_memberships", "group_posts", "groups", "items",
    "notifications", "password_reset_tokens", "reviews", "users",
    "user_submissions",
}
FIELD_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _path(field):
    parts = field.split(".")
    if not all(FIELD_RE.fullmatch(part) for part in parts):
        raise ValueError(f"Unsupported database field path: {field}")
    return parts


def _get_path(document, field):
    parts = _path(field)

    def read(value, rest):
        if not rest:
            return value
        if isinstance(value, list):
            return [result for item in value for result in [read(item, rest)] if result is not _MISSING]
        if not isinstance(value, dict) or rest[0] not in value:
            return _MISSING
        return read(value[rest[0]], rest[1:])

    return read(document, parts)


_MISSING = object()


def _set_path(document, field, value):
    parts = _path(field)
    current = document
    for part in parts[:-1]:
        child = current.get(part)
        if not isinstance(child, dict):
            child = {}
            current[part] = child
        current = child
    current[parts[-1]] = value


def _equal(actual, expected):
    if actual is _MISSING:
        return False
    if isinstance(actual, list) and not isinstance(expected, list):
        return any(_equal(item, expected) for item in actual)
    if isinstance(actual, dict) and isinstance(expected, dict):
        return all(key in actual and _equal(actual[key], value) for key, value in expected.items())
    return actual == expected


def _matches(document, query):
    for field, condition in (query or {}).items():
        if field == "$or":
            if not any(_matches(document, item) for item in condition):
                return False
            continue
        if field == "$and":
            if not all(_matches(document, item) for item in condition):
                return False
            continue

        actual = _get_path(document, field)
        if not isinstance(condition, dict) or not any(key.startswith("$") for key in condition):
            if not _equal(actual, condition):
                return False
            continue

        options = condition.get("$options", "")
        for operator, expected in condition.items():
            if operator == "$options":
                continue
            if operator == "$exists":
                if (actual is not _MISSING) != bool(expected):
                    return False
            elif operator == "$eq":
                if not _equal(actual, expected):
                    return False
            elif operator == "$ne":
                if _equal(actual, expected):
                    return False
            elif operator == "$in":
                if not any(_equal(actual, item) for item in expected):
                    return False
            elif operator == "$nin":
                if any(_equal(actual, item) for item in expected):
                    return False
            elif operator == "$gte":
                if actual is _MISSING or actual < expected:
                    return False
            elif operator == "$gt":
                if actual is _MISSING or actual <= expected:
                    return False
            elif operator == "$lte":
                if actual is _MISSING or actual > expected:
                    return False
            elif operator == "$lt":
                if actual is _MISSING or actual >= expected:
                    return False
            elif operator == "$regex":
                pattern = re.compile(expected, re.IGNORECASE if "i" in options else 0)
                values = actual if isinstance(actual, list) else [actual]
                if not any(isinstance(value, str) and pattern.search(value) for value in values):
                    return False
            else:
                raise NotImplementedError(f"Unsupported query operator: {operator}")
    return True


def _project(document, projection):
    if not projection:
        return deepcopy(document)
    included = {key for key, enabled in projection.items() if enabled and key != "_id"}
    excluded = {key for key, enabled in projection.items() if not enabled and key != "_id"}
    if included:
        result = {}
        for field in included:
            value = _get_path(document, field)
            if value is not _MISSING:
                _set_path(result, field, deepcopy(value))
        return result
    result = deepcopy(document)
    for field in excluded:
        parts = _path(field)
        target = result
        for part in parts[:-1]:
            target = target.get(part, {}) if isinstance(target, dict) else {}
        if isinstance(target, dict):
            target.pop(parts[-1], None)
    return result


class SQLCursor:
    def __init__(self, collection, query=None, projection=None):
        self.collection = collection
        self.query = query or {}
        self.projection = projection
        self.sort_spec = []
        self.offset = 0
        self.max_rows = None

    def sort(self, specification, direction=None):
        if isinstance(specification, str):
            specification = [(specification, direction or 1)]
        self.sort_spec = list(specification)
        return self

    def skip(self, count):
        self.offset = max(0, int(count))
        return self

    def limit(self, count):
        self.max_rows = max(0, int(count))
        return self

    async def to_list(self, length=None):
        limit = self.max_rows
        if length is not None:
            limit = int(length) if limit is None else min(limit, int(length))
        return await self.collection._select(
            self.query, self.projection, self.sort_spec, self.offset, limit
        )

    def __aiter__(self):
        return self._iterate()

    async def _iterate(self):
        for row in await self.to_list():
            yield row


class AggregateCursor:
    def __init__(self, rows):
        self.rows = rows
        self.max_rows = None

    def sort(self, specification, direction=None):
        spec = [(specification, direction or 1)] if isinstance(specification, str) else specification
        for field, order in reversed(spec):
            self.rows.sort(key=lambda row: (_get_path(row, field) is _MISSING, _get_path(row, field)), reverse=order < 0)
        return self

    def limit(self, count):
        self.max_rows = count
        return self

    def skip(self, count):
        self.rows = self.rows[count:]
        return self

    async def to_list(self, length=None):
        rows = self.rows if self.max_rows is None else self.rows[: self.max_rows]
        if length is not None:
            rows = rows[:length]
        return deepcopy(rows)

    def __aiter__(self):
        return self._iterate()

    async def _iterate(self):
        for row in await self.to_list():
            yield row


class SQLCollection:
    def __init__(self, database, name):
        self.database = database
        self.name = name
        self.table = f'"public"."{name}"'

    @property
    def pool(self):
        if self.database.pool is None:
            raise RuntimeError("PostgreSQL is not connected")
        return self.database.pool

    def _compile_filter(self, query, args):
        clauses = []

        def parameter(value):
            args.append(json.dumps(value, separators=(",", ":"), ensure_ascii=False))
            return f"${len(args)}::jsonb"

        def field_expr(field):
            parts = _path(field)
            args.append(parts)
            return f"(data #> ${len(args)}::text[])"

        def jsonpath_match(field, value, mode="eq"):
            parts = _path(field)
            # JSONPath wildcards let a dotted Mongo path traverse embedded arrays.
            path = "$"
            for index, part in enumerate(parts):
                path += f".{part}"
                if index < len(parts) - 1:
                    path += "[*]"
            if mode == "regex":
                path += ' ? (@ like_regex $v flag "i")'
                var_name = "v"
                var_value = json.dumps(str(value))
            else:
                path += " ? (@ == $v)"
                var_name = "v"
                var_value = json.dumps(value, separators=(",", ":"), ensure_ascii=False)
            args.extend([path, json.dumps({var_name: json.loads(var_value)}, separators=(",", ":"), ensure_ascii=False)])
            return f"jsonb_path_exists(data, ${len(args)-1}::jsonpath, ${len(args)}::jsonb)"

        def equality(field, value):
            expr = field_expr(field)
            val = parameter(value)
            direct = f"({expr} = {val} OR {expr} @> jsonb_build_array({val}))"
            return f"({direct} OR {jsonpath_match(field, value)})"

        for field, condition in (query or {}).items():
            if field == "$or":
                clauses.append("(" + " OR ".join(self._compile_filter(item, args) for item in condition) + ")")
                continue
            if field == "$and":
                clauses.append("(" + " AND ".join(self._compile_filter(item, args) for item in condition) + ")")
                continue
            if not isinstance(condition, dict) or not any(key.startswith("$") for key in condition):
                clauses.append(equality(field, condition))
                continue
            for operator, expected in condition.items():
                if operator == "$options":
                    continue
                if operator == "$exists":
                    expr = field_expr(field)
                    clauses.append(f"({expr} IS {'NOT ' if expected else ''}NULL)")
                elif operator in ("$eq", "$ne", "$in", "$nin"):
                    values = expected if operator in ("$in", "$nin") else [expected]
                    alternatives = [equality(field, value) for value in values]
                    positive = "(" + " OR ".join(alternatives or ["FALSE"]) + ")"
                    if operator in ("$ne", "$nin"):
                        expr = field_expr(field)
                        clauses.append(f"({expr} IS NULL OR NOT {positive})")
                    else:
                        clauses.append(positive)
                elif operator in ("$gte", "$gt", "$lte", "$lt"):
                    expr = field_expr(field)
                    sql_operator = {"$gte": ">=", "$gt": ">", "$lte": "<=", "$lt": "<"}[operator]
                    clauses.append(f"({expr} {sql_operator} {parameter(expected)})")
                elif operator == "$regex":
                    options = condition.get("$options", "")
                    regex_expr = f"(data #>> ${len(args)+1}::text[])"
                    args.append(_path(field))
                    args.append(expected)
                    clauses.append(f"({regex_expr} {'~*' if 'i' in options else '~'} ${len(args)})")
                    clauses[-1] = f"({clauses[-1]} OR {jsonpath_match(field, expected, 'regex')})"
                else:
                    raise NotImplementedError(f"Unsupported query operator: {operator}")

        return " AND ".join(clauses) if clauses else "TRUE"

    async def _select(self, query, projection, sort_spec, offset, limit):
        args = []
        where = self._compile_filter(query, args)
        sql = f"SELECT data FROM {self.table} WHERE {where}"
        if sort_spec:
            order_by = []
            for field, direction in sort_spec:
                expr = field_expr = _path(field)
                args.append(field_expr)
                order_by.append(f"(data #> ${len(args)}::text[]) {'DESC' if direction < 0 else 'ASC'}")
            sql += " ORDER BY " + ", ".join(order_by)
        if limit is not None:
            args.append(max(0, int(limit)))
            sql += f" LIMIT ${len(args)}"
        if offset:
            args.append(max(0, int(offset)))
            sql += f" OFFSET ${len(args)}"
        rows = await self.pool.fetch(sql, *args)
        documents = [json.loads(row["data"]) if isinstance(row["data"], str) else row["data"] for row in rows]
        return [_project(document, projection) for document in documents]

    def find(self, query=None, projection=None):
        return SQLCursor(self, query, projection)

    async def find_one(self, query=None, projection=None, sort=None):
        cursor = self.find(query, projection)
        if sort:
            cursor.sort(sort)
        rows = await cursor.to_list(1)
        return rows[0] if rows else None

    async def insert_one(self, document):
        doc = deepcopy(document)
        if not doc.get("id"):
            raise ValueError(f"{self.name} records must have an id")
        await self.pool.execute(
            f"INSERT INTO {self.table} (id, data) VALUES ($1, $2::jsonb)",
            str(doc["id"]), json.dumps(doc, ensure_ascii=False, separators=(",", ":")),
        )
        return SimpleNamespace(inserted_id=doc["id"])

    async def count_documents(self, query=None):
        args = []
        where = self._compile_filter(query, args)
        return await self.pool.fetchval(f"SELECT COUNT(*) FROM {self.table} WHERE {where}", *args)

    async def _matching_documents(self, query, for_update=False):
        args = []
        where = self._compile_filter(query, args)
        sql = f"SELECT id, data FROM {self.table} WHERE {where}"
        if for_update:
            sql += " FOR UPDATE"
        rows = await self.pool.fetch(sql, *args)
        return [(row["id"], json.loads(row["data"]) if isinstance(row["data"], str) else row["data"]) for row in rows]

    @staticmethod
    def _apply_update(document, update, inserting=False):
        changed = False
        for field, value in update.get("$set", {}).items():
            if _get_path(document, field) != value:
                _set_path(document, field, deepcopy(value))
                changed = True
        for field, value in update.get("$setOnInsert", {}).items():
            if inserting:
                _set_path(document, field, deepcopy(value))
                changed = True
        for field, amount in update.get("$inc", {}).items():
            current = _get_path(document, field)
            current = 0 if current is _MISSING or current is None else current
            _set_path(document, field, current + amount)
            changed = True
        for field in update.get("$unset", {}):
            parts = _path(field)
            target = document
            for part in parts[:-1]:
                target = target.get(part, {}) if isinstance(target, dict) else {}
            if isinstance(target, dict) and parts[-1] in target:
                target.pop(parts[-1])
                changed = True
        return changed

    async def update_one(self, query, update, upsert=False):
        async with self.pool.acquire() as connection:
            async with connection.transaction():
                args = []
                where = self._compile_filter(query, args)
                row = await connection.fetchrow(
                    f"SELECT id, data FROM {self.table} WHERE {where} LIMIT 1 FOR UPDATE", *args
                )
                if row:
                    document = json.loads(row["data"]) if isinstance(row["data"], str) else row["data"]
                    modified = self._apply_update(document, update)
                    if modified:
                        await connection.execute(
                            f"UPDATE {self.table} SET data = $2::jsonb WHERE id = $1",
                            row["id"], json.dumps(document, ensure_ascii=False, separators=(",", ":")),
                        )
                    return SimpleNamespace(matched_count=1, modified_count=int(modified), upserted_id=None)
                if not upsert:
                    return SimpleNamespace(matched_count=0, modified_count=0, upserted_id=None)
                document = {}
                for field, value in query.items():
                    if not field.startswith("$") and not (isinstance(value, dict) and any(k.startswith("$") for k in value)):
                        _set_path(document, field, deepcopy(value))
                self._apply_update(document, update, inserting=True)
                if not document.get("id"):
                    import uuid
                    document["id"] = str(uuid.uuid4())
                await connection.execute(
                    f"INSERT INTO {self.table} (id, data) VALUES ($1, $2::jsonb)",
                    str(document["id"]), json.dumps(document, ensure_ascii=False, separators=(",", ":")),
                )
                return SimpleNamespace(matched_count=0, modified_count=0, upserted_id=document["id"])

    async def update_many(self, query, update):
        async with self.pool.acquire() as connection:
            async with connection.transaction():
                args = []
                where = self._compile_filter(query, args)
                rows = await connection.fetch(f"SELECT id, data FROM {self.table} WHERE {where} FOR UPDATE", *args)
                updates = []
                for row in rows:
                    document = json.loads(row["data"]) if isinstance(row["data"], str) else row["data"]
                    if self._apply_update(document, update):
                        updates.append((row["id"], json.dumps(document, ensure_ascii=False, separators=(",", ":"))))
                if updates:
                    await connection.executemany(
                        f"UPDATE {self.table} SET data = $2::jsonb WHERE id = $1", updates
                    )
                return SimpleNamespace(matched_count=len(rows), modified_count=len(updates))

    async def delete_one(self, query):
        args = []
        where = self._compile_filter(query, args)
        status = await self.pool.execute(f"DELETE FROM {self.table} WHERE id IN (SELECT id FROM {self.table} WHERE {where} LIMIT 1)", *args)
        return SimpleNamespace(deleted_count=int(status.split()[-1]))

    async def delete_many(self, query):
        args = []
        where = self._compile_filter(query, args)
        status = await self.pool.execute(f"DELETE FROM {self.table} WHERE {where}", *args)
        return SimpleNamespace(deleted_count=int(status.split()[-1]))

    async def distinct(self, field, query=None):
        rows = await self.find(query).to_list()
        values = []
        for row in rows:
            value = _get_path(row, field)
            items = value if isinstance(value, list) else [value]
            for item in items:
                if item is not _MISSING and item not in values:
                    values.append(item)
        return values

    async def aggregate(self, pipeline):
        rows = await self.find().to_list()
        for stage in pipeline:
            name, value = next(iter(stage.items()))
            if name == "$match":
                rows = [row for row in rows if _matches(row, value)]
            elif name == "$unwind":
                field = value.lstrip("$")
                expanded = []
                for row in rows:
                    items = _get_path(row, field)
                    if isinstance(items, list):
                        for item in items:
                            copy = deepcopy(row)
                            _set_path(copy, field, item)
                            expanded.append(copy)
                    elif items is not _MISSING and items is not None:
                        expanded.append(row)
                rows = expanded
            elif name == "$lookup":
                foreign = await getattr(self.database, value["from"]).find().to_list()
                joined = []
                for row in rows:
                    local = _get_path(row, value["localField"])
                    matches = [item for item in foreign if _equal(_get_path(item, value["foreignField"]), local)]
                    copy = deepcopy(row)
                    copy[value["as"]] = matches
                    joined.append(copy)
                rows = joined
            elif name == "$group":
                groups = {}
                for row in rows:
                    group_id = _expression(row, value.get("_id"))
                    key = json.dumps(group_id, sort_keys=True, default=str)
                    if key not in groups:
                        groups[key] = {"_id": group_id}
                        for output, expression in value.items():
                            if output != "_id":
                                groups[key][output] = 0.0 if "$avg" in expression else 0
                                if "$avg" in expression:
                                    groups[key][f"__count_{output}"] = 0
                    group = groups[key]
                    for output, expression in value.items():
                        if output == "_id":
                            continue
                        if "$sum" in expression:
                            operand = expression["$sum"]
                            group[output] += 1 if operand == 1 else (_expression(row, operand) or 0)
                        elif "$avg" in expression:
                            result = _expression(row, expression["$avg"])
                            if result is not None:
                                count_key = f"__count_{output}"
                                group[output] += result
                                group[count_key] += 1
                rows = list(groups.values())
                for group in rows:
                    for key in list(group):
                        if key.startswith("__count_"):
                            output = key.removeprefix("__count_")
                            group[output] = group[output] / group[key] if group[key] else None
                            del group[key]
            elif name == "$sort":
                for field, order in reversed(list(value.items())):
                    rows.sort(key=lambda row: (_expression(row, f"${field}") is None, _expression(row, f"${field}")), reverse=order < 0)
            elif name == "$limit":
                rows = rows[:value]
            else:
                raise NotImplementedError(f"Unsupported aggregation stage: {name}")
        return AggregateCursor(rows)


def _expression(document, expression):
    if isinstance(expression, str) and expression.startswith("$"):
        value = _get_path(document, expression[1:])
        return None if value is _MISSING else value
    return expression


class SQLDatabase:
    def __init__(self):
        self.pool = None

    async def connect(self):
        database_url = os.environ.get("DATABASE_URL")
        if not database_url:
            raise RuntimeError("DATABASE_URL is missing; enable the Replit PostgreSQL database.")
        self.pool = await asyncpg.create_pool(database_url, min_size=1, max_size=8)
        await self.pool.fetchval("SELECT 1")

    async def close(self):
        if self.pool is not None:
            await self.pool.close()
            self.pool = None

    def __getattr__(self, name):
        if name not in COLLECTIONS:
            raise AttributeError(name)
        return SQLCollection(self, name)