-- Development schema for the Replit-managed PostgreSQL database.
-- Tables are created by the configured post-merge setup script, never by app startup.
CREATE TABLE IF NOT EXISTS ai_summaries (id text PRIMARY KEY, data jsonb NOT NULL);
CREATE TABLE IF NOT EXISTS blog_posts (id text PRIMARY KEY, data jsonb NOT NULL);
CREATE TABLE IF NOT EXISTS cast_members (id text PRIMARY KEY, data jsonb NOT NULL);
CREATE TABLE IF NOT EXISTS categories (id text PRIMARY KEY, data jsonb NOT NULL);
CREATE TABLE IF NOT EXISTS email_verification_tokens (id text PRIMARY KEY, data jsonb NOT NULL);
CREATE TABLE IF NOT EXISTS feed_comments (id text PRIMARY KEY, data jsonb NOT NULL);
CREATE TABLE IF NOT EXISTS feed_posts (id text PRIMARY KEY, data jsonb NOT NULL);
CREATE TABLE IF NOT EXISTS files (id text PRIMARY KEY, data jsonb NOT NULL);
CREATE TABLE IF NOT EXISTS follows (id text PRIMARY KEY, data jsonb NOT NULL);
CREATE TABLE IF NOT EXISTS group_memberships (id text PRIMARY KEY, data jsonb NOT NULL);
CREATE TABLE IF NOT EXISTS group_posts (id text PRIMARY KEY, data jsonb NOT NULL);
CREATE TABLE IF NOT EXISTS groups (id text PRIMARY KEY, data jsonb NOT NULL);
CREATE TABLE IF NOT EXISTS items (id text PRIMARY KEY, data jsonb NOT NULL);
CREATE TABLE IF NOT EXISTS notifications (id text PRIMARY KEY, data jsonb NOT NULL);
CREATE TABLE IF NOT EXISTS password_reset_tokens (id text PRIMARY KEY, data jsonb NOT NULL);
CREATE TABLE IF NOT EXISTS reviews (id text PRIMARY KEY, data jsonb NOT NULL);
CREATE TABLE IF NOT EXISTS users (id text PRIMARY KEY, data jsonb NOT NULL);
CREATE TABLE IF NOT EXISTS user_submissions (id text PRIMARY KEY, data jsonb NOT NULL);

CREATE UNIQUE INDEX IF NOT EXISTS users_email_unique ON users ((data->>'email'));
CREATE UNIQUE INDEX IF NOT EXISTS categories_slug_unique ON categories ((data->>'slug'));
CREATE UNIQUE INDEX IF NOT EXISTS items_slug_unique ON items ((data->>'slug'));
CREATE UNIQUE INDEX IF NOT EXISTS groups_slug_unique ON groups ((data->>'slug'));
CREATE UNIQUE INDEX IF NOT EXISTS blog_posts_slug_unique ON blog_posts ((data->>'slug'));
CREATE UNIQUE INDEX IF NOT EXISTS cast_members_slug_unique ON cast_members ((data->>'slug'));
CREATE UNIQUE INDEX IF NOT EXISTS verification_token_unique
    ON email_verification_tokens ((data->>'token'));
CREATE UNIQUE INDEX IF NOT EXISTS password_reset_token_unique
    ON password_reset_tokens ((data->>'token'));
CREATE UNIQUE INDEX IF NOT EXISTS group_membership_unique
    ON group_memberships ((data->>'group_id'), (data->>'user_id'));
CREATE UNIQUE INDEX IF NOT EXISTS follow_pair_unique
    ON follows ((data->>'follower_id'), (data->>'following_id'));

CREATE INDEX IF NOT EXISTS items_category_idx ON items ((data->>'category_slug'));
CREATE INDEX IF NOT EXISTS reviews_item_idx ON reviews ((data->>'item_id'));
CREATE INDEX IF NOT EXISTS reviews_user_idx ON reviews ((data->>'user_id'));
CREATE INDEX IF NOT EXISTS group_posts_group_idx ON group_posts ((data->>'group_id'));
CREATE INDEX IF NOT EXISTS feed_posts_created_idx ON feed_posts ((data->>'created_at') DESC);
CREATE INDEX IF NOT EXISTS feed_posts_user_idx ON feed_posts ((data->>'user_id'));
CREATE INDEX IF NOT EXISTS feed_comments_post_idx ON feed_comments ((data->>'post_id'));
CREATE INDEX IF NOT EXISTS notifications_recipient_created_idx
    ON notifications ((data->>'recipient_id'), (data->>'created_at') DESC);
CREATE INDEX IF NOT EXISTS notifications_recipient_read_idx
    ON notifications ((data->>'recipient_id'), (data->>'read'));
CREATE INDEX IF NOT EXISTS cast_members_name_idx ON cast_members ((data->>'name'));