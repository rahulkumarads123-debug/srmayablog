import { useRef, useState } from "react";
import api, { formatApiError } from "@/lib/api";
import { Upload, Loader2, X, Link as LinkIcon, ImageIcon } from "lucide-react";
import { toast } from "sonner";

const BACKEND_URL =
  process.env.NODE_ENV === "development"
    ? ""
    : process.env.REACT_APP_BACKEND_URL || "";

function toAbsoluteUrl(u) {
  if (!u) return "";
  if (u.startsWith("http://") || u.startsWith("https://")) return u;
  if (u.startsWith("/api/")) return `${BACKEND_URL}${u}`;
  return u;
}

/**
 * ImageUploader
 * - Drag-and-drop or click-to-browse file upload backed by /api/uploads/image
 * - Optional URL-paste fallback (allowUrl=true)
 * - Emits the resulting URL (absolute or /api/uploads/file/... path) via onChange
 * - Displays a preview when value is present
 *
 * Props:
 *   value: string          current URL
 *   onChange(url): void    called with the new URL (or "" when cleared)
 *   aspect: string         tailwind aspect class, default "aspect-video"
 *   size: "sm" | "md"      controls preview height on non-aspect layouts
 *   allowUrl: boolean      show a "Paste URL" fallback tab (default true)
 *   testId: string         data-testid prefix
 *   label: string          optional small label above the uploader
 *   circular: boolean      render a circular preview (avatar mode)
 */
export default function ImageUploader({
  value,
  onChange,
  aspect = "aspect-video",
  allowUrl = true,
  testId = "image-uploader",
  label,
  circular = false,
}) {
  const inputRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [mode, setMode] = useState("upload"); // "upload" | "url"
  const [urlDraft, setUrlDraft] = useState(value || "");

  const uploadFile = async (file) => {
    if (!file) return;
    if (!file.type?.startsWith("image/")) {
      toast.error("Only image files are supported (JPG, PNG, WEBP, GIF).");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      toast.error("File is too large — max 10 MB.");
      return;
    }
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const { data } = await api.post("/uploads/image", fd, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      onChange?.(data.url);
      toast.success("Image uploaded.");
    } catch (err) {
      toast.error(formatApiError(err.response?.data?.detail) || "Upload failed");
    } finally {
      setUploading(false);
    }
  };

  const onDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    const f = e.dataTransfer.files?.[0];
    if (f) uploadFile(f);
  };

  const clear = () => {
    onChange?.("");
    setUrlDraft("");
  };

  const previewSrc = toAbsoluteUrl(value);
  const previewClass = circular
    ? "aspect-square rounded-full"
    : aspect;

  return (
    <div className="space-y-2" data-testid={testId}>
      {label && (
        <div className="text-xs font-bold uppercase tracking-[0.2em] text-zinc-500">{label}</div>
      )}
      {value ? (
        <div className={`relative overflow-hidden bg-zinc-100 border border-zinc-200 ${previewClass}`}>
          <img
            src={previewSrc}
            alt=""
            className="w-full h-full object-cover"
            onError={(e) => { e.currentTarget.style.opacity = "0.3"; }}
            data-testid={`${testId}-preview`}
          />
          <button
            type="button"
            onClick={clear}
            className="absolute top-2 right-2 bg-white/90 hover:bg-red-600 hover:text-white text-zinc-700 p-1.5 shadow-sm transition-colors"
            aria-label="Remove image"
            data-testid={`${testId}-clear`}
          >
            <X size={13} />
          </button>
        </div>
      ) : (
        <>
          {allowUrl && (
            <div className="flex gap-1 text-[10px] font-bold uppercase tracking-[0.15em]">
              <button
                type="button"
                onClick={() => setMode("upload")}
                className={`px-2.5 py-1 transition-colors ${mode === "upload" ? "bg-zinc-900 text-white" : "bg-zinc-100 hover:bg-zinc-200"}`}
                data-testid={`${testId}-mode-upload`}
              >
                <Upload size={10} className="inline mr-1" /> Upload
              </button>
              <button
                type="button"
                onClick={() => setMode("url")}
                className={`px-2.5 py-1 transition-colors ${mode === "url" ? "bg-zinc-900 text-white" : "bg-zinc-100 hover:bg-zinc-200"}`}
                data-testid={`${testId}-mode-url`}
              >
                <LinkIcon size={10} className="inline mr-1" /> Paste URL
              </button>
            </div>
          )}
          {mode === "upload" ? (
            <div
              onClick={() => !uploading && inputRef.current?.click()}
              onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={onDrop}
              className={`${previewClass} border-2 border-dashed grid place-items-center cursor-pointer transition-colors ${
                dragging ? "border-blue-600 bg-blue-50" : "border-zinc-300 hover:border-zinc-900 bg-zinc-50"
              }`}
              role="button"
              tabIndex={0}
              data-testid={`${testId}-dropzone`}
            >
              <div className="text-center px-4">
                {uploading ? (
                  <>
                    <Loader2 size={22} className="mx-auto mb-2 animate-spin text-blue-600" />
                    <div className="text-xs font-mono uppercase tracking-[0.15em] text-zinc-500">Uploading...</div>
                  </>
                ) : (
                  <>
                    <ImageIcon size={22} className="mx-auto mb-2 text-zinc-400" />
                    <div className="text-xs font-semibold text-zinc-700">Drop image or click to browse</div>
                    <div className="text-[10px] font-mono uppercase tracking-[0.15em] text-zinc-400 mt-1">
                      JPG · PNG · WEBP · GIF · Max 10 MB
                    </div>
                  </>
                )}
              </div>
              <input
                ref={inputRef}
                type="file"
                accept="image/jpeg,image/png,image/webp,image/gif"
                className="hidden"
                onChange={(e) => uploadFile(e.target.files?.[0])}
                data-testid={`${testId}-file-input`}
              />
            </div>
          ) : (
            <div className="flex gap-2">
              <input
                type="url"
                value={urlDraft}
                onChange={(e) => setUrlDraft(e.target.value)}
                placeholder="https://..."
                className="flex-1 bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2 text-xs font-mono outline-none focus:ring-2 focus:ring-blue-600"
                data-testid={`${testId}-url-input`}
              />
              <button
                type="button"
                onClick={() => { if (urlDraft.trim()) onChange?.(urlDraft.trim()); }}
                className="bg-zinc-900 text-white px-3 py-2 text-xs font-bold uppercase tracking-[0.15em] hover:bg-blue-600 transition-colors"
                data-testid={`${testId}-url-apply`}
              >
                Use
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export { toAbsoluteUrl };
