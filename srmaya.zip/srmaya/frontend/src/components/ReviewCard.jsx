import StarRating from "./StarRating";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ThumbsUp, Flag, BadgeCheck, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { Link } from "react-router-dom";

function formatDate(iso) {
  try {
    const d = new Date(iso);
    return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  } catch {
    return "";
  }
}

export default function ReviewCard({ review, onHelpful, onReport, onDelete, showItemLink = false }) {
  const { user } = useAuth();
  const isOwner = user && typeof user === "object" && user.id === review.user_id;
  const isAdmin = user && typeof user === "object" && user.role === "admin";
  const helpfulPressed = user && typeof user === "object" && (review.helpful_user_ids || []).includes(user.id);
  const initials = review.user_name?.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();

  return (
    <article
      className="border-b border-zinc-200 py-8 fade-up"
      data-testid={`review-${review.id}`}
    >
      <div className="flex justify-between items-start gap-4 mb-4">
        <div className="flex items-center gap-3">
          <Avatar className="h-10 w-10 rounded-none">
            <AvatarImage src={review.user_avatar} />
            <AvatarFallback className="rounded-none bg-zinc-900 text-white text-xs font-semibold">
              {initials || "U"}
            </AvatarFallback>
          </Avatar>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-sm text-zinc-900">{review.user_name}</span>
              {review.verified && (
                <span className="inline-flex items-center gap-1 bg-green-50 text-green-800 text-[10px] font-semibold uppercase tracking-wide px-1.5 py-0.5">
                  <BadgeCheck size={11} /> Verified
                </span>
              )}
            </div>
            <div className="text-xs text-zinc-500 font-mono">
              {formatDate(review.created_at)}
              {showItemLink && (
                <>
                  {" · "}
                  <Link to={`/item/${review.item_slug}`} className="text-zinc-700 hover:text-blue-600">
                    {review.item_name}
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <StarRating value={review.rating} size={16} />
          <span className="font-bold text-sm">{review.rating}.0</span>
        </div>
      </div>

      <h4 className="font-display font-bold text-lg tracking-tight leading-tight mb-2">
        {review.title}
      </h4>
      <p className="text-zinc-700 leading-relaxed mb-4 whitespace-pre-line">{review.body}</p>

      {(review.pros?.length > 0 || review.cons?.length > 0) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5">
          {review.pros?.length > 0 && (
            <div className="border-l-2 border-green-500 pl-4">
              <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-green-700 mb-2">Pros</div>
              <ul className="text-sm text-zinc-700 space-y-1">
                {review.pros.map((p, i) => <li key={i}>+ {p}</li>)}
              </ul>
            </div>
          )}
          {review.cons?.length > 0 && (
            <div className="border-l-2 border-red-500 pl-4">
              <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-red-700 mb-2">Cons</div>
              <ul className="text-sm text-zinc-700 space-y-1">
                {review.cons.map((c, i) => <li key={i}>− {c}</li>)}
              </ul>
            </div>
          )}
        </div>
      )}

      <div className="flex items-center gap-2 text-sm text-zinc-500">
        <Button
          size="sm"
          variant="outline"
          onClick={() => onHelpful?.(review)}
          className={`rounded-none border-zinc-200 hover:border-zinc-900 ${helpfulPressed ? "bg-zinc-900 text-white border-zinc-900" : ""}`}
          data-testid={`review-helpful-${review.id}`}
        >
          <ThumbsUp size={13} className="mr-1.5" /> Helpful · {review.helpful_count || 0}
        </Button>
        <Button
          size="sm"
          variant="ghost"
          onClick={() => onReport?.(review)}
          className="rounded-none text-zinc-500 hover:text-red-600"
          data-testid={`review-report-${review.id}`}
        >
          <Flag size={13} className="mr-1.5" /> Report
        </Button>
        {(isOwner || isAdmin) && onDelete && (
          <Button
            size="sm"
            variant="ghost"
            onClick={() => onDelete(review)}
            className="rounded-none text-zinc-500 hover:text-red-600 ml-auto"
            data-testid={`review-delete-${review.id}`}
          >
            <Trash2 size={13} className="mr-1.5" /> Delete
          </Button>
        )}
      </div>
    </article>
  );
}
