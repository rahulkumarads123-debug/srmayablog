import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { AlertTriangle, X } from "lucide-react";
import { toast } from "sonner";
import api, { formatApiError } from "@/lib/api";
import { useAuth } from "@/contexts/AuthContext";

const DISMISS_KEY = "rateverse:verify-banner-dismissed";

export default function VerificationBanner() {
  const { user, refresh } = useAuth();
  const [dismissed, setDismissed] = useState(false);
  const [resending, setResending] = useState(false);

  useEffect(() => {
    setDismissed(sessionStorage.getItem(DISMISS_KEY) === "1");
  }, []);

  if (!user || typeof user !== "object") return null;
  if (user.email_verified) return null;
  if (dismissed) return null;

  const resend = async () => {
    setResending(true);
    try {
      const { data } = await api.post("/auth/verify/send");
      if (data.already_verified) {
        toast.success("Your email is already verified.");
        await refresh?.();
        return;
      }
      // Dev-mode: token comes back inline. Show a direct verify link.
      const link = `${window.location.origin}/verify-email?token=${encodeURIComponent(data.token)}`;
      toast.success("Verification link issued", {
        duration: 12000,
        description: "Click below to verify (email provider not yet wired).",
        action: {
          label: "Verify now",
          onClick: () => { window.location.href = link; },
        },
      });
    } catch (err) {
      toast.error(formatApiError(err.response?.data?.detail) || "Failed to send verification link");
    } finally {
      setResending(false);
    }
  };

  const close = () => {
    sessionStorage.setItem(DISMISS_KEY, "1");
    setDismissed(true);
  };

  return (
    <div
      className="bg-amber-50 border-b border-amber-200 text-amber-900"
      data-testid="verification-banner"
    >
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-2.5 flex items-center gap-3 text-sm">
        <AlertTriangle size={15} className="flex-shrink-0 text-amber-600" />
        <div className="flex-1 min-w-0">
          <strong>Verify your email</strong> to publish reviews, feed posts, submissions and group discussions.
        </div>
        <button
          onClick={resend}
          disabled={resending}
          className="text-xs font-bold uppercase tracking-[0.15em] bg-amber-900 text-white px-3 py-1.5 hover:bg-amber-700 disabled:opacity-50"
          data-testid="verification-resend-btn"
        >
          {resending ? "Sending…" : "Resend link"}
        </button>
        <Link
          to="/verify-email"
          className="hidden sm:inline text-xs font-bold uppercase tracking-[0.15em] hover:underline"
        >
          How it works
        </Link>
        <button onClick={close} className="text-amber-700 hover:text-amber-900" aria-label="Dismiss">
          <X size={14} />
        </button>
      </div>
    </div>
  );
}
