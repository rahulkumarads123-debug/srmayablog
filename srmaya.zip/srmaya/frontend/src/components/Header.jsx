import { Link, useNavigate, useLocation } from "react-router-dom";
import {
  Search,
  User,
  LogOut,
  LayoutDashboard,
  Menu,
  X,
  Plus,
  ChevronDown,
  Film,
  Building2,
  Package,
  Wrench,
  Monitor,
  TrendingUp,
  Users,
  BookOpen,
  Rss,
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import NotificationsBell from "@/components/NotificationsBell";

const DISCOVER_LINKS = [
  { to: "/category/entertainment", label: "Movies & TV", Icon: Film },
  { to: "/category/business", label: "Companies", Icon: Building2 },
  { to: "/category/products", label: "Products", Icon: Package },
  { to: "/category/services", label: "Services", Icon: Wrench },
  { to: "/category/digital", label: "Digital", Icon: Monitor },
  { to: "/top10", label: "Top 10 Charts", Icon: TrendingUp },
];

const PRIMARY_LINKS = [
  { to: "/feed", label: "Feed", Icon: Rss, testid: "nav-feed" },
  { to: "/groups", label: "Community", Icon: Users, testid: "nav-groups" },
  { to: "/blog", label: "Blog", Icon: BookOpen, testid: "nav-blog" },
];

export default function Header() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [q, setQ] = useState("");
  const [mobileOpen, setMobileOpen] = useState(false);

  const onSearch = (e) => {
    e.preventDefault();
    if (q.trim()) {
      navigate(`/search?q=${encodeURIComponent(q.trim())}`);
      setMobileOpen(false);
    }
  };

  const initials = user && typeof user === "object"
    ? user.name?.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase()
    : "";

  const isActive = (to) =>
    to === "/"
      ? location.pathname === "/"
      : location.pathname.startsWith(to);

  return (
    <header
      className="sticky top-0 z-40 bg-white/90 backdrop-blur-xl border-b border-zinc-200"
      data-testid="site-header"
    >
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="flex items-center gap-6 h-16">
          <Link to="/" className="flex items-center gap-2 group shrink-0" data-testid="logo-link">
            <div className="w-8 h-8 bg-zinc-900 text-white grid place-items-center font-display font-black text-base">
              R
            </div>
            <div className="font-display font-black text-xl tracking-tighter hidden sm:block">
              Rateverse<span className="text-blue-600">.</span>
            </div>
          </Link>

          <form
            onSubmit={onSearch}
            className="hidden md:flex flex-1 max-w-md relative"
            data-testid="header-search-form"
          >
            <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" />
            <input
              type="search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search movies, companies, products..."
              className="w-full bg-zinc-50 border border-zinc-200 rounded-none pl-11 pr-4 py-2.5 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition"
              data-testid="header-search-input"
            />
          </form>

          <nav className="hidden lg:flex items-center gap-1 text-sm font-medium">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  className="flex items-center gap-1 px-3 py-2 hover:text-blue-600 transition-colors"
                  data-testid="nav-discover-trigger"
                >
                  Discover <ChevronDown size={14} className="opacity-60" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                align="start"
                className="rounded-none w-60 border-zinc-900"
                data-testid="nav-discover-menu"
              >
                {DISCOVER_LINKS.map(({ to, label, Icon }) => (
                  <DropdownMenuItem
                    key={to}
                    onClick={() => navigate(to)}
                    className="cursor-pointer rounded-none py-2.5"
                    data-testid={`nav-discover-${label.toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    <Icon size={14} className="mr-2.5 text-blue-600" />
                    <span className="font-medium">{label}</span>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {PRIMARY_LINKS.map(({ to, label, testid }) => (
              <Link
                key={to}
                to={to}
                className={`px-3 py-2 transition-colors ${
                  isActive(to) ? "text-blue-600" : "hover:text-blue-600"
                }`}
                data-testid={testid}
              >
                {label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2 ml-auto shrink-0">
            {user && typeof user === "object" ? (
              <>
                <NotificationsBell />
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button
                      className="flex items-center gap-2 group"
                      data-testid="user-menu-trigger"
                    >
                      <Avatar className="h-9 w-9 rounded-none ring-1 ring-zinc-200 hover:ring-blue-600 transition">
                        <AvatarImage src={user.avatar_url} />
                        <AvatarFallback className="rounded-none bg-zinc-900 text-white text-xs font-semibold">
                          {initials || <User size={14} />}
                        </AvatarFallback>
                      </Avatar>
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent
                    align="end"
                    className="rounded-none w-56 border-zinc-900"
                  >
                    <div className="px-3 py-2 text-xs">
                      <div className="font-semibold text-zinc-900 truncate">{user.name}</div>
                      <div className="text-zinc-500 truncate">{user.email}</div>
                    </div>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => navigate("/profile")} data-testid="menu-profile" className="cursor-pointer">
                      <User size={14} className="mr-2" /> My Profile
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate("/submit-post")} data-testid="menu-submit-post" className="cursor-pointer">
                      <Plus size={14} className="mr-2" /> Submit Post
                    </DropdownMenuItem>
                    {user.role === "admin" && (
                      <DropdownMenuItem onClick={() => navigate("/admin")} data-testid="menu-admin" className="cursor-pointer">
                        <LayoutDashboard size={14} className="mr-2" /> Admin Dashboard
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem
                      onClick={async () => { await logout(); navigate("/"); }}
                      data-testid="menu-logout"
                      className="cursor-pointer"
                    >
                      <LogOut size={14} className="mr-2" /> Sign out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <>
                <Button
                  variant="ghost"
                  className="rounded-none hidden sm:inline-flex h-9"
                  onClick={() => navigate("/login")}
                  data-testid="header-login-btn"
                >
                  Sign in
                </Button>
                <Button
                  className="rounded-none bg-blue-600 hover:bg-blue-700 text-white font-semibold h-9 px-4"
                  onClick={() => navigate("/register")}
                  data-testid="header-register-btn"
                >
                  Join free
                </Button>
              </>
            )}
            <button
              className="lg:hidden p-2 -mr-2"
              onClick={() => setMobileOpen((v) => !v)}
              aria-label="Toggle menu"
              data-testid="mobile-menu-toggle"
            >
              {mobileOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {mobileOpen && (
          <div
            className="lg:hidden pb-5 border-t border-zinc-200 -mx-6 px-6 lg:px-10 pt-4 space-y-4"
            data-testid="mobile-menu"
          >
            <form onSubmit={onSearch} className="md:hidden flex relative">
              <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" />
              <input
                type="search"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search anything..."
                className="w-full bg-zinc-50 border border-zinc-200 rounded-none pl-11 pr-4 py-2.5 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                data-testid="mobile-search-input"
              />
            </form>

            <div>
              <div className="text-[10px] font-bold tracking-[0.2em] text-zinc-400 uppercase mb-2">
                Discover
              </div>
              <div className="grid grid-cols-2 gap-1">
                {DISCOVER_LINKS.map(({ to, label, Icon }) => (
                  <Link
                    key={to}
                    to={to}
                    onClick={() => setMobileOpen(false)}
                    className="flex items-center gap-2 py-2 px-2 text-sm font-medium hover:text-blue-600 hover:bg-zinc-50 transition-colors"
                    data-testid={`mobile-nav-${label.toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    <Icon size={14} className="text-blue-600" /> {label}
                  </Link>
                ))}
              </div>
            </div>

            <div>
              <div className="text-[10px] font-bold tracking-[0.2em] text-zinc-400 uppercase mb-2">
                Community
              </div>
              <div className="flex flex-col gap-0.5">
                {PRIMARY_LINKS.map(({ to, label, Icon }) => (
                  <Link
                    key={to}
                    to={to}
                    onClick={() => setMobileOpen(false)}
                    className="flex items-center gap-2 py-2 px-2 text-sm font-medium hover:text-blue-600 hover:bg-zinc-50 transition-colors"
                    data-testid={`mobile-nav-${label.toLowerCase()}`}
                  >
                    <Icon size={14} className="text-blue-600" /> {label}
                  </Link>
                ))}
              </div>
            </div>

            {user && typeof user === "object" ? (
              <Link
                to="/submit-post"
                className="flex items-center justify-center gap-2 bg-blue-600 text-white py-2.5 text-sm font-semibold hover:bg-blue-700 transition-colors"
                onClick={() => setMobileOpen(false)}
                data-testid="mobile-submit-post"
              >
                <Plus size={14} /> Submit Post
              </Link>
            ) : (
              <div className="grid grid-cols-2 gap-2 pt-1">
                <Link
                  to="/login"
                  className="text-center border border-zinc-900 py-2.5 text-sm font-semibold hover:bg-zinc-900 hover:text-white transition-colors"
                  onClick={() => setMobileOpen(false)}
                  data-testid="mobile-login-btn"
                >
                  Sign in
                </Link>
                <Link
                  to="/register"
                  className="text-center bg-blue-600 text-white py-2.5 text-sm font-semibold hover:bg-blue-700 transition-colors"
                  onClick={() => setMobileOpen(false)}
                  data-testid="mobile-register-btn"
                >
                  Join free
                </Link>
              </div>
            )}
          </div>
        )}
      </div>
    </header>
  );
}
