import { Link } from "react-router-dom";
import * as Icons from "lucide-react";
import { ArrowUpRight } from "lucide-react";

export default function CategoryCard({ category, index = 0 }) {
  const Icon = Icons[category.icon] || Icons.Layers;
  return (
    <Link
      to={`/category/${category.slug}`}
      className="group block border border-zinc-200 hover:border-zinc-900 bg-white p-6 transition-all duration-200 hover:-translate-y-1 fade-up"
      style={{ animationDelay: `${index * 60}ms` }}
      data-testid={`category-card-${category.slug}`}
    >
      <div className="flex items-start justify-between mb-12">
        <div
          className="w-12 h-12 grid place-items-center"
          style={{ backgroundColor: category.color, color: "#FFFFFF" }}
        >
          <Icon size={22} strokeWidth={2} />
        </div>
        <ArrowUpRight size={20} className="text-zinc-300 group-hover:text-zinc-900 transition-colors" />
      </div>
      <h3 className="font-display font-bold text-2xl tracking-tighter mb-1">
        {category.name}
      </h3>
      <p className="text-sm text-zinc-500 leading-relaxed mb-4 line-clamp-2">
        {category.description}
      </p>
      <div className="text-xs font-mono uppercase tracking-[0.2em] text-zinc-400">
        {category.item_count} listings
      </div>
    </Link>
  );
}
