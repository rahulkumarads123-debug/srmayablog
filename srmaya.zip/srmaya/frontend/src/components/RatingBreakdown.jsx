import StarRating from "./StarRating";

export default function RatingBreakdown({ avg = 0, count = 0, breakdown = {} }) {
  const total = count || Object.values(breakdown).reduce((a, b) => a + (b || 0), 0);
  const order = ["5", "4", "3", "2", "1"];

  return (
    <div className="border border-zinc-200 bg-white p-6" data-testid="rating-breakdown">
      <div className="grid grid-cols-[auto_1fr] gap-8">
        <div className="text-center">
          <div className="font-display font-black text-6xl tracking-tighter leading-none">
            {avg ? avg.toFixed(1) : "0.0"}
          </div>
          <div className="my-3">
            <StarRating value={avg} size={18} />
          </div>
          <div className="text-xs text-zinc-500 font-mono uppercase tracking-[0.2em]">
            {total} review{total === 1 ? "" : "s"}
          </div>
        </div>
        <div className="space-y-2">
          {order.map((star) => {
            const c = breakdown?.[star] || 0;
            const pct = total ? Math.round((c / total) * 100) : 0;
            return (
              <div key={star} className="flex items-center gap-3 text-sm">
                <div className="w-6 font-mono text-zinc-500 text-xs">{star}★</div>
                <div className="flex-1 bg-zinc-100 h-2 relative overflow-hidden">
                  <div
                    className="absolute inset-y-0 left-0 bg-blue-600 transition-all duration-500"
                    style={{ width: `${pct}%` }}
                  />
                </div>
                <div className="w-12 text-right text-xs text-zinc-500 font-mono">
                  {c} ({pct}%)
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
