import { useEffect, useState } from "react";

/**
 * Detects the host of a video URL and returns the embed type.
 * Returns null when the URL is not from a supported platform.
 */
export function parseVideoUrl(rawUrl) {
  if (!rawUrl || typeof rawUrl !== "string") return null;
  let url;
  try {
    url = new URL(rawUrl.trim());
  } catch {
    return null;
  }
  const host = url.hostname.toLowerCase().replace(/^www\./, "");

  // ---- YouTube ----
  if (host === "youtu.be") {
    const id = url.pathname.replace(/^\//, "").split("/")[0];
    if (id) return { kind: "youtube", id, original: rawUrl };
  }
  if (host === "youtube.com" || host === "m.youtube.com" || host === "youtube-nocookie.com") {
    const v = url.searchParams.get("v");
    if (v) return { kind: "youtube", id: v, original: rawUrl };
    const embedMatch = url.pathname.match(/^\/(?:embed|shorts|v)\/([A-Za-z0-9_-]{6,})/);
    if (embedMatch) return { kind: "youtube", id: embedMatch[1], original: rawUrl };
  }

  // ---- Facebook ----
  if (host === "facebook.com" || host === "m.facebook.com" || host === "fb.watch") {
    return { kind: "facebook", original: rawUrl };
  }

  // ---- X / Twitter ----
  if (host === "twitter.com" || host === "x.com" || host === "mobile.twitter.com") {
    const m = url.pathname.match(/\/status(?:es)?\/(\d+)/);
    if (m) return { kind: "twitter", id: m[1], original: rawUrl };
  }

  return null;
}

export function isSupportedVideoUrl(url) {
  return parseVideoUrl(url) !== null;
}

export const VIDEO_PLATFORM_HINT =
  "Paste a YouTube (youtube.com / youtu.be), Facebook (facebook.com / fb.watch) or X (x.com / twitter.com) link.";

/**
 * Renders an in-place player for the supplied URL.
 * Returns null for unsupported URLs so the caller can fall back.
 */
export default function VideoPlayer({ url, title = "Video" }) {
  const parsed = parseVideoUrl(url);

  // Load Twitter widgets script only when needed
  useEffect(() => {
    if (parsed?.kind !== "twitter") return;
    if (window.__twitterWidgetsLoading) return;
    if (window.twttr && window.twttr.widgets) {
      window.twttr.widgets.load();
      return;
    }
    window.__twitterWidgetsLoading = true;
    const s = document.createElement("script");
    s.async = true;
    s.src = "https://platform.twitter.com/widgets.js";
    s.charset = "utf-8";
    document.body.appendChild(s);
  }, [parsed?.kind, parsed?.id]);

  // Re-render twitter embed when the URL changes
  const [twKey, setTwKey] = useState(0);
  useEffect(() => {
    if (parsed?.kind !== "twitter") return;
    setTwKey((k) => k + 1);
    const t = setTimeout(() => {
      if (window.twttr && window.twttr.widgets) window.twttr.widgets.load();
    }, 400);
    return () => clearTimeout(t);
  }, [parsed?.original, parsed?.kind]);

  if (!parsed) return null;

  if (parsed.kind === "youtube") {
    return (
      <div className="border border-zinc-900 bg-black" data-testid="video-player-youtube">
        <div className="relative w-full" style={{ paddingBottom: "56.25%" }}>
          <iframe
            className="absolute inset-0 w-full h-full"
            src={`https://www.youtube-nocookie.com/embed/${parsed.id}?rel=0`}
            title={title}
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
          />
        </div>
      </div>
    );
  }

  if (parsed.kind === "facebook") {
    return (
      <div className="border border-zinc-900 bg-black" data-testid="video-player-facebook">
        <div className="relative w-full" style={{ paddingBottom: "56.25%" }}>
          <iframe
            className="absolute inset-0 w-full h-full"
            src={`https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(
              parsed.original
            )}&show_text=false&width=560`}
            title={title}
            frameBorder="0"
            scrolling="no"
            allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"
            allowFullScreen
          />
        </div>
      </div>
    );
  }

  if (parsed.kind === "twitter") {
    return (
      <div className="border border-zinc-200 bg-white p-4 max-w-full overflow-hidden" data-testid="video-player-twitter">
        <blockquote key={twKey} className="twitter-tweet" data-dnt="true" data-theme="light">
          <a href={parsed.original}>View on X</a>
        </blockquote>
      </div>
    );
  }

  return null;
}
