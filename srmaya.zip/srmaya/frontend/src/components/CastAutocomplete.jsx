import { useEffect, useRef, useState } from "react";
import { Search, Loader2, Plus, X, Check } from "lucide-react";
import api from "@/lib/api";
import { toast } from "sonner";
import ImageUploader from "@/components/ImageUploader";

/**
 * CastAutocomplete
 * Row-level editor for a single cast/crew member linked (optionally) to the central DB.
 *
 * value: { cast_id?, name, role, character, photo_url }
 * onChange(next): void
 * onRemove(): void
 * testId prefix
 */
export default function CastAutocomplete({ value, onChange, onRemove, testId }) {
  const [query, setQuery] = useState(value?.name || "");
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggest, setShowSuggest] = useState(false);
  const [searching, setSearching] = useState(false);
  const [creating, setCreating] = useState(false);
  const timerRef = useRef(null);

  const linked = !!value?.cast_id;

  useEffect(() => {
    if (linked || query.trim().length < 2) { setSuggestions([]); return; }
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(async () => {
      setSearching(true);
      try {
        const { data } = await api.get(`/cast?q=${encodeURIComponent(query.trim())}&limit=6`);
        setSuggestions(data);
      } catch (err) {
        console.warn("cast search failed", err);
      } finally { setSearching(false); }
    }, 220);
    return () => timerRef.current && clearTimeout(timerRef.current);
  }, [query, linked]);

  const pick = (person) => {
    onChange({
      ...value,
      cast_id: person.id,
      cast_slug: person.slug,
      name: person.name,
      photo_url: person.photo_url || value?.photo_url || "",
    });
    setShowSuggest(false);
    setSuggestions([]);
    setQuery(person.name);
  };

  const createNew = async () => {
    if (!query.trim()) return;
    setCreating(true);
    try {
      const { data } = await api.post("/cast", { name: query.trim() });
      pick(data);
      toast.success(`Added ${data.name} to Cast & Crew.`);
    } catch (err) {
      toast.error("Could not create cast member.");
    } finally {
      setCreating(false);
    }
  };

  const unlink = () => {
    onChange({ ...value, cast_id: undefined, cast_slug: undefined });
  };

  return (
    <div
      className="grid grid-cols-1 sm:grid-cols-[100px_1fr_auto] gap-3 items-start"
      data-testid={testId}
    >
      <div className="w-24">
        <ImageUploader
          value={value?.photo_url}
          onChange={(url) => onChange({ ...value, photo_url: url })}
          aspect="aspect-square"
          allowUrl={false}
          testId={`${testId}-photo`}
        />
      </div>
      <div className="space-y-2 relative">
        <div className="relative">
          <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-400" />
          <input
            value={query}
            onChange={(e) => {
              const v = e.target.value;
              setQuery(v);
              setShowSuggest(true);
              onChange({ ...value, name: v, cast_id: linked && v !== value?.name ? undefined : value?.cast_id });
            }}
            onFocus={() => setShowSuggest(true)}
            onBlur={() => setTimeout(() => setShowSuggest(false), 180)}
            placeholder="Type a name — pick from the list or add new"
            className="w-full bg-zinc-50 border border-zinc-200 rounded-none pl-7 pr-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-600"
            data-testid={`${testId}-name`}
          />
          {linked && (
            <button
              type="button"
              onClick={unlink}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] font-bold uppercase tracking-[0.15em] bg-green-600 text-white px-1.5 py-0.5"
              title="Linked to Cast DB — click to unlink"
              data-testid={`${testId}-linked`}
            >
              <Check size={9} className="inline" /> Linked
            </button>
          )}
        </div>
        {showSuggest && !linked && (suggestions.length > 0 || (query.trim().length >= 2 && !searching)) && (
          <div className="absolute z-20 left-0 right-0 top-full mt-1 bg-white border border-zinc-900 max-h-64 overflow-y-auto" data-testid={`${testId}-suggestions`}>
            {searching && (
              <div className="px-3 py-2 text-xs text-zinc-500 flex items-center gap-2"><Loader2 size={11} className="animate-spin" /> Searching…</div>
            )}
            {suggestions.map((p) => (
              <button
                key={p.id}
                type="button"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => pick(p)}
                className="w-full text-left flex items-center gap-2 p-2 hover:bg-zinc-100 border-b border-zinc-100 last:border-0"
                data-testid={`${testId}-option-${p.id}`}
              >
                <div className="w-9 h-9 bg-zinc-100 overflow-hidden flex-shrink-0">
                  {p.photo_url && <img src={p.photo_url} alt="" className="w-full h-full object-cover" />}
                </div>
                <div className="min-w-0">
                  <div className="font-semibold text-xs truncate">{p.name}</div>
                  {p.profession && <div className="text-[10px] text-zinc-500 truncate uppercase tracking-wide">{p.profession}</div>}
                </div>
              </button>
            ))}
            {!searching && query.trim().length >= 2 && !suggestions.some((s) => s.name.toLowerCase() === query.trim().toLowerCase()) && (
              <button
                type="button"
                onMouseDown={(e) => e.preventDefault()}
                onClick={createNew}
                disabled={creating}
                className="w-full text-left flex items-center gap-2 p-2 hover:bg-blue-50 text-blue-700 font-semibold text-xs"
                data-testid={`${testId}-create-new`}
              >
                <Plus size={12} /> {creating ? "Adding…" : `Add “${query.trim()}” to Cast & Crew`}
              </button>
            )}
          </div>
        )}
        <input
          value={value?.role || ""}
          onChange={(e) => onChange({ ...value, role: e.target.value })}
          placeholder="Role (e.g. Director) — optional"
          className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2 text-xs outline-none focus:ring-2 focus:ring-blue-600"
          data-testid={`${testId}-role`}
        />
        <input
          value={value?.character || ""}
          onChange={(e) => onChange({ ...value, character: e.target.value })}
          placeholder="Character name (for actors) — optional"
          className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2 text-xs outline-none focus:ring-2 focus:ring-blue-600"
          data-testid={`${testId}-character`}
        />
      </div>
      <button
        type="button"
        onClick={onRemove}
        className="text-zinc-400 hover:text-red-600 px-2 py-2 self-center"
        aria-label="Remove cast member"
        data-testid={`${testId}-remove`}
      >
        <X size={16} />
      </button>
    </div>
  );
}
