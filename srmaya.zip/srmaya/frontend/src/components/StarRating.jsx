import { Star } from "lucide-react";

export default function StarRating({ value = 0, size = 16, onChange = null, testIdPrefix = "star" }) {
  const stars = [1, 2, 3, 4, 5];
  const interactive = typeof onChange === "function";

  return (
    <div className="inline-flex items-center gap-0.5" role="img" aria-label={`Rating: ${value} out of 5`}>
      {stars.map((s) => {
        const filled = value >= s;
        const half = !filled && value >= s - 0.5;
        const Icon = (
          <Star
            size={size}
            strokeWidth={1.5}
            className={
              filled
                ? "text-blue-600 fill-blue-600"
                : half
                ? "text-blue-600"
                : "text-zinc-200 fill-zinc-200"
            }
          />
        );
        if (interactive) {
          return (
            <button
              type="button"
              key={s}
              onClick={() => onChange(s)}
              className="p-0.5 hover:scale-110 transition-transform"
              data-testid={`${testIdPrefix}-${s}`}
              aria-label={`${s} star${s > 1 ? "s" : ""}`}
            >
              {Icon}
            </button>
          );
        }
        return <span key={s}>{Icon}</span>;
      })}
    </div>
  );
}
