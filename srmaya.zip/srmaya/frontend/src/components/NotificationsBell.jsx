import { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Bell, Check, CheckCheck, UserPlus, Heart, MessageCircle, Star } from "lucide-react";
import api from "@/lib/api";
import { useAuth } from "@/contexts/AuthContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const ICON_BY_TYPE = {
  follow: UserPlus,
  like_post: Heart,
  comment_post: MessageCircle,
  like_comment: Heart,
  review: Star,
  group_post_like: Heart,
};

function timeAgo(iso) {
  if (!iso) return "";
  const s = Math.round((Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.round(s / 60)}m`;
  if (s < 86400) return `${Math.round(s / 3600)}h`;
  return `${Math.round(s / 86400)}d`;
}

export default function NotificationsBell() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState([]);
  const [unread, setUnread] = useState(0);
  const wrapRef = useRef(null);

  const loadUnread = async () => {
    try {
      const { data } = await api.get("/notifications/unread-count");
      setUnread(data.unread || 0);
    } catch (err) {
      console.warn("Failed to load unread count:", err);
    }
  };

  const loadList = async () => {
    try {
      const { data } = await api.get("/notifications?limit=8");
      setItems(data.items || []);
      setUnread(data.unread || 0);
    } catch (err) {
      console.warn("Failed to load notifications:", err);
    }
  };

  useEffect(() => {
    if (!user || typeof user !== "object") return;
    loadUnread();
    const timer = setInterval(loadUnread, 30000);
    return () => clearInterval(timer);
  }, [user]);

  useEffect(() => {
    if (open) loadList();
  }, [open]);

  useEffect(() => {
    const onClick = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const handleClick = async (n) => {
    if (!n.read) {
      try { await api.post(`/notifications/${n.id}/read`); } catch (err) { console.warn(err); }
    }
    setOpen(false);
    if (n.link) navigate(n.link);
  };

  const markAll = async () => {
    try {
      await api.post("/notifications/read-all");
      setItems((xs) => xs.map((x) => ({ ...x, read: true })));
      setUnread(0);
    } catch (err) { console.warn(err); }
  };

  if (!user || typeof user !== "object") return null;

  return (
    <div className="relative" ref={wrapRef}>
      <button
        onClick={() => setOpen((v) => !v)}
        className="relative p-2 hover:bg-zinc-100 transition-colors"
        aria-label="Notifications"
        data-testid="notifications-bell"
      >
        <Bell size={18} />
        {unread > 0 && (
          <span
            className="absolute -top-0.5 -right-0.5 bg-red-600 text-white text-[10px] font-bold min-w-[16px] h-4 grid place-items-center px-1 leading-none"
            data-testid="notifications-badge"
          >
            {unread > 99 ? "99+" : unread}
          </span>
        )}
      </button>
      {open && (
        <div
          className="absolute right-0 mt-1 w-80 sm:w-96 bg-white border border-zinc-900 shadow-lg z-50"
          data-testid="notifications-panel"
        >
          <div className="flex items-center justify-between border-b border-zinc-200 px-4 py-3">
            <div className="text-xs font-bold uppercase tracking-[0.2em]">Notifications</div>
            {items.some((x) => !x.read) && (
              <button
                onClick={markAll}
                className="text-[10px] font-bold uppercase tracking-[0.15em] text-blue-600 hover:underline"
                data-testid="mark-all-read-btn"
              >
                <CheckCheck size={11} className="inline mr-1" /> Mark all read
              </button>
            )}
          </div>
          <div className="max-h-96 overflow-y-auto">
            {items.length === 0 ? (
              <div className="px-4 py-10 text-center text-zinc-500 text-sm">You're all caught up.</div>
            ) : (
              items.map((n) => {
                const Icon = ICON_BY_TYPE[n.type] || Bell;
                const initials = n.actor_name?.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();
                return (
                  <button
                    key={n.id}
                    onClick={() => handleClick(n)}
                    className={`w-full text-left flex items-start gap-3 px-4 py-3 border-b border-zinc-100 hover:bg-zinc-50 transition-colors ${!n.read ? "bg-blue-50/40" : ""}`}
                    data-testid={`notification-${n.id}`}
                  >
                    <div className="relative flex-shrink-0">
                      <Avatar className="h-9 w-9 rounded-none">
                        <AvatarImage src={n.actor_avatar} />
                        <AvatarFallback className="rounded-none bg-zinc-900 text-white text-[10px]">{initials}</AvatarFallback>
                      </Avatar>
                      <div className="absolute -bottom-1 -right-1 bg-blue-600 text-white p-0.5">
                        <Icon size={9} />
                      </div>
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm text-zinc-800 leading-snug line-clamp-2">{n.message}</div>
                      <div className="text-[10px] text-zinc-400 font-mono uppercase mt-1">{timeAgo(n.created_at)}</div>
                    </div>
                    {!n.read && (
                      <span className="mt-2 w-1.5 h-1.5 bg-blue-600 rounded-full flex-shrink-0" aria-label="Unread" />
                    )}
                  </button>
                );
              })
            )}
          </div>
          <Link
            to="/notifications"
            onClick={() => setOpen(false)}
            className="block text-center py-2.5 text-[10px] font-bold uppercase tracking-[0.2em] bg-zinc-900 text-white hover:bg-blue-600 transition-colors"
            data-testid="notifications-see-all"
          >
            See all notifications
          </Link>
        </div>
      )}
    </div>
  );
}
