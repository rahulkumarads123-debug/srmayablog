import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="border-t border-zinc-200 bg-white mt-24" data-testid="site-footer">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-16 grid grid-cols-2 md:grid-cols-4 gap-8 text-sm">
        <div className="col-span-2 md:col-span-1">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-7 h-7 bg-zinc-900 text-white grid place-items-center font-display font-black">R</div>
            <span className="font-display font-black text-lg tracking-tighter">
              Rateverse<span className="text-blue-600">.</span>
            </span>
          </div>
          <p className="text-zinc-500 leading-relaxed">
            One place to rate and review everything — movies, companies, products, services, and digital tools.
          </p>
        </div>
        <div>
          <div className="text-xs font-bold uppercase tracking-[0.2em] text-zinc-900 mb-4">Categories</div>
          <ul className="space-y-2 text-zinc-500">
            <li><Link to="/category/entertainment" className="hover:text-zinc-900">Entertainment</Link></li>
            <li><Link to="/category/business" className="hover:text-zinc-900">Business</Link></li>
            <li><Link to="/category/products" className="hover:text-zinc-900">Products</Link></li>
            <li><Link to="/category/services" className="hover:text-zinc-900">Services</Link></li>
            <li><Link to="/category/digital" className="hover:text-zinc-900">Digital</Link></li>
          </ul>
        </div>
        <div>
          <div className="text-xs font-bold uppercase tracking-[0.2em] text-zinc-900 mb-4">Discover</div>
          <ul className="space-y-2 text-zinc-500">
            <li><Link to="/top10" className="hover:text-zinc-900">Top 10 Rankings</Link></li>
            <li><Link to="/search" className="hover:text-zinc-900">Search</Link></li>
          </ul>
        </div>
        <div>
          <div className="text-xs font-bold uppercase tracking-[0.2em] text-zinc-900 mb-4">Account</div>
          <ul className="space-y-2 text-zinc-500">
            <li><Link to="/login" className="hover:text-zinc-900">Sign in</Link></li>
            <li><Link to="/register" className="hover:text-zinc-900">Create account</Link></li>
            <li><Link to="/profile" className="hover:text-zinc-900">My profile</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-zinc-200">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-6 flex flex-col md:flex-row justify-between items-center gap-2 text-xs text-zinc-500">
          <span>© {new Date().getFullYear()} Rateverse — all reviews belong to their authors.</span>
          <span className="font-mono uppercase tracking-[0.2em]">Built objectively · Updated continuously</span>
        </div>
      </div>
    </footer>
  );
}
