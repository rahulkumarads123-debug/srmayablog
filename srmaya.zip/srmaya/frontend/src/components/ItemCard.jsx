import { Link } from "react-router-dom";
import StarRating from "./StarRating";

export default function ItemCard({ item, index = 0 }) {
  return (
    <Link
      to={`/item/${item.slug}`}
      className="group block border border-zinc-200 hover:border-zinc-900 bg-white transition-all duration-200 hover:-translate-y-1 fade-up"
      style={{ animationDelay: `${(index % 6) * 50}ms` }}
      data-testid={`item-card-${item.slug}`}
    >
      <div className="aspect-[4/3] bg-zinc-100 overflow-hidden relative">
        {item.image_url ? (
          <img
            src={item.image_url}
            alt={item.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full grid place-items-center text-zinc-400 text-xs uppercase tracking-[0.2em]">
            No image
          </div>
        )}
        {item.featured && (
          <div className="absolute top-3 left-3 bg-zinc-900 text-white text-[10px] font-bold uppercase tracking-[0.2em] px-2 py-1">
            Featured
          </div>
        )}
      </div>
      <div className="p-5">
        <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500 mb-2">
          {item.category_name}
        </div>
        <h3 className="font-display font-bold text-lg tracking-tight leading-tight mb-2 group-hover:text-blue-600 transition-colors line-clamp-1">
          {item.name}
        </h3>
        <p className="text-sm text-zinc-500 leading-relaxed line-clamp-2 mb-4">
          {item.description}
        </p>
        <div className="flex items-center justify-between border-t border-zinc-100 pt-3">
          <div className="flex items-center gap-2">
            <StarRating value={item.avg_rating} size={14} />
            <span className="font-semibold text-sm text-zinc-900">
              {item.avg_rating?.toFixed(1) ?? "0.0"}
            </span>
          </div>
          <span className="text-xs text-zinc-500 font-mono">
            {item.review_count} reviews
          </span>
        </div>
      </div>
    </Link>
  );
}
