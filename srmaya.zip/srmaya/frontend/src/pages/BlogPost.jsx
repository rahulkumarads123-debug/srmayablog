import { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import api, { formatApiError } from "@/lib/api";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Heart, Eye, Calendar, Edit3, Trash2, ArrowLeft } from "lucide-react";
import { toast } from "sonner";

function fmtLong(iso) {
  try { return new Date(iso).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" }); } catch { return ""; }
}

export default function BlogPost() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [post, setPost] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    api.get(`/blog/${slug}`).then((r) => setPost(r.data)).catch(() => setPost(null)).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [slug]);

  const liked = user && typeof user === "object" && post && (post.liked_user_ids || []).includes(user.id);
  const isAdmin = user && typeof user === "object" && user.role === "admin";
  const initials = post?.author_name?.split(" ").map((x) => x[0]).slice(0, 2).join("").toUpperCase();

  const handleLike = async () => {
    if (!user || typeof user !== "object") { toast.error("Sign in to like posts."); return; }
    try {
      const { data } = await api.post(`/blog/${post.id}/like`);
      setPost((p) => ({ ...p, liked_user_ids: data.liked_user_ids, likes_count: data.likes_count }));
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  const handleDelete = async () => {
    if (!confirm("Delete this post?")) return;
    try {
      await api.delete(`/blog/${post.id}`);
      toast.success("Post deleted.");
      navigate("/blog");
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  if (loading && !post) return <div className="max-w-[1000px] mx-auto px-6 py-20 text-zinc-400 text-xs uppercase tracking-[0.3em]">Loading...</div>;
  if (!post) {
    return (
      <div className="max-w-[1000px] mx-auto px-6 py-20">
        <h1 className="font-display font-black text-3xl mb-4">Post not found</h1>
        <Link to="/blog" className="text-blue-600 hover:underline">← All posts</Link>
      </div>
    );
  }

  return (
    <article className="max-w-[820px] mx-auto px-6 lg:px-10 py-12" data-testid="blog-post-page">
      <Link to="/blog" className="text-xs font-bold uppercase tracking-[0.3em] text-zinc-500 hover:text-zinc-900 inline-flex items-center gap-1.5 mb-6">
        <ArrowLeft size={11} /> Back to blog
      </Link>
      <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-600 mb-4 flex items-center gap-2">
        {post.tag}
        {!post.published && <span className="bg-amber-100 text-amber-800 px-1.5 py-0.5">Draft</span>}
      </div>
      <h1 className="font-display font-black text-4xl lg:text-6xl tracking-tighter leading-[0.95] mb-6">{post.title}</h1>
      <p className="text-xl text-zinc-600 leading-relaxed mb-8">{post.excerpt}</p>

      <div className="flex items-center justify-between border-y border-zinc-200 py-4 mb-10 text-sm text-zinc-500">
        <div className="flex items-center gap-3">
          <Avatar className="h-9 w-9 rounded-none">
            <AvatarImage src={post.author_avatar} />
            <AvatarFallback className="rounded-none bg-zinc-900 text-white text-xs">{initials}</AvatarFallback>
          </Avatar>
          <div>
            <div className="font-semibold text-zinc-900 text-sm">{post.author_name}</div>
            <div className="text-xs font-mono">{fmtLong(post.created_at)}</div>
          </div>
        </div>
        <div className="flex items-center gap-4 text-xs font-mono">
          <span className="flex items-center gap-1"><Eye size={11} />{post.views || 0}</span>
          <span className="flex items-center gap-1"><Heart size={11} />{post.likes_count || 0}</span>
        </div>
      </div>

      {post.cover_url && (
        <div className="border border-zinc-200 mb-10 overflow-hidden">
          <img src={post.cover_url} alt={post.title} className="w-full h-auto" />
        </div>
      )}

      <div className="prose prose-zinc max-w-none text-lg text-zinc-800 leading-relaxed space-y-5" data-testid="blog-body">
        {post.body.split("\n\n").map((para, i) => {
          const isHeading = /^\*\*[^*]+\*\*\s/.test(para);
          if (isHeading) {
            const m = para.match(/^\*\*([^*]+)\*\*\s(.*)$/s);
            return (
              <div key={i}>
                <h3 className="font-display font-bold text-2xl tracking-tight mb-2 mt-8">{m[1]}</h3>
                <p>{m[2]}</p>
              </div>
            );
          }
          // Numbered list
          if (/^\d\./.test(para.trim())) {
            return <p key={i} className="border-l-2 border-blue-600 pl-4">{para}</p>;
          }
          return <p key={i}>{para}</p>;
        })}
      </div>

      <div className="flex items-center gap-3 mt-12 pt-8 border-t border-zinc-200">
        <Button onClick={handleLike} variant="outline" className={`rounded-none border-zinc-200 hover:border-zinc-900 ${liked ? "bg-zinc-900 text-white border-zinc-900" : ""}`} data-testid="blog-like-btn">
          <Heart size={14} className="mr-1.5" /> {liked ? "Liked" : "Like"} · {post.likes_count || 0}
        </Button>
        {isAdmin && (
          <>
            <Button onClick={() => navigate(`/blog/${post.slug}/edit`)} variant="outline" className="rounded-none" data-testid="blog-edit-btn">
              <Edit3 size={13} className="mr-1.5" /> Edit
            </Button>
            <Button onClick={handleDelete} variant="ghost" className="rounded-none text-red-600 hover:bg-red-50 ml-auto" data-testid="blog-delete-btn">
              <Trash2 size={13} className="mr-1.5" /> Delete
            </Button>
          </>
        )}
      </div>
    </article>
  );
}
