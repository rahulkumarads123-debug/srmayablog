import { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import api, { formatApiError } from "@/lib/api";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Plus, X, Eye, Upload, Save, RefreshCw, AlertCircle, CheckCircle2, Users } from "lucide-react";
import StarRating from "@/components/StarRating";
import VideoPlayerPreview, { parseVideoUrl, VIDEO_PLATFORM_HINT } from "@/components/VideoPlayer";
import ImageUploader from "@/components/ImageUploader";
import CastAutocomplete from "@/components/CastAutocomplete";

// Subcategory options per category
const SUBCATEGORIES = {
  entertainment: ["Movie", "Web Series", "TV Show", "Documentary", "Podcast", "Game"],
  business: ["Startup", "Enterprise", "Agency", "Non-profit", "Employer"],
  products: ["Gadget", "Car", "Laptop", "Phone", "Appliance", "Wearable", "Audio"],
  services: ["Restaurant", "Hotel", "Hospital", "College", "Spa", "Gym", "Influencer"],
  digital: ["Mobile App", "Web App", "SaaS Tool", "Browser Extension", "Plugin"],
};

// Dynamic field schema per category — all fields are OPTIONAL.
// Field types: text | textarea | date | url | csv | select | multiselect
const DYNAMIC_FIELDS = {
  entertainment: [
    { key: "release_date", label: "Release Date", type: "date" },
    { key: "duration", label: "Duration", type: "text", placeholder: "e.g. 2h 18m" },
    { key: "director", label: "Director", type: "text" },
    { key: "writer", label: "Writer(s)", type: "text", placeholder: "Comma-separated names" },
    { key: "genre", label: "Genre", type: "select", options: ["Action", "Adventure", "Animation", "Biography", "Comedy", "Crime", "Documentary", "Drama", "Fantasy", "Horror", "Mystery", "Romance", "Sci-Fi", "Thriller", "Western", "Reality", "Sport", "Music"] },
    { key: "language", label: "Language", type: "select", options: ["English", "Hindi", "Spanish", "French", "German", "Japanese", "Korean", "Mandarin", "Portuguese", "Italian", "Russian", "Arabic", "Other"] },
    { key: "age_rating", label: "Age Rating", type: "select", options: ["G", "PG", "PG-13", "R", "NC-17", "TV-Y", "TV-PG", "TV-14", "TV-MA"] },
    { key: "country", label: "Country of Origin", type: "select", options: ["USA", "UK", "India", "Canada", "Australia", "France", "Germany", "Japan", "South Korea", "China", "Spain", "Italy", "Brazil", "Mexico", "Other"] },
    { key: "studio", label: "Studio / Network", type: "text", placeholder: "e.g. Netflix, A24, HBO" },
  ],
  business: [
    { key: "ceo", label: "CEO / Founder", type: "text" },
    { key: "founded", label: "Founded Year", type: "text", placeholder: "e.g. 2018" },
    { key: "headquarters", label: "Headquarters", type: "text" },
    { key: "website", label: "Website", type: "url", placeholder: "https://..." },
    { key: "industry", label: "Industry", type: "select", options: ["Fintech", "AI / ML", "SaaS", "E-commerce", "Healthcare", "Education", "Media & Entertainment", "Manufacturing", "Real Estate", "Consumer Goods", "Logistics", "Energy", "Telecom", "Hospitality", "Other"] },
    { key: "company_size", label: "Company Size", type: "select", options: ["1-10", "11-50", "51-200", "201-500", "501-1000", "1001-5000", "5000+"] },
    { key: "funding_stage", label: "Funding Stage", type: "select", options: ["Bootstrapped", "Pre-seed", "Seed", "Series A", "Series B", "Series C+", "IPO / Public", "Private", "Acquired"] },
    { key: "work_model", label: "Work Model", type: "select", options: ["Remote", "Hybrid", "On-site"] },
    { key: "region", label: "Primary Region", type: "select", options: ["North America", "Europe", "Asia-Pacific", "Latin America", "Middle East", "Africa", "Global"] },
  ],
  products: [
    { key: "brand", label: "Brand", type: "text" },
    { key: "price", label: "Price", type: "text", placeholder: "$ amount" },
    { key: "release_date", label: "Release Date", type: "date" },
    { key: "specs", label: "Specifications", type: "textarea", placeholder: "Free-form specs" },
    { key: "condition", label: "Condition", type: "select", options: ["New", "Refurbished", "Used", "Open Box"] },
    { key: "warranty", label: "Warranty", type: "select", options: ["No Warranty", "30 Days", "90 Days", "6 Months", "1 Year", "2 Years", "3+ Years", "Lifetime"] },
    { key: "availability", label: "Availability", type: "select", options: ["In Stock", "Limited", "Pre-order", "Out of Stock", "Discontinued"] },
    { key: "currency", label: "Currency", type: "select", options: ["USD", "EUR", "GBP", "INR", "CAD", "AUD", "JPY", "CNY", "Other"] },
    { key: "country_of_origin", label: "Country of Origin", type: "text", placeholder: "Made in..." },
  ],
  services: [
    { key: "type", label: "Service Type", type: "select", options: ["Restaurant", "Cafe", "Bar", "Hotel", "Resort", "Spa", "Gym", "Hospital", "Clinic", "College", "School", "Influencer", "Other"] },
    { key: "city", label: "City", type: "text" },
    { key: "country", label: "Country", type: "text" },
    { key: "price_range", label: "Price Range", type: "select", options: ["$", "$$", "$$$", "$$$$"] },
    { key: "hours", label: "Hours", type: "text", placeholder: "e.g. 8am – 10pm" },
    { key: "cuisine", label: "Cuisine / Specialty", type: "select", options: ["Italian", "French", "Japanese", "Indian", "Chinese", "Mexican", "Mediterranean", "American", "Thai", "Korean", "Vegan", "Seafood", "BBQ", "Bakery", "Healthcare-Cardiology", "Healthcare-Oncology", "General", "Other"] },
    { key: "stars", label: "Hotel Stars", type: "select", options: ["1", "2", "3", "4", "5"] },
    { key: "reservation_required", label: "Reservation Required", type: "select", options: ["Yes", "No", "Recommended"] },
    { key: "phone", label: "Phone", type: "text", placeholder: "+1 555..." },
  ],
  digital: [
    { key: "developer", label: "Developer / Publisher", type: "text" },
    { key: "version", label: "Latest Version", type: "text", placeholder: "e.g. 2.4.1" },
    { key: "platform", label: "Primary Platform", type: "select", options: ["iOS", "Android", "iOS + Android", "Web", "Windows", "macOS", "Linux", "Cross-platform"] },
    { key: "pricing_model", label: "Pricing Model", type: "select", options: ["Free", "Freemium", "Subscription", "One-time Purchase", "Usage-based", "Open Source"] },
    { key: "pricing", label: "Price", type: "text", placeholder: "$4.99 / mo or Free" },
    { key: "license", label: "License", type: "select", options: ["Proprietary", "MIT", "Apache 2.0", "GPL", "BSD", "Creative Commons", "Other"] },
    { key: "category_focus", label: "Tool Focus", type: "select", options: ["Productivity", "Communication", "Design", "Developer Tool", "Finance", "Health & Fitness", "Education", "Entertainment", "Social", "Security", "AI / ML", "Other"] },
    { key: "supports_offline", label: "Works Offline", type: "select", options: ["Yes", "Partially", "No"] },
  ],
};

const DRAFT_KEY = "rateverse:submit-draft";

function slugify(s) {
  return (s || "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export default function SubmitPost() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [categories, setCategories] = useState([]);
  const [tab, setTab] = useState("form");
  const [submitting, setSubmitting] = useState(false);
  const [slugStatus, setSlugStatus] = useState({ checked: false, available: true, slug: "" });
  const [captcha, setCaptcha] = useState({ question: "", label: "" });
  const slugTimer = useRef(null);
  const draftTimer = useRef(null);

  const [form, setForm] = useState({
    title: "",
    slug: "",
    category_slug: "",
    subcategory: "",
    short_description: "",
    full_description: "",
    featured_image: "",
    gallery_images: [""],
    logo_url: "",
    video_url: "",
    tags: "",
    extra: {},
    cast_members: [{ name: "", role: "", photo_url: "" }],
    captcha_a: "",
  });

  // Load categories + draft + captcha
  useEffect(() => {
    api.get("/categories").then((r) => setCategories(r.data));
    refreshCaptcha();
    try {
      const draft = localStorage.getItem(DRAFT_KEY);
      if (draft) {
        const parsed = JSON.parse(draft);
        setForm((prev) => ({ ...prev, ...parsed, captcha_a: "" }));
        toast.message("Draft restored from your last session.");
      }
    } catch (err) {
      console.warn("Failed to restore draft:", err);
    }
  }, []);

  const refreshCaptcha = async () => {
    try {
      const { data } = await api.get("/submissions/captcha");
      setCaptcha(data);
    } catch (err) {
      console.warn("Failed to load captcha:", err);
    }
  };

  // Auto-slug from title (only if user hasn't touched slug)
  useEffect(() => {
    setForm((prev) => {
      const auto = slugify(prev.title);
      if (!prev.slug || prev.slug === slugify(prev.slug)) {
        // Replace if the current slug matches the previous auto-generated one
        return { ...prev, slug: auto };
      }
      return prev;
    });
  }, [form.title]);

  // Debounced slug-availability check
  useEffect(() => {
    if (!form.slug && !form.title) {
      setSlugStatus({ checked: false, available: true, slug: "" });
      return;
    }
    if (slugTimer.current) clearTimeout(slugTimer.current);
    slugTimer.current = setTimeout(async () => {
      try {
        const { data } = await api.get(`/submissions/check-slug?title=${encodeURIComponent(form.title)}&slug=${encodeURIComponent(form.slug)}`);
        setSlugStatus({ checked: true, available: data.available, slug: data.slug });
      } catch (err) {
        console.warn("Slug availability check failed:", err);
      }
    }, 400);
    return () => slugTimer.current && clearTimeout(slugTimer.current);
  }, [form.slug, form.title]);

  // Auto-save draft (debounced)
  useEffect(() => {
    if (draftTimer.current) clearTimeout(draftTimer.current);
    draftTimer.current = setTimeout(() => {
      const { captcha_a, ...rest } = form;
      void captcha_a;
      try {
        localStorage.setItem(DRAFT_KEY, JSON.stringify(rest));
      } catch (err) {
        console.warn("Failed to autosave draft:", err);
      }
    }, 600);
    return () => draftTimer.current && clearTimeout(draftTimer.current);
  }, [form]);

  const update = (key, value) => setForm((p) => ({ ...p, [key]: value }));
  const updateExtra = (k, v) => setForm((p) => ({ ...p, extra: { ...p.extra, [k]: v } }));

  const dynamicFields = DYNAMIC_FIELDS[form.category_slug] || [];
  const subcategoryOptions = SUBCATEGORIES[form.category_slug] || [];

  const clearDraft = () => {
    localStorage.removeItem(DRAFT_KEY);
    setForm({
      title: "", slug: "", category_slug: "", subcategory: "",
      short_description: "", full_description: "", featured_image: "",
      gallery_images: [""], logo_url: "", video_url: "", tags: "",
      extra: {}, captcha_a: "",
    });
    toast.success("Draft cleared.");
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!form.title || !form.category_slug || !form.short_description || !form.full_description) {
      toast.error("Fill in all required fields.");
      return;
    }
    if (!slugStatus.available) {
      toast.error("That slug is already taken — adjust the title or slug.");
      return;
    }
    if (form.video_url && !parseVideoUrl(form.video_url)) {
      toast.error("Video URL must be a YouTube, Facebook or X (Twitter) link.");
      return;
    }
    if (!form.captcha_a) {
      toast.error("Please answer the captcha.");
      return;
    }
    setSubmitting(true);
    try {
      const tagsArr = form.tags.split(",").map((t) => t.trim()).filter(Boolean);
      const galleryArr = (form.gallery_images || []).filter((g) => g.trim());

      // Cast string fields to right type for extra
      const extraOut = { ...form.extra };
      if (extraOut.cast && typeof extraOut.cast === "string") {
        extraOut.cast = extraOut.cast.split(",").map((s) => s.trim()).filter(Boolean);
      }

      // Cast members (entertainment only)
      const castMembers = form.category_slug === "entertainment"
        ? (form.cast_members || []).filter((c) => (c.name || "").trim()).map((c) => ({
            cast_id: c.cast_id || undefined,
            cast_slug: c.cast_slug || undefined,
            name: c.name.trim(),
            role: (c.role || "").trim(),
            character: (c.character || "").trim(),
            photo_url: (c.photo_url || "").trim(),
          }))
        : [];
      if (castMembers.length > 0) extraOut.cast_members = castMembers;

      const payload = {
        title: form.title,
        slug: form.slug || undefined,
        category_slug: form.category_slug,
        subcategory: form.subcategory || undefined,
        short_description: form.short_description,
        full_description: form.full_description,
        featured_image: form.featured_image || undefined,
        gallery_images: galleryArr,
        logo_url: form.logo_url || undefined,
        video_url: form.video_url || undefined,
        tags: tagsArr,
        extra: extraOut,
        captcha_q: captcha.question,
        captcha_a: form.captcha_a,
      };
      await api.post("/submissions", payload);
      toast.success("Submitted! Admin will review and publish.");
      localStorage.removeItem(DRAFT_KEY);
      navigate("/profile");
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Submission failed");
      refreshCaptcha();
      setForm((p) => ({ ...p, captcha_a: "" }));
    } finally {
      setSubmitting(false);
    }
  };

  if (!user || typeof user !== "object") return null;

  return (
    <div className="max-w-[1100px] mx-auto px-6 lg:px-10 py-12" data-testid="submit-post-page">
      <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-600 mb-3">Contribute</div>
      <h1 className="font-display font-black text-4xl lg:text-5xl tracking-tighter mb-3">Submit a new listing</h1>
      <p className="text-zinc-600 leading-relaxed max-w-2xl mb-8">
        Add anything that's missing — a movie, company, gadget, restaurant, or app. Our admins review every submission before it goes live.
      </p>

      <Tabs value={tab} onValueChange={setTab} className="w-full">
        <TabsList className="rounded-none bg-transparent border-b border-zinc-200 w-full justify-start gap-1 px-0 mb-6 h-auto">
          <TabsTrigger value="form" className="rounded-none data-[state=active]:bg-zinc-900 data-[state=active]:text-white px-5 py-2.5 text-xs uppercase tracking-[0.2em] font-bold" data-testid="tab-form">
            <Upload size={12} className="mr-2" /> Form
          </TabsTrigger>
          <TabsTrigger value="preview" className="rounded-none data-[state=active]:bg-zinc-900 data-[state=active]:text-white px-5 py-2.5 text-xs uppercase tracking-[0.2em] font-bold" data-testid="tab-preview">
            <Eye size={12} className="mr-2" /> Preview
          </TabsTrigger>
        </TabsList>

        <TabsContent value="form">
          <form onSubmit={onSubmit} className="grid lg:grid-cols-[1fr_320px] gap-8" data-testid="submit-post-form">
            <div className="space-y-6">
              {/* Basic */}
              <fieldset className="border border-zinc-200 bg-white p-6">
                <legend className="text-xs font-bold uppercase tracking-[0.2em] px-2">Basic details</legend>
                <div className="space-y-5 mt-2">
                  <div>
                    <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">Title <span className="text-red-500">*</span></label>
                    <input required value={form.title} onChange={(e) => update("title", e.target.value)} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" placeholder="The thing you want reviewed" data-testid="submit-title-input" />
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">URL Slug</label>
                    <div className="flex">
                      <span className="border border-r-0 border-zinc-200 bg-zinc-100 px-3 py-2.5 text-xs font-mono text-zinc-500 self-stretch flex items-center">/item/</span>
                      <input value={form.slug} onChange={(e) => update("slug", slugify(e.target.value))} className="flex-1 bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" placeholder="auto-generated-from-title" data-testid="submit-slug-input" />
                    </div>
                    {slugStatus.checked && (
                      <p className={`text-xs mt-1.5 flex items-center gap-1 ${slugStatus.available ? "text-green-700" : "text-red-600"}`} data-testid="slug-status">
                        {slugStatus.available ? <><CheckCircle2 size={12} /> "{slugStatus.slug}" is available</> : <><AlertCircle size={12} /> "{slugStatus.slug}" is taken</>}
                      </p>
                    )}
                  </div>
                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">Category <span className="text-red-500">*</span></label>
                      <select required value={form.category_slug} onChange={(e) => { update("category_slug", e.target.value); setForm((p) => ({ ...p, subcategory: "", extra: {} })); }} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" data-testid="submit-category-select">
                        <option value="">Select category</option>
                        {categories.map((c) => (<option key={c.slug} value={c.slug}>{c.name}</option>))}
                      </select>
                    </div>
                    <div>
                      <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">Subcategory</label>
                      <select value={form.subcategory} onChange={(e) => update("subcategory", e.target.value)} disabled={!form.category_slug} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none disabled:opacity-50" data-testid="submit-subcategory-select">
                        <option value="">{form.category_slug ? "Select subcategory" : "Pick category first"}</option>
                        {subcategoryOptions.map((s) => (<option key={s} value={s}>{s}</option>))}
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">Short description <span className="text-red-500">*</span></label>
                    <input required maxLength={240} value={form.short_description} onChange={(e) => update("short_description", e.target.value)} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" placeholder="One line that hooks people (max 240 chars)" data-testid="submit-short-desc-input" />
                    <p className="text-xs text-zinc-400 mt-1 font-mono">{form.short_description.length}/240</p>
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">Full description <span className="text-red-500">*</span></label>
                    <textarea required rows={6} value={form.full_description} onChange={(e) => update("full_description", e.target.value)} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" placeholder="Describe in detail — what is it, who it's for, why it matters." data-testid="submit-full-desc-input" />
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">Tags</label>
                    <input value={form.tags} onChange={(e) => update("tags", e.target.value)} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" placeholder="Comma-separated, e.g. ai, productivity, mobile" data-testid="submit-tags-input" />
                  </div>
                </div>
              </fieldset>

              {/* Media */}
              <fieldset className="border border-zinc-200 bg-white p-6">
                <legend className="text-xs font-bold uppercase tracking-[0.2em] px-2">Media · upload or paste URLs</legend>
                <div className="space-y-5 mt-2">
                  <div>
                    <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">Featured image</label>
                    <ImageUploader
                      value={form.featured_image}
                      onChange={(url) => update("featured_image", url)}
                      aspect="aspect-video"
                      testId="submit-featured-image"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">Logo</label>
                    <ImageUploader
                      value={form.logo_url}
                      onChange={(url) => update("logo_url", url)}
                      aspect="aspect-square"
                      testId="submit-logo"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">Video URL</label>
                    <input type="url" value={form.video_url} onChange={(e) => update("video_url", e.target.value)} className={`w-full bg-zinc-50 border rounded-none px-3 py-2.5 text-sm font-mono focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none ${form.video_url && !parseVideoUrl(form.video_url) ? "border-red-400" : "border-zinc-200"}`} placeholder="https://youtube.com/watch?v=... · https://x.com/.../status/... · https://facebook.com/..." data-testid="submit-video-input" />
                    {form.video_url ? (
                      parseVideoUrl(form.video_url) ? (
                        <p className="text-xs text-green-700 mt-1.5 flex items-center gap-1" data-testid="video-url-valid">
                          <CheckCircle2 size={11} /> {{ youtube: "YouTube", facebook: "Facebook", twitter: "X / Twitter" }[parseVideoUrl(form.video_url).kind]} video will be embedded.
                        </p>
                      ) : (
                        <p className="text-xs text-red-600 mt-1.5 flex items-center gap-1" data-testid="video-url-invalid">
                          <AlertCircle size={11} /> Only YouTube, Facebook or X links are supported.
                        </p>
                      )
                    ) : (
                      <p className="text-xs text-zinc-500 mt-1.5">{VIDEO_PLATFORM_HINT}</p>
                    )}
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-zinc-900 mb-2 flex items-center justify-between">
                      Gallery images
                      <button type="button" onClick={() => update("gallery_images", [...form.gallery_images, ""])} className="text-blue-600 hover:underline text-xs" data-testid="add-gallery-btn">
                        <Plus size={11} className="inline mr-0.5" /> add
                      </button>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      {form.gallery_images.map((g, i) => (
                        <div key={i} className="relative">
                          <ImageUploader
                            value={g}
                            onChange={(url) => { const next = [...form.gallery_images]; next[i] = url; update("gallery_images", next); }}
                            aspect="aspect-video"
                            testId={`submit-gallery-${i}`}
                          />
                          {form.gallery_images.length > 1 && (
                            <button
                              type="button"
                              onClick={() => update("gallery_images", form.gallery_images.filter((_, j) => j !== i))}
                              className="absolute -top-2 -right-2 bg-white border border-zinc-300 hover:border-red-600 hover:text-red-600 w-6 h-6 grid place-items-center shadow-sm"
                              aria-label="Remove gallery slot"
                              data-testid={`remove-gallery-${i}`}
                            >
                              <X size={12} />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </fieldset>

              {/* Dynamic fields */}
              {dynamicFields.length > 0 && (
                <fieldset className="border border-zinc-200 bg-white p-6">
                  <legend className="text-xs font-bold uppercase tracking-[0.2em] px-2 flex items-center gap-2">
                    {categories.find((c) => c.slug === form.category_slug)?.name} details
                    <span className="text-zinc-400 normal-case font-normal tracking-normal text-[10px]">— all optional</span>
                  </legend>
                  <div className="grid sm:grid-cols-2 gap-5 mt-2">
                    {dynamicFields.map((f) => (
                      <div key={f.key} className={f.type === "textarea" ? "sm:col-span-2" : ""}>
                        <label className="text-sm font-semibold text-zinc-900 mb-1.5 flex items-center justify-between">
                          <span>{f.label}</span>
                          <span className="text-[10px] font-mono uppercase tracking-[0.15em] text-zinc-400">Optional</span>
                        </label>
                        {f.type === "textarea" ? (
                          <textarea rows={3} value={form.extra[f.key] || ""} onChange={(e) => updateExtra(f.key, e.target.value)} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" placeholder={f.placeholder} data-testid={`submit-extra-${f.key}`} />
                        ) : f.type === "select" ? (
                          <select value={form.extra[f.key] || ""} onChange={(e) => updateExtra(f.key, e.target.value)} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" data-testid={`submit-extra-${f.key}`}>
                            <option value="">Select {f.label.toLowerCase()}...</option>
                            {(f.options || []).map((opt) => (
                              <option key={opt} value={opt}>{opt}</option>
                            ))}
                          </select>
                        ) : (
                          <input type={f.type === "csv" ? "text" : f.type} value={form.extra[f.key] || ""} onChange={(e) => updateExtra(f.key, e.target.value)} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" placeholder={f.placeholder} data-testid={`submit-extra-${f.key}`} />
                        )}
                      </div>
                    ))}
                  </div>
                </fieldset>
              )}

              {/* Cast & Crew (entertainment only) */}
              {form.category_slug === "entertainment" && (
                <fieldset className="border border-zinc-200 bg-white p-6" data-testid="cast-crew-fieldset">
                  <legend className="text-xs font-bold uppercase tracking-[0.2em] px-2 flex items-center gap-2">
                    <Users size={11} /> Cast &amp; Crew
                    <span className="text-zinc-400 normal-case font-normal tracking-normal text-[10px]">— optional, add as many as you like</span>
                  </legend>
                  <div className="space-y-4 mt-2">
                    {(form.cast_members || []).map((c, i) => (
                      <CastAutocomplete
                        key={i}
                        value={c}
                        onChange={(next) => { const arr = [...form.cast_members]; arr[i] = next; setForm({ ...form, cast_members: arr }); }}
                        onRemove={() => setForm({ ...form, cast_members: form.cast_members.filter((_, j) => j !== i) })}
                        testId={`cast-row-${i}`}
                      />
                    ))}
                    <button
                      type="button"
                      onClick={() => setForm({ ...form, cast_members: [...(form.cast_members || []), { name: "", role: "", photo_url: "" }] })}
                      className="border border-dashed border-zinc-300 hover:border-zinc-900 w-full py-3 text-sm text-zinc-600 hover:text-zinc-900 transition-colors"
                      data-testid="add-cast-btn"
                    >
                      <Plus size={13} className="inline mr-1.5" /> Add cast / crew member
                    </button>
                  </div>
                </fieldset>
              )}
            </div>

            {/* Sticky sidebar */}
            <aside className="space-y-5 lg:sticky lg:top-24 self-start">
              <div className="border border-zinc-200 bg-white p-5">
                <div className="text-xs font-bold uppercase tracking-[0.2em] mb-3">Captcha</div>
                <div className="text-sm text-zinc-700 mb-2">{captcha.label || "Loading..."}</div>
                <div className="flex gap-2">
                  <input type="number" required value={form.captcha_a} onChange={(e) => update("captcha_a", e.target.value)} className="flex-1 bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-600" placeholder="Answer" data-testid="captcha-input" />
                  <button type="button" onClick={refreshCaptcha} className="px-3 border border-zinc-200 hover:border-zinc-900" aria-label="Refresh captcha" data-testid="captcha-refresh">
                    <RefreshCw size={14} />
                  </button>
                </div>
              </div>

              <Button type="submit" disabled={submitting || !slugStatus.available} className="rounded-none bg-blue-600 hover:bg-blue-700 text-white font-semibold w-full py-6 text-sm uppercase tracking-[0.15em]" data-testid="submit-post-btn">
                {submitting ? "Submitting..." : "Submit for review"}
              </Button>
              <Button type="button" variant="outline" onClick={() => setTab("preview")} className="rounded-none w-full py-6 text-sm uppercase tracking-[0.15em] border-zinc-200 hover:border-zinc-900" data-testid="preview-btn">
                <Eye size={13} className="mr-2" /> Preview
              </Button>
              <Button type="button" variant="ghost" onClick={clearDraft} className="rounded-none w-full text-zinc-500 hover:text-red-600 text-xs uppercase tracking-[0.15em]" data-testid="clear-draft-btn">
                Clear draft
              </Button>
              <p className="text-xs text-zinc-500 leading-relaxed flex items-start gap-2">
                <Save size={12} className="mt-0.5 flex-shrink-0" />
                Drafts are auto-saved locally. Submissions are reviewed by admins before going live.
              </p>
            </aside>
          </form>
        </TabsContent>

        <TabsContent value="preview">
          <PreviewCard form={form} categoryName={categories.find((c) => c.slug === form.category_slug)?.name} />
          <div className="mt-6 flex gap-3">
            <Button onClick={() => setTab("form")} variant="outline" className="rounded-none">← Back to edit</Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function PreviewCard({ form, categoryName }) {
  const parsedVideo = parseVideoUrl(form.video_url);
  return (
    <div className="border border-zinc-900 p-1 bg-white" data-testid="submit-preview">
      <div className="bg-zinc-50 p-8">
        <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500 mb-4">Preview · how it will appear once approved</div>
        <div className="grid lg:grid-cols-[280px_1fr] gap-8">
          <div className="aspect-[4/5] bg-zinc-200 overflow-hidden">
            {form.featured_image ? <img src={form.featured_image} alt="" className="w-full h-full object-cover" /> : <div className="w-full h-full grid place-items-center text-zinc-400 text-xs uppercase tracking-[0.2em]">No image</div>}
          </div>
          <div>
            <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-blue-600 mb-2">{categoryName || "Category"}{form.subcategory ? ` · ${form.subcategory}` : ""}</div>
            <h2 className="font-display font-black text-4xl tracking-tighter leading-none mb-4">{form.title || "Untitled listing"}</h2>
            <div className="flex items-center gap-2 mb-4">
              <StarRating value={0} size={16} />
              <span className="text-zinc-500 text-sm font-mono">No reviews yet</span>
            </div>
            <p className="text-zinc-600 leading-relaxed mb-3">{form.short_description || "Your one-liner will appear here."}</p>
            <p className="text-zinc-700 leading-relaxed whitespace-pre-line">{form.full_description || "Full description preview will appear here."}</p>
            {form.tags && (
              <div className="flex flex-wrap gap-2 mt-4">
                {form.tags.split(",").map((t) => t.trim()).filter(Boolean).map((t) => (
                  <span key={t} className="bg-zinc-100 text-zinc-900 rounded-none px-2 py-1 text-xs font-semibold tracking-wide uppercase">{t}</span>
                ))}
              </div>
            )}
            {parsedVideo && (
              <div className="mt-6">
                <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500 mb-2">
                  Video preview · {{ youtube: "YouTube", facebook: "Facebook", twitter: "X / Twitter" }[parsedVideo.kind]}
                </div>
                <VideoPlayerPreview url={form.video_url} title={form.title} />
              </div>
            )}
            {Object.entries(form.extra || {}).filter(([, v]) => v).length > 0 && (
              <dl className="grid sm:grid-cols-2 gap-x-8 gap-y-3 mt-6 text-sm">
                {Object.entries(form.extra).filter(([, v]) => v).map(([k, v]) => (
                  <div key={k} className="border-b border-zinc-100 pb-2">
                    <dt className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500 mb-1">{k.replace(/_/g, " ")}</dt>
                    <dd className="text-zinc-900 font-medium">{String(v)}</dd>
                  </div>
                ))}
              </dl>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
