import { useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import api from "@/lib/api";
import ItemCard from "@/components/ItemCard";
import { Search } from "lucide-react";

export default function SearchPage() {
  const [params, setParams] = useSearchParams();
  const q = params.get("q") || "";
  const category = params.get("category") || "";
  const sort = params.get("sort") || "trending";

  const [input, setInput] = useState(q);
  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    api.get("/categories").then((r) => setCategories(r.data));
  }, []);

  useEffect(() => {
    setLoading(true);
    const search = new URLSearchParams();
    if (q) search.set("q", q);
    if (category) search.set("category", category);
    search.set("sort", sort);
    search.set("limit", "48");
    api.get(`/items?${search.toString()}`)
      .then((r) => {
        setItems(r.data.items);
        setTotal(r.data.total);
      })
      .finally(() => setLoading(false));
  }, [q, category, sort]);

  const update = (key, value) => {
    const next = new URLSearchParams(params);
    if (value) next.set(key, value); else next.delete(key);
    setParams(next);
  };

  const onSubmit = (e) => {
    e.preventDefault();
    const next = new URLSearchParams(params);
    if (input) next.set("q", input); else next.delete("q");
    setParams(next);
  };

  return (
    <div data-testid="search-page">
      <section className="border-b border-zinc-200 bg-white">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-12">
          <div className="text-xs font-bold uppercase tracking-[0.3em] text-zinc-500 mb-3">Search</div>
          <h1 className="font-display font-black text-4xl lg:text-5xl tracking-tighter mb-6">
            {q ? <>Results for "<span className="text-blue-600">{q}</span>"</> : "Browse everything"}
          </h1>
          <form onSubmit={onSubmit} className="flex border border-zinc-900 max-w-2xl">
            <div className="flex-1 flex items-center pl-5">
              <Search size={16} className="text-zinc-400 mr-3" />
              <input
                type="search"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Search anything..."
                className="flex-1 py-3 outline-none text-sm bg-transparent"
                data-testid="search-input"
              />
            </div>
            <button type="submit" className="bg-zinc-900 hover:bg-blue-600 text-white px-6 font-semibold text-sm uppercase tracking-[0.15em] transition-colors" data-testid="search-submit">
              Search
            </button>
          </form>
        </div>
      </section>

      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-12">
        <div className="flex flex-col lg:flex-row gap-10">
          <aside className="lg:w-60 lg:flex-shrink-0">
            <div className="border-t border-zinc-900 pt-4">
              <div className="text-xs font-bold uppercase tracking-[0.2em] mb-3">Category</div>
              <div className="space-y-1.5">
                <button
                  onClick={() => update("category", "")}
                  className={`block text-left text-sm w-full py-1 ${!category ? "font-bold text-blue-600" : "text-zinc-600 hover:text-zinc-900"}`}
                  data-testid="filter-cat-all"
                >
                  All categories
                </button>
                {categories.map((c) => (
                  <button
                    key={c.slug}
                    onClick={() => update("category", c.slug)}
                    className={`block text-left text-sm w-full py-1 ${category === c.slug ? "font-bold text-blue-600" : "text-zinc-600 hover:text-zinc-900"}`}
                    data-testid={`filter-cat-${c.slug}`}
                  >
                    {c.name} <span className="text-zinc-400 text-xs">({c.item_count})</span>
                  </button>
                ))}
              </div>
            </div>
            <div className="border-t border-zinc-900 pt-4 mt-8">
              <div className="text-xs font-bold uppercase tracking-[0.2em] mb-3">Sort</div>
              <select
                value={sort}
                onChange={(e) => update("sort", e.target.value)}
                className="w-full bg-white border border-zinc-200 rounded-none px-3 py-2 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                data-testid="search-sort-select"
              >
                <option value="trending">Trending</option>
                <option value="rating">Highest rated</option>
                <option value="newest">Newest</option>
                <option value="reviews">Most reviewed</option>
              </select>
            </div>
          </aside>

          <div className="flex-1">
            <div className="text-xs font-mono uppercase tracking-[0.2em] text-zinc-500 mb-6">
              {loading ? "Loading..." : `${total} result${total === 1 ? "" : "s"}`}
            </div>
            {items.length === 0 && !loading ? (
              <div className="border border-zinc-200 p-16 text-center">
                <p className="text-zinc-500 mb-4">Nothing found{q ? ` for "${q}"` : ""}.</p>
                <button onClick={() => navigate("/")} className="text-blue-600 hover:underline text-sm">← Back home</button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-0 border-l border-t border-zinc-200" data-testid="search-results-grid">
                {items.map((it, i) => (
                  <div key={it.id} className="border-r border-b border-zinc-200 -ml-px -mt-px">
                    <ItemCard item={it} index={i} />
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
