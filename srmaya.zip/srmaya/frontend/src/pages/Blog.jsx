import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/contexts/AuthContext";
import { Plus, Eye, Heart, Calendar, BookOpen } from "lucide-react";

function fmtDate(iso) {
  try { return new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }); } catch { return ""; }
}

function PostCard({ p, featured = false, index = 0 }) {
  const initials = p.author_name?.split(" ").map((x) => x[0]).slice(0, 2).join("").toUpperCase();
  return (
    <Link
      to={`/blog/${p.slug}`}
      className={`group block border border-zinc-200 hover:border-zinc-900 bg-white transition-all duration-200 hover:-translate-y-1 fade-up ${featured ? "lg:col-span-2" : ""}`}
      style={{ animationDelay: `${(index % 6) * 50}ms` }}
      data-testid={`blog-card-${p.slug}`}
    >
      <div className={`bg-zinc-100 overflow-hidden ${featured ? "aspect-[21/9]" : "aspect-[16/9]"}`}>
        {p.cover_url ? (
          <img src={p.cover_url} alt={p.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy" />
        ) : (
          <div className="w-full h-full grid place-items-center text-zinc-300 font-display font-black text-4xl tracking-tighter">{p.title?.[0]}</div>
        )}
      </div>
      <div className="p-6">
        <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-blue-600 mb-3 flex items-center gap-2">
          {p.tag}
          {!p.published && <span className="bg-amber-100 text-amber-800 px-1.5 py-0.5">Draft</span>}
        </div>
        <h3 className={`font-display font-bold tracking-tight leading-tight mb-2 group-hover:text-blue-600 transition-colors line-clamp-2 ${featured ? "text-3xl" : "text-xl"}`}>{p.title}</h3>
        <p className="text-sm text-zinc-500 leading-relaxed line-clamp-2 mb-4">{p.excerpt}</p>
        <div className="flex items-center justify-between border-t border-zinc-100 pt-3">
          <div className="flex items-center gap-2">
            <Avatar className="h-7 w-7 rounded-none">
              <AvatarImage src={p.author_avatar} />
              <AvatarFallback className="rounded-none bg-zinc-900 text-white text-[10px]">{initials}</AvatarFallback>
            </Avatar>
            <span className="text-xs text-zinc-500">{p.author_name}</span>
          </div>
          <div className="text-xs font-mono text-zinc-400 flex items-center gap-3">
            <span className="flex items-center gap-1"><Calendar size={10} />{fmtDate(p.created_at)}</span>
            <span className="flex items-center gap-1"><Eye size={10} />{p.views || 0}</span>
            <span className="flex items-center gap-1"><Heart size={10} />{p.likes_count || 0}</span>
          </div>
        </div>
      </div>
    </Link>
  );
}

export default function Blog() {
  const [posts, setPosts] = useState([]);
  const [tags, setTags] = useState([]);
  const [tag, setTag] = useState("");
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => { api.get("/blog/tags").then((r) => setTags(r.data)); }, []);

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (tag) params.set("tag", tag);
    if (user && typeof user === "object" && user.role === "admin") params.set("include_drafts", "true");
    api.get(`/blog?${params.toString()}`).then((r) => setPosts(r.data)).finally(() => setLoading(false));
  }, [q, tag, user]);

  return (
    <div data-testid="blog-page">
      <section className="border-b border-zinc-200 bg-white">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-14 grid lg:grid-cols-12 gap-10 items-end">
          <div className="lg:col-span-8">
            <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-600 mb-4 flex items-center gap-2">
              <BookOpen size={12} /> Editorial · From the team
            </div>
            <h1 className="font-display font-black text-5xl lg:text-6xl tracking-tighter leading-none mb-5">
              Stories about<br />honest opinions.
            </h1>
            <p className="text-lg text-zinc-600 leading-relaxed max-w-2xl">
              Guides, launch notes, and observations from the Rateverse editorial team. Built to help you read between the stars.
            </p>
          </div>
          <div className="lg:col-span-4 flex lg:justify-end">
            {user && typeof user === "object" && user.role === "admin" && (
              <Button onClick={() => navigate("/blog/new")} className="rounded-none bg-blue-600 hover:bg-blue-700 text-white font-semibold px-7 py-6 text-sm uppercase tracking-[0.15em]" data-testid="new-blog-post-btn">
                <Plus size={14} className="mr-2" /> New post
              </Button>
            )}
          </div>
        </div>
      </section>

      <section className="border-b border-zinc-200 bg-white sticky top-16 z-20 backdrop-blur-xl bg-white/90">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-4 flex flex-wrap items-center gap-3" data-testid="blog-filters">
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search posts..." className="flex-1 min-w-[220px] bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" data-testid="blog-search" />
          <button onClick={() => setTag("")} className={`text-xs font-bold uppercase tracking-[0.15em] px-3 py-1.5 ${tag === "" ? "bg-zinc-900 text-white" : "bg-zinc-100 hover:bg-zinc-200"}`} data-testid="blog-tag-all">All</button>
          {tags.map((t) => (
            <button key={t} onClick={() => setTag(t)} className={`text-xs font-bold uppercase tracking-[0.15em] px-3 py-1.5 ${tag === t ? "bg-zinc-900 text-white" : "bg-zinc-100 hover:bg-zinc-200"}`} data-testid={`blog-tag-${t.toLowerCase()}`}>
              {t}
            </button>
          ))}
        </div>
      </section>

      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-12">
        {loading ? (
          <div className="text-zinc-400 text-xs uppercase tracking-[0.3em]">Loading posts...</div>
        ) : posts.length === 0 ? (
          <div className="border border-dashed border-zinc-300 p-16 text-center">
            <p className="text-zinc-500">No blog posts match those filters.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" data-testid="blog-grid">
            {posts.map((p, i) => (<PostCard key={p.id} p={p} featured={i === 0} index={i} />))}
          </div>
        )}
      </section>
    </div>
  );
}
