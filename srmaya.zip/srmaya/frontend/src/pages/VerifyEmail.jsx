import { useEffect, useState } from "react";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { CheckCircle2, XCircle, Loader2, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import api, { formatApiError } from "@/lib/api";
import { useAuth } from "@/contexts/AuthContext";

export default function VerifyEmail() {
  const { user, refresh } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const params = new URLSearchParams(location.search);
  const urlToken = params.get("token");
  const [status, setStatus] = useState("idle"); // idle | loading | ok | error
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (!urlToken) return;
    (async () => {
      setStatus("loading");
      try {
        await api.post("/auth/verify/confirm", { token: urlToken });
        setStatus("ok");
        setMessage("Your email is verified. You can now publish reviews, posts and submissions.");
        await refresh?.();
      } catch (err) {
        setStatus("error");
        setMessage(formatApiError(err.response?.data?.detail) || "Could not verify this link.");
      }
    })();
  }, [urlToken]);

  return (
    <div className="max-w-[720px] mx-auto px-6 lg:px-10 py-16" data-testid="verify-email-page">
      <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-600 mb-3">Account</div>
      <h1 className="font-display font-black text-4xl lg:text-5xl tracking-tighter mb-3">
        Verify your email
      </h1>
      <p className="text-zinc-600 leading-relaxed mb-8">
        We use email verification to keep Rateverse honest. Once your email is confirmed you can post reviews, share to the feed, comment in groups and submit new listings.
      </p>

      {urlToken && (
        <div className="border border-zinc-200 bg-white p-8 mb-8" data-testid="verify-result">
          {status === "loading" && (
            <div className="flex items-center gap-3 text-zinc-700">
              <Loader2 size={18} className="animate-spin text-blue-600" />
              <div>Verifying your link…</div>
            </div>
          )}
          {status === "ok" && (
            <div>
              <div className="flex items-center gap-3 mb-3">
                <CheckCircle2 size={24} className="text-green-600" />
                <div className="font-display font-black text-2xl tracking-tighter">You're verified.</div>
              </div>
              <p className="text-zinc-600 leading-relaxed mb-5">{message}</p>
              <Button onClick={() => navigate("/")} className="rounded-none bg-blue-600 hover:bg-blue-700 text-white">
                Continue
              </Button>
            </div>
          )}
          {status === "error" && (
            <div>
              <div className="flex items-center gap-3 mb-3">
                <XCircle size={24} className="text-red-600" />
                <div className="font-display font-black text-2xl tracking-tighter">Link no longer valid</div>
              </div>
              <p className="text-zinc-600 leading-relaxed mb-5">{message}</p>
              {user && typeof user === "object" && !user.email_verified && (
                <Link to="/verify-email">
                  <Button className="rounded-none bg-blue-600 hover:bg-blue-700 text-white">Request a fresh link</Button>
                </Link>
              )}
            </div>
          )}
        </div>
      )}

      <div className="border border-zinc-200 bg-white p-8">
        <div className="flex items-center gap-2 mb-3 text-zinc-700">
          <Mail size={16} /> <span className="text-xs font-bold uppercase tracking-[0.2em]">How verification works</span>
        </div>
        <ol className="list-decimal pl-5 space-y-2 text-sm text-zinc-700 leading-relaxed">
          <li>Click <strong>Resend link</strong> in the banner or below.</li>
          <li>We generate a secure single-use link that expires in 24 hours.</li>
          <li>Open the link to mark your account as verified.</li>
          <li>Reload any page — the yellow banner will disappear.</li>
        </ol>
        {user && typeof user === "object" && !user.email_verified ? (
          <ResendButton />
        ) : user?.email_verified ? (
          <div className="mt-6 flex items-center gap-2 text-green-700 text-sm">
            <CheckCircle2 size={15} /> Your email is verified. Nothing to do.
          </div>
        ) : (
          <p className="mt-6 text-sm text-zinc-500">Sign in first to request a link.</p>
        )}
      </div>
    </div>
  );
}

function ResendButton() {
  const [busy, setBusy] = useState(false);
  const [link, setLink] = useState("");
  const send = async () => {
    setBusy(true);
    try {
      const { data } = await api.post("/auth/verify/send");
      if (data.already_verified) { setLink(""); return; }
      setLink(`${window.location.origin}/verify-email?token=${encodeURIComponent(data.token)}`);
    } catch (err) {
      setLink("");
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="mt-6 space-y-3">
      <Button onClick={send} disabled={busy} className="rounded-none bg-blue-600 hover:bg-blue-700 text-white" data-testid="verify-page-resend-btn">
        {busy ? "Sending…" : "Send me a verification link"}
      </Button>
      {link && (
        <div className="border border-blue-200 bg-blue-50 p-3 text-xs font-mono break-all" data-testid="verify-dev-link">
          Dev-mode link: <a href={link} className="text-blue-700 hover:underline">{link}</a>
        </div>
      )}
    </div>
  );
}
