import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Bell, CheckCheck, Trash2, UserPlus, Heart, MessageCircle, Star } from "lucide-react";

const ICON_BY_TYPE = {
  follow: UserPlus,
  like_post: Heart,
  comment_post: MessageCircle,
  like_comment: Heart,
  review: Star,
  group_post_like: Heart,
};

function timeAgo(iso) {
  if (!iso) return "";
  const s = Math.round((Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  if (s < 86400) return `${Math.round(s / 3600)}h ago`;
  return `${Math.round(s / 86400)}d ago`;
}

export default function NotificationsPage() {
  const navigate = useNavigate();
  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [skip, setSkip] = useState(0);
  const [loading, setLoading] = useState(true);
  const [onlyUnread, setOnlyUnread] = useState(false);
  const LIMIT = 25;

  const load = async (reset = false) => {
    setLoading(true);
    try {
      const s = reset ? 0 : skip;
      const { data } = await api.get(`/notifications?limit=${LIMIT}&skip=${s}&only_unread=${onlyUnread}`);
      setTotal(data.total || 0);
      setItems(reset ? data.items : [...items, ...data.items]);
      setSkip(s + data.items.length);
    } finally { setLoading(false); }
  };

  useEffect(() => { load(true); /* eslint-disable-next-line */ }, [onlyUnread]);

  const markAll = async () => {
    await api.post("/notifications/read-all");
    setItems((xs) => xs.map((x) => ({ ...x, read: true })));
  };

  const remove = async (n) => {
    await api.delete(`/notifications/${n.id}`);
    setItems((xs) => xs.filter((x) => x.id !== n.id));
    setTotal((t) => t - 1);
  };

  const open = async (n) => {
    if (!n.read) { try { await api.post(`/notifications/${n.id}/read`); } catch { /* noop */ } }
    if (n.link) navigate(n.link);
  };

  return (
    <div className="max-w-[900px] mx-auto px-6 lg:px-10 py-12" data-testid="notifications-page">
      <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-600 mb-3 flex items-center gap-2">
        <Bell size={12} /> Activity
      </div>
      <div className="flex items-end justify-between mb-6 flex-wrap gap-3">
        <h1 className="font-display font-black text-4xl lg:text-5xl tracking-tighter">Notifications</h1>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setOnlyUnread((v) => !v)}
            className={`text-xs font-bold uppercase tracking-[0.15em] px-3 py-1.5 border ${onlyUnread ? "border-blue-600 bg-blue-600 text-white" : "border-zinc-200 hover:border-zinc-900"}`}
            data-testid="filter-unread-btn"
          >
            {onlyUnread ? "Unread only" : "All"}
          </button>
          <Button onClick={markAll} variant="outline" className="rounded-none text-xs uppercase tracking-[0.15em] border-zinc-200" data-testid="mark-all-page-btn">
            <CheckCheck size={13} className="mr-1.5" /> Mark all read
          </Button>
        </div>
      </div>

      {items.length === 0 ? (
        <div className="border border-dashed border-zinc-300 p-12 text-center text-zinc-500">
          <Bell size={22} className="mx-auto text-zinc-300 mb-3" />
          <p>{onlyUnread ? "No unread notifications." : "No notifications yet."}</p>
        </div>
      ) : (
        <div className="border border-zinc-200 bg-white" data-testid="notifications-list">
          {items.map((n) => {
            const Icon = ICON_BY_TYPE[n.type] || Bell;
            const initials = n.actor_name?.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();
            return (
              <div key={n.id} className={`flex items-start gap-4 p-4 border-b border-zinc-100 last:border-0 ${!n.read ? "bg-blue-50/40" : ""}`} data-testid={`notification-row-${n.id}`}>
                <div className="relative flex-shrink-0">
                  <Avatar className="h-10 w-10 rounded-none">
                    <AvatarImage src={n.actor_avatar} />
                    <AvatarFallback className="rounded-none bg-zinc-900 text-white text-xs">{initials}</AvatarFallback>
                  </Avatar>
                  <div className="absolute -bottom-1 -right-1 bg-blue-600 text-white p-0.5">
                    <Icon size={10} />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <button onClick={() => open(n)} className="text-left w-full hover:text-blue-600 transition-colors">
                    <div className="text-sm text-zinc-800">{n.message}</div>
                  </button>
                  <div className="text-[10px] text-zinc-400 font-mono uppercase mt-1">{timeAgo(n.created_at)}</div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  {!n.read && <span className="w-2 h-2 bg-blue-600 rounded-full" aria-label="Unread" />}
                  <button onClick={() => remove(n)} className="text-zinc-400 hover:text-red-600" aria-label="Delete" data-testid={`delete-notif-${n.id}`}>
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {items.length < total && (
        <div className="mt-6 text-center">
          <Button onClick={() => load(false)} disabled={loading} variant="outline" className="rounded-none" data-testid="load-more-btn">
            {loading ? "Loading…" : `Load more (${total - items.length} left)`}
          </Button>
        </div>
      )}
    </div>
  );
}
