import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import api, { formatApiError } from "@/lib/api";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { UserPlus, UserMinus, Users, MessageSquare } from "lucide-react";
import { toast } from "sonner";
import { PostCard } from "./Feed";

export default function UserProfile() {
  const { user_id } = useParams();
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await api.get(`/feed/users/${user_id}/profile`);
      setProfile(data);
      const p = await api.get(`/feed?user_id=${user_id}`);
      setPosts(p.data);
    } catch {
      setProfile(null);
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [user_id, user]); // eslint-disable-line

  const handleFollow = async () => {
    if (!user || typeof user !== "object") { toast.error("Sign in to follow people."); return; }
    try {
      if (profile.is_following) {
        await api.delete(`/follows/${user_id}`);
      } else {
        await api.post(`/follows/${user_id}`);
      }
      load();
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  if (loading && !profile) return <div className="max-w-[1100px] mx-auto px-6 py-20 text-zinc-400 text-xs uppercase tracking-[0.3em]">Loading...</div>;
  if (!profile) {
    return (
      <div className="max-w-[1100px] mx-auto px-6 py-20">
        <h1 className="font-display font-black text-3xl mb-4">User not found</h1>
        <Link to="/feed" className="text-blue-600 hover:underline">← Back to feed</Link>
      </div>
    );
  }

  const u = profile.user;
  const s = profile.stats;
  const initials = u.name?.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();
  const isSelf = profile.is_self;

  return (
    <div data-testid="user-profile-page">
      <section className="bg-zinc-900 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, rgba(255,255,255,0.4) 1px, transparent 0)", backgroundSize: "24px 24px" }} />
        <div className="relative max-w-[1100px] mx-auto px-6 lg:px-10 py-14 grid lg:grid-cols-[auto_1fr_auto] gap-6 items-end">
          <Avatar className="h-32 w-32 rounded-none border-4 border-white/10">
            <AvatarImage src={u.avatar_url} />
            <AvatarFallback className="rounded-none bg-blue-600 text-white font-display font-black text-4xl">{initials}</AvatarFallback>
          </Avatar>
          <div>
            <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-400 mb-2">{u.role === "admin" ? "Site Admin · " : ""}Member</div>
            <h1 className="font-display font-black text-5xl tracking-tighter leading-none mb-2" data-testid="profile-name">{u.name}</h1>
            {u.bio && <p className="text-zinc-300 max-w-2xl mb-3 leading-relaxed">{u.bio}</p>}
            <div className="flex items-center gap-5 text-sm text-zinc-300">
              <span><strong className="text-white">{s.followers}</strong> followers</span>
              <span><strong className="text-white">{s.following}</strong> following</span>
              <span><strong className="text-white">{s.posts}</strong> posts</span>
              <span><strong className="text-white">{s.reviews}</strong> reviews</span>
            </div>
          </div>
          <div className="flex gap-2 lg:justify-end">
            {isSelf ? (
              <Link to="/profile"><Button variant="outline" className="rounded-none border-white/30 bg-transparent text-white hover:bg-white hover:text-zinc-900 px-6 py-5 text-xs uppercase tracking-[0.15em] font-bold" data-testid="edit-profile-btn">Edit profile</Button></Link>
            ) : (
              <Button onClick={handleFollow} className={`rounded-none px-7 py-5 text-xs uppercase tracking-[0.15em] font-bold ${profile.is_following ? "bg-white text-zinc-900 hover:bg-zinc-200" : "bg-blue-600 hover:bg-blue-500 text-white"}`} data-testid="follow-btn">
                {profile.is_following ? <><UserMinus size={13} className="mr-1.5" /> Unfollow</> : <><UserPlus size={13} className="mr-1.5" /> Follow</>}
              </Button>
            )}
          </div>
        </div>
      </section>

      <section className="max-w-[1100px] mx-auto px-6 lg:px-10 py-10">
        <Tabs defaultValue="posts" className="w-full">
          <TabsList className="rounded-none bg-transparent border-b border-zinc-200 w-full justify-start gap-1 px-0 h-auto mb-6">
            <TabsTrigger value="posts" className="rounded-none data-[state=active]:bg-zinc-900 data-[state=active]:text-white px-5 py-2.5 text-xs uppercase tracking-[0.2em] font-bold" data-testid="profile-tab-posts">
              <MessageSquare size={11} className="mr-1.5" /> Posts ({s.posts})
            </TabsTrigger>
            <TabsTrigger value="followers" className="rounded-none data-[state=active]:bg-zinc-900 data-[state=active]:text-white px-5 py-2.5 text-xs uppercase tracking-[0.2em] font-bold" data-testid="profile-tab-followers">
              <Users size={11} className="mr-1.5" /> Followers ({s.followers})
            </TabsTrigger>
            <TabsTrigger value="following" className="rounded-none data-[state=active]:bg-zinc-900 data-[state=active]:text-white px-5 py-2.5 text-xs uppercase tracking-[0.2em] font-bold" data-testid="profile-tab-following">Following ({s.following})</TabsTrigger>
          </TabsList>

          <TabsContent value="posts">
            {posts.length === 0 ? (
              <div className="border border-dashed border-zinc-300 p-12 text-center text-zinc-500">No posts yet.</div>
            ) : (
              <div className="space-y-4">
                {posts.map((p) => (<PostCard key={p.id} post={p} currentUser={user} onUpdate={(np) => setPosts((ps) => ps.map((x) => x.id === np.id ? { ...x, ...np } : x))} onDelete={async (post) => { if (confirm("Delete?")) { await api.delete(`/feed/posts/${post.id}`); load(); } }} />))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="followers">
            <FollowList endpoint={`/follows/${u.id}/followers`} emptyText="No followers yet." />
          </TabsContent>
          <TabsContent value="following">
            <FollowList endpoint={`/follows/${u.id}/following`} emptyText="Not following anyone yet." />
          </TabsContent>
        </Tabs>
      </section>
    </div>
  );
}

function FollowList({ endpoint, emptyText }) {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => { api.get(endpoint).then((r) => setUsers(r.data)).finally(() => setLoading(false)); }, [endpoint]);
  if (loading) return <div className="text-zinc-400 text-xs uppercase tracking-[0.3em]">Loading...</div>;
  if (users.length === 0) return <div className="border border-dashed border-zinc-300 p-12 text-center text-zinc-500">{emptyText}</div>;
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3" data-testid="follow-list">
      {users.map((u) => {
        const initials = u.name?.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();
        return (
          <Link key={u.id} to={`/u/${u.id}`} className="border border-zinc-200 bg-white p-4 hover:border-zinc-900 transition-colors flex items-center gap-3" data-testid={`follow-user-${u.id}`}>
            <Avatar className="h-10 w-10 rounded-none">
              <AvatarImage src={u.avatar_url} />
              <AvatarFallback className="rounded-none bg-zinc-900 text-white text-xs">{initials}</AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <div className="font-semibold text-sm truncate">{u.name}</div>
              <div className="text-xs text-zinc-500 truncate">{u.email}</div>
            </div>
          </Link>
        );
      })}
    </div>
  );
}
