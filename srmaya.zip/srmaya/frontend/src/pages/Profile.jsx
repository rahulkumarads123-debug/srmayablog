import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import api, { formatApiError } from "@/lib/api";
import ReviewCard from "@/components/ReviewCard";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Plus, FileText, Clock, CheckCircle2, XCircle, Camera, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";

const STATUS_META = {
  pending: { label: "Pending review", className: "bg-amber-100 text-amber-800", Icon: Clock },
  approved: { label: "Approved & published", className: "bg-green-100 text-green-800", Icon: CheckCircle2 },
  rejected: { label: "Rejected", className: "bg-red-100 text-red-700", Icon: XCircle },
};

export default function Profile() {
  const { user, refresh } = useAuth();
  const [reviews, setReviews] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [avatarUploading, setAvatarUploading] = useState(false);

  const load = () => {
    setLoading(true);
    Promise.all([
      api.get("/users/me/reviews"),
      api.get("/submissions/me"),
    ]).then(([rev, sub]) => {
      setReviews(rev.data);
      setSubmissions(sub.data);
    }).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const handleAvatarPick = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!file.type?.startsWith("image/")) { toast.error("Pick an image (JPG, PNG, WEBP, GIF)."); return; }
    if (file.size > 10 * 1024 * 1024) { toast.error("Max size is 10 MB."); return; }
    setAvatarUploading(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const { data } = await api.post("/uploads/image", fd, { headers: { "Content-Type": "multipart/form-data" } });
      await api.patch("/auth/me", { avatar_url: data.url });
      await refresh?.();
      toast.success("Avatar updated.");
    } catch (err) {
      toast.error(formatApiError(err.response?.data?.detail) || "Failed");
    } finally {
      setAvatarUploading(false);
    }
  };

  const handleDelete = async (review) => {
    if (!confirm("Delete this review?")) return;
    try {
      await api.delete(`/reviews/${review.id}`);
      toast.success("Review deleted.");
      load();
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  if (!user || typeof user !== "object") return null;

  const initials = user.name?.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();
  const pendingCount = submissions.filter((s) => s.status === "pending").length;
  const approvedCount = submissions.filter((s) => s.status === "approved").length;
  const rejectedCount = submissions.filter((s) => s.status === "rejected").length;

  return (
    <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-12" data-testid="profile-page">
      <section className="border border-zinc-200 bg-white p-8 mb-10 grid sm:grid-cols-[auto_1fr_auto] gap-6 items-center">
        <div className="relative group">
          <Avatar className="h-20 w-20 rounded-none">
            <AvatarImage src={user.avatar_url} />
            <AvatarFallback className="rounded-none bg-zinc-900 text-white font-display font-black text-2xl">{initials}</AvatarFallback>
          </Avatar>
          <label
            className="absolute inset-0 bg-zinc-900/60 opacity-0 group-hover:opacity-100 transition-opacity grid place-items-center cursor-pointer text-white text-[10px] font-bold uppercase tracking-[0.15em]"
            data-testid="avatar-upload-label"
          >
            {avatarUploading ? (
              <Loader2 size={18} className="animate-spin" />
            ) : (
              <><Camera size={16} className="mb-0.5" /><span>Change</span></>
            )}
            <input
              type="file"
              accept="image/jpeg,image/png,image/webp,image/gif"
              className="hidden"
              onChange={handleAvatarPick}
              disabled={avatarUploading}
              data-testid="avatar-upload-input"
            />
          </label>
        </div>
        <div>
          <div className="text-xs font-bold uppercase tracking-[0.3em] text-zinc-500 mb-2">Your profile</div>
          <h1 className="font-display font-black text-3xl lg:text-4xl tracking-tighter">{user.name}</h1>
          <p className="text-sm text-zinc-500 mt-1">{user.email} · {user.role}</p>
        </div>
        <div className="hidden sm:flex gap-6 border-l border-zinc-200 pl-6">
          <div>
            <div className="font-display font-black text-3xl tracking-tighter">{reviews.length}</div>
            <div className="text-[10px] font-mono uppercase tracking-[0.2em] text-zinc-500">Reviews</div>
          </div>
          <div>
            <div className="font-display font-black text-3xl tracking-tighter">{submissions.length}</div>
            <div className="text-[10px] font-mono uppercase tracking-[0.2em] text-zinc-500">Submissions</div>
          </div>
        </div>
      </section>

      <Tabs defaultValue="reviews" className="w-full">
        <TabsList className="rounded-none bg-transparent border-b border-zinc-200 w-full justify-start gap-1 px-0 mb-6 h-auto">
          <TabsTrigger value="reviews" className="rounded-none data-[state=active]:bg-zinc-900 data-[state=active]:text-white px-5 py-2.5 text-xs uppercase tracking-[0.2em] font-bold" data-testid="profile-tab-reviews">
            My Reviews ({reviews.length})
          </TabsTrigger>
          <TabsTrigger value="submissions" className="rounded-none data-[state=active]:bg-zinc-900 data-[state=active]:text-white px-5 py-2.5 text-xs uppercase tracking-[0.2em] font-bold" data-testid="profile-tab-submissions">
            My Submissions ({submissions.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="reviews">
          {loading ? (
            <div className="text-zinc-400 text-xs uppercase tracking-[0.3em]">Loading...</div>
          ) : reviews.length === 0 ? (
            <div className="border border-dashed border-zinc-300 p-12 text-center">
              <p className="text-zinc-500">You haven't reviewed anything yet.</p>
            </div>
          ) : (
            <div data-testid="profile-reviews-list">
              {reviews.map((r) => (
                <ReviewCard key={r.id} review={r} onDelete={handleDelete} showItemLink />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="submissions">
          <div className="flex items-end justify-between mb-5">
            <div className="flex gap-3 text-xs font-mono uppercase tracking-[0.2em] text-zinc-500">
              <span><Clock size={11} className="inline mr-1" />Pending {pendingCount}</span>
              <span><CheckCircle2 size={11} className="inline mr-1" />Approved {approvedCount}</span>
              <span><XCircle size={11} className="inline mr-1" />Rejected {rejectedCount}</span>
            </div>
            <Link to="/submit-post">
              <Button className="rounded-none bg-blue-600 hover:bg-blue-700 text-white font-semibold" data-testid="profile-new-submission-btn">
                <Plus size={14} className="mr-1.5" /> New submission
              </Button>
            </Link>
          </div>
          {submissions.length === 0 ? (
            <div className="border border-dashed border-zinc-300 p-12 text-center">
              <FileText size={28} className="mx-auto text-zinc-300 mb-3" />
              <p className="text-zinc-500 mb-4">No submissions yet — propose a new listing for the community.</p>
              <Link to="/submit-post">
                <Button className="rounded-none bg-blue-600 hover:bg-blue-700 text-white font-semibold">
                  <Plus size={14} className="mr-1.5" /> Submit your first
                </Button>
              </Link>
            </div>
          ) : (
            <div className="border border-zinc-200" data-testid="profile-submissions-list">
              {submissions.map((s) => {
                const meta = STATUS_META[s.status] || STATUS_META.pending;
                const Icon = meta.Icon;
                return (
                  <div key={s.id} className="grid lg:grid-cols-[100px_1fr_auto] gap-5 p-5 border-b last:border-b-0 border-zinc-200" data-testid={`submission-row-${s.id}`}>
                    <div className="aspect-[4/3] bg-zinc-100 overflow-hidden hidden lg:block">
                      {s.featured_image ? <img src={s.featured_image} alt="" className="w-full h-full object-cover" /> : <div className="w-full h-full grid place-items-center text-zinc-400 text-[10px] uppercase">No img</div>}
                    </div>
                    <div className="min-w-0">
                      <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500 mb-1">{s.category_name}{s.subcategory ? ` · ${s.subcategory}` : ""}</div>
                      <h3 className="font-display font-bold text-lg tracking-tight leading-tight mb-1">
                        {s.status === "approved" ? (
                          <Link to={`/item/${s.slug}`} className="hover:text-blue-600">{s.title}</Link>
                        ) : (
                          s.title
                        )}
                      </h3>
                      <p className="text-sm text-zinc-600 line-clamp-2 mb-2">{s.short_description}</p>
                      <p className="text-xs text-zinc-400 font-mono">Submitted {new Date(s.created_at).toLocaleDateString()}</p>
                      {s.admin_notes && s.status === "rejected" && (
                        <div className="mt-2 text-xs text-red-700 bg-red-50 border-l-2 border-red-500 px-3 py-2">
                          <strong>Admin notes:</strong> {s.admin_notes}
                        </div>
                      )}
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <span className={`inline-flex items-center gap-1 ${meta.className} text-[10px] font-bold uppercase tracking-[0.15em] px-2.5 py-1`} data-testid={`submission-status-${s.id}`}>
                        <Icon size={11} /> {meta.label}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
