import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Users, MessageSquare, Plus, Search } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

function GroupCard({ g, index = 0 }) {
  return (
    <Link
      to={`/groups/${g.slug}`}
      className="group block border border-zinc-200 hover:border-zinc-900 bg-white transition-all duration-200 hover:-translate-y-1 fade-up"
      style={{ animationDelay: `${(index % 6) * 50}ms` }}
      data-testid={`group-card-${g.slug}`}
    >
      <div className="aspect-[16/9] bg-zinc-100 overflow-hidden relative">
        {g.cover_url ? (
          <img src={g.cover_url} alt={g.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy" />
        ) : (
          <div className="w-full h-full grid place-items-center text-zinc-300 font-display font-black text-4xl tracking-tighter">{g.name?.[0]}</div>
        )}
      </div>
      <div className="p-5">
        {g.category_slug && (
          <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500 mb-2">{g.category_slug}</div>
        )}
        <h3 className="font-display font-bold text-xl tracking-tight leading-tight mb-2 group-hover:text-blue-600 transition-colors line-clamp-1">{g.name}</h3>
        <p className="text-sm text-zinc-500 leading-relaxed line-clamp-2 mb-4">{g.description}</p>
        <div className="flex items-center gap-4 border-t border-zinc-100 pt-3 text-xs text-zinc-500 font-mono">
          <span className="flex items-center gap-1.5"><Users size={11} /> {g.member_count} members</span>
          <span className="flex items-center gap-1.5"><MessageSquare size={11} /> {g.post_count} posts</span>
        </div>
      </div>
    </Link>
  );
}

export default function Groups() {
  const [groups, setGroups] = useState([]);
  const [categories, setCategories] = useState([]);
  const [q, setQ] = useState("");
  const [category, setCategory] = useState("");
  const [sort, setSort] = useState("popular");
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { user } = useAuth();

  useEffect(() => { api.get("/categories").then((r) => setCategories(r.data)); }, []);

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (category) params.set("category", category);
    params.set("sort", sort);
    api.get(`/groups?${params.toString()}`).then((r) => setGroups(r.data)).finally(() => setLoading(false));
  }, [q, category, sort]);

  return (
    <div data-testid="groups-page">
      <section className="border-b border-zinc-200 bg-white">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-14 grid lg:grid-cols-12 gap-10 items-end">
          <div className="lg:col-span-8">
            <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-600 mb-4 flex items-center gap-2">
              <Users size={12} /> Community · Find your people
            </div>
            <h1 className="font-display font-black text-5xl lg:text-6xl tracking-tighter leading-none mb-5">
              Groups where the<br />opinions get sharp.
            </h1>
            <p className="text-lg text-zinc-600 leading-relaxed max-w-2xl">
              Join communities organized around what you actually care about — pick films apart with sci-fi obsessives, share honest employer takes, swap indie app launches.
            </p>
          </div>
          <div className="lg:col-span-4 flex lg:justify-end">
            <Button
              onClick={() => navigate(user && typeof user === "object" ? "/groups/new" : "/login")}
              className="rounded-none bg-blue-600 hover:bg-blue-700 text-white font-semibold px-7 py-6 text-sm uppercase tracking-[0.15em]"
              data-testid="create-group-btn"
            >
              <Plus size={14} className="mr-2" /> Create a group
            </Button>
          </div>
        </div>
      </section>

      <section className="border-b border-zinc-200 bg-white sticky top-16 z-20 backdrop-blur-xl bg-white/90">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-4 flex flex-wrap items-center gap-3" data-testid="groups-filters">
          <div className="relative flex-1 min-w-[240px]">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search groups..." className="w-full bg-zinc-50 border border-zinc-200 rounded-none pl-9 pr-3 py-2 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" data-testid="groups-search-input" />
          </div>
          <select value={category} onChange={(e) => setCategory(e.target.value)} className="bg-white border border-zinc-200 rounded-none px-3 py-2 text-xs uppercase tracking-[0.15em] font-bold focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" data-testid="groups-filter-category">
            <option value="">All categories</option>
            {categories.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}
          </select>
          <select value={sort} onChange={(e) => setSort(e.target.value)} className="bg-white border border-zinc-200 rounded-none px-3 py-2 text-xs uppercase tracking-[0.15em] font-bold focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" data-testid="groups-sort">
            <option value="popular">Most members</option>
            <option value="active">Most active</option>
            <option value="newest">Newest</option>
          </select>
        </div>
      </section>

      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-12">
        {loading ? (
          <div className="text-zinc-400 text-xs uppercase tracking-[0.3em]">Loading groups...</div>
        ) : groups.length === 0 ? (
          <div className="border border-dashed border-zinc-300 p-16 text-center">
            <p className="text-zinc-500">No groups match those filters yet.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-0 border-l border-t border-zinc-200" data-testid="groups-grid">
            {groups.map((g, i) => (
              <div key={g.id} className="border-r border-b border-zinc-200 -ml-px -mt-px">
                <GroupCard g={g} index={i} />
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
