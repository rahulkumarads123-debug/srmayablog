import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "@/lib/api";
import StarRating from "@/components/StarRating";
import { Trophy } from "lucide-react";

export default function Top10() {
  const [items, setItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [activeCat, setActiveCat] = useState("");

  useEffect(() => {
    api.get("/categories").then((r) => setCategories(r.data));
  }, []);

  useEffect(() => {
    const url = activeCat ? `/items/top?limit=10&category=${activeCat}` : "/items/top?limit=10";
    api.get(url).then((r) => setItems(r.data));
  }, [activeCat]);

  return (
    <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-12" data-testid="top10-page">
      <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-600 mb-3 flex items-center gap-2">
        <Trophy size={12} /> Rankings
      </div>
      <h1 className="font-display font-black text-5xl lg:text-7xl tracking-tighter leading-none mb-8">Top 10 of everything</h1>
      <p className="text-lg text-zinc-600 max-w-2xl mb-10 leading-relaxed">
        The highest rated listings across the platform — auto-updated based on real reviews from real people.
      </p>

      <div className="flex flex-wrap gap-2 mb-10 border-y border-zinc-200 py-4">
        <button onClick={() => setActiveCat("")} className={`text-xs font-bold uppercase tracking-[0.15em] px-3 py-1.5 ${activeCat === "" ? "bg-zinc-900 text-white" : "bg-zinc-100 hover:bg-zinc-200"}`} data-testid="top10-cat-all">All</button>
        {categories.map((c) => (
          <button
            key={c.slug}
            onClick={() => setActiveCat(c.slug)}
            className={`text-xs font-bold uppercase tracking-[0.15em] px-3 py-1.5 ${activeCat === c.slug ? "bg-zinc-900 text-white" : "bg-zinc-100 hover:bg-zinc-200"}`}
            data-testid={`top10-cat-${c.slug}`}
          >
            {c.name}
          </button>
        ))}
      </div>

      <div className="border-t border-zinc-200" data-testid="top10-list">
        {items.length === 0 ? (
          <div className="py-16 text-center text-zinc-500">No items in this view yet.</div>
        ) : items.map((it, i) => (
          <Link to={`/item/${it.slug}`} key={it.id} className="grid grid-cols-[auto_120px_1fr_auto] gap-6 py-6 border-b border-zinc-200 hover:bg-zinc-50 -mx-3 px-3 group transition-colors fade-up" style={{ animationDelay: `${i * 50}ms` }} data-testid={`top10-row-${it.slug}`}>
            <div className="font-display font-black text-6xl tracking-tighter w-20 text-zinc-200 group-hover:text-blue-600 transition-colors leading-none">
              {String(i + 1).padStart(2, "0")}
            </div>
            <div className="aspect-[4/3] w-[120px] bg-zinc-100 overflow-hidden">
              {it.image_url && (<img src={it.image_url} alt="" className="w-full h-full object-cover" />)}
            </div>
            <div className="min-w-0">
              <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500 mb-2">{it.category_name}</div>
              <h3 className="font-display font-bold text-2xl tracking-tighter leading-tight mb-2 group-hover:text-blue-600 transition-colors">{it.name}</h3>
              <p className="text-sm text-zinc-600 line-clamp-2 max-w-2xl">{it.description}</p>
            </div>
            <div className="text-right self-center">
              <div className="font-display font-black text-3xl tracking-tighter">{it.avg_rating.toFixed(1)}</div>
              <div className="my-1"><StarRating value={it.avg_rating} size={12} /></div>
              <div className="text-xs text-zinc-500 font-mono">{it.review_count} reviews</div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
