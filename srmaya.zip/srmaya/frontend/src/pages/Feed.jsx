import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api, { formatApiError } from "@/lib/api";
import { useAuth } from "@/contexts/AuthContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Heart, MessageCircle, Bookmark, Repeat2, Trash2, Send, Image as ImgIcon, Hash, X } from "lucide-react";
import { toast } from "sonner";
import ImageUploader from "@/components/ImageUploader";

function timeAgo(iso) {
  if (!iso) return "";
  const s = Math.round((Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.round(s / 60)}m`;
  if (s < 86400) return `${Math.round(s / 3600)}h`;
  return `${Math.round(s / 86400)}d`;
}

function decorateBody(body) {
  if (!body) return null;
  const parts = body.split(/(\s+)/);
  return parts.map((part, i) => {
    if (part.startsWith("#")) {
      const tag = part.slice(1).replace(/[^A-Za-z0-9_]/g, "");
      if (tag) return <Link key={i} to={`/feed?tag=${tag}`} className="text-blue-600 hover:underline">{part}</Link>;
    }
    if (part.startsWith("@")) return <span key={i} className="text-blue-600">{part}</span>;
    return <span key={i}>{part}</span>;
  });
}

function Comment({ comment, currentUser, onLike, onDelete, onReply }) {
  const liked = comment.liked_by_me;
  const initials = comment.user_name?.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();
  const canDelete = currentUser && (currentUser.id === comment.user_id || currentUser.role === "admin");
  return (
    <div className="flex gap-3" data-testid={`comment-${comment.id}`}>
      <Avatar className="h-7 w-7 rounded-none flex-shrink-0">
        <AvatarImage src={comment.user_avatar} />
        <AvatarFallback className="rounded-none bg-zinc-900 text-white text-[10px]">{initials}</AvatarFallback>
      </Avatar>
      <div className="min-w-0 flex-1">
        <div className="bg-zinc-100 px-3 py-2">
          <div className="flex items-center gap-2 mb-0.5">
            <Link to={`/u/${comment.user_id}`} className="font-semibold text-xs hover:text-blue-600">{comment.user_name}</Link>
            <span className="text-[10px] text-zinc-400 font-mono">{timeAgo(comment.created_at)}</span>
          </div>
          <div className="text-sm text-zinc-800 whitespace-pre-line">{comment.body}</div>
        </div>
        <div className="flex items-center gap-3 mt-1 text-[11px] text-zinc-500">
          <button onClick={() => onLike(comment)} className={`hover:text-blue-600 ${liked ? "text-blue-600 font-semibold" : ""}`} data-testid={`comment-like-${comment.id}`}>
            <Heart size={11} className={`inline mr-1 ${liked ? "fill-blue-600" : ""}`} /> {comment.likes_count || 0}
          </button>
          {!comment.parent_comment_id && (
            <button onClick={() => onReply(comment)} className="hover:text-zinc-900" data-testid={`comment-reply-${comment.id}`}>Reply</button>
          )}
          {canDelete && (
            <button onClick={() => onDelete(comment)} className="hover:text-red-600 ml-auto" data-testid={`comment-delete-${comment.id}`}><Trash2 size={11} /></button>
          )}
        </div>
      </div>
    </div>
  );
}

function CommentsSection({ post, currentUser, onCountChange }) {
  const [comments, setComments] = useState(null);
  const [body, setBody] = useState("");
  const [replyTo, setReplyTo] = useState(null);

  const load = () => api.get(`/feed/posts/${post.id}/comments`).then((r) => setComments(r.data));
  useEffect(() => { load(); }, []); // eslint-disable-line

  const send = async () => {
    if (!body.trim()) return;
    if (!currentUser || typeof currentUser !== "object") { toast.error("Sign in to comment."); return; }
    try {
      await api.post(`/feed/posts/${post.id}/comments`, { body, parent_comment_id: replyTo?.id || null });
      setBody(""); setReplyTo(null);
      await load();
      onCountChange?.();
    } catch (e) { toast.error(formatApiError(e.response?.data?.detail) || "Failed"); }
  };

  const handleLike = async (c) => {
    if (!currentUser || typeof currentUser !== "object") { toast.error("Sign in."); return; }
    try {
      const { data } = await api.post(`/feed/comments/${c.id}/like`);
      setComments((cs) => cs.map((x) => x.id === c.id ? { ...x, ...data } : x));
    } catch (err) {
      console.warn("Comment like failed:", err);
    }
  };

  const handleDelete = async (c) => {
    if (!confirm("Delete this comment?")) return;
    try {
      await api.delete(`/feed/comments/${c.id}`);
      await load();
      onCountChange?.();
    } catch (e) { toast.error(formatApiError(e.response?.data?.detail) || "Failed"); }
  };

  if (comments === null) return <div className="text-xs text-zinc-400 font-mono uppercase tracking-[0.2em]">Loading...</div>;

  // group: top-level + replies
  const top = comments.filter((c) => !c.parent_comment_id);
  const repliesByParent = comments.filter((c) => c.parent_comment_id).reduce((acc, r) => {
    (acc[r.parent_comment_id] = acc[r.parent_comment_id] || []).push(r);
    return acc;
  }, {});

  return (
    <div className="mt-4 pt-4 border-t border-zinc-100 space-y-4" data-testid={`comments-${post.id}`}>
      {top.length === 0 && <p className="text-xs text-zinc-400">Be the first to comment.</p>}
      {top.map((c) => (
        <div key={c.id} className="space-y-3">
          <Comment comment={c} currentUser={currentUser} onLike={handleLike} onDelete={handleDelete} onReply={setReplyTo} />
          {(repliesByParent[c.id] || []).map((r) => (
            <div key={r.id} className="pl-10">
              <Comment comment={r} currentUser={currentUser} onLike={handleLike} onDelete={handleDelete} onReply={() => {}} />
            </div>
          ))}
        </div>
      ))}

      {currentUser && typeof currentUser === "object" && (
        <div>
          {replyTo && (
            <div className="text-xs text-zinc-500 mb-1 flex items-center gap-2">
              Replying to <strong>{replyTo.user_name}</strong>
              <button onClick={() => setReplyTo(null)} className="text-zinc-400 hover:text-red-600"><X size={11} /></button>
            </div>
          )}
          <div className="flex gap-2">
            <input value={body} onChange={(e) => setBody(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") send(); }} placeholder={replyTo ? "Write a reply..." : "Add a comment..."} className="flex-1 bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-600" data-testid={`comment-input-${post.id}`} />
            <Button onClick={send} className="rounded-none bg-blue-600 hover:bg-blue-700" data-testid={`comment-send-${post.id}`}><Send size={13} /></Button>
          </div>
        </div>
      )}
    </div>
  );
}

export function PostCard({ post, currentUser, onUpdate, onDelete }) {
  const [showComments, setShowComments] = useState(false);
  const initials = post.user_name?.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();
  const canDelete = currentUser && (currentUser.id === post.user_id || currentUser.role === "admin");

  const handleLike = async () => {
    if (!currentUser || typeof currentUser !== "object") { toast.error("Sign in to like."); return; }
    try {
      const { data } = await api.post(`/feed/posts/${post.id}/like`);
      onUpdate?.({ ...post, ...data });
    } catch (e) { toast.error(formatApiError(e.response?.data?.detail) || "Failed"); }
  };

  const handleSave = async () => {
    if (!currentUser || typeof currentUser !== "object") { toast.error("Sign in to save."); return; }
    try {
      const { data } = await api.post(`/feed/posts/${post.id}/save`);
      onUpdate?.({ ...post, ...data });
      toast.success(data.saved_by_me ? "Saved" : "Unsaved");
    } catch (e) { toast.error(formatApiError(e.response?.data?.detail) || "Failed"); }
  };

  const handleRepost = async () => {
    if (!currentUser || typeof currentUser !== "object") { toast.error("Sign in to repost."); return; }
    try {
      await api.post(`/feed/posts`, { body: `Sharing — ${post.body.slice(0, 120)}`, repost_of: post.id });
      toast.success("Reposted to your feed");
      onUpdate?.({ ...post, repost_count: (post.repost_count || 0) + 1 });
    } catch (e) { toast.error(formatApiError(e.response?.data?.detail) || "Failed"); }
  };

  return (
    <article className="border border-zinc-200 bg-white p-5 fade-up" data-testid={`feed-post-${post.id}`}>
      <header className="flex items-start justify-between gap-3 mb-3">
        <Link to={`/u/${post.user_id}`} className="flex items-center gap-3 group">
          <Avatar className="h-10 w-10 rounded-none">
            <AvatarImage src={post.user_avatar} />
            <AvatarFallback className="rounded-none bg-zinc-900 text-white text-xs">{initials}</AvatarFallback>
          </Avatar>
          <div>
            <div className="font-semibold text-sm group-hover:text-blue-600">{post.user_name}</div>
            <div className="text-xs text-zinc-500 font-mono">{timeAgo(post.created_at)} ago</div>
          </div>
        </Link>
        {canDelete && (
          <button onClick={() => onDelete?.(post)} className="text-zinc-400 hover:text-red-600 p-1" data-testid={`post-delete-${post.id}`}><Trash2 size={14} /></button>
        )}
      </header>

      <p className="text-zinc-800 leading-relaxed whitespace-pre-line mb-3">{decorateBody(post.body)}</p>

      {post.image_url && (
        <div className="border border-zinc-200 mb-3 overflow-hidden bg-zinc-100">
          <img src={post.image_url} alt="" className="w-full h-auto" loading="lazy" />
        </div>
      )}

      {post.repost_of && (
        <Link to={`/u/${post.repost_of.user_id}`} className="block border-l-2 border-zinc-300 pl-4 mb-3 hover:border-zinc-900 transition-colors" data-testid={`repost-source-${post.id}`}>
          <div className="text-xs text-zinc-500 mb-1">↻ Originally posted by <strong>{post.repost_of.user_name}</strong></div>
          <p className="text-sm text-zinc-600 line-clamp-3">{post.repost_of.body}</p>
        </Link>
      )}

      {post.hashtags?.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mb-3">
          {post.hashtags.map((t) => (
            <Link key={t} to={`/feed?tag=${t}`} className="text-[10px] font-bold uppercase tracking-[0.15em] bg-zinc-100 hover:bg-blue-600 hover:text-white px-2 py-0.5 transition-colors">#{t}</Link>
          ))}
        </div>
      )}

      <footer className="flex items-center gap-2 pt-3 border-t border-zinc-100 text-zinc-500">
        <Button size="sm" variant="ghost" onClick={handleLike} className={`rounded-none text-xs ${post.liked_by_me ? "text-blue-600 font-semibold" : ""}`} data-testid={`post-like-${post.id}`}>
          <Heart size={13} className={`mr-1.5 ${post.liked_by_me ? "fill-blue-600" : ""}`} /> {post.likes_count || 0}
        </Button>
        <Button size="sm" variant="ghost" onClick={() => setShowComments((v) => !v)} className="rounded-none text-xs" data-testid={`post-comments-toggle-${post.id}`}>
          <MessageCircle size={13} className="mr-1.5" /> {post.comments_count || 0}
        </Button>
        <Button size="sm" variant="ghost" onClick={handleRepost} className="rounded-none text-xs" data-testid={`post-repost-${post.id}`}>
          <Repeat2 size={13} className="mr-1.5" /> {post.repost_count || 0}
        </Button>
        <Button size="sm" variant="ghost" onClick={handleSave} className={`rounded-none text-xs ml-auto ${post.saved_by_me ? "text-blue-600" : ""}`} data-testid={`post-save-${post.id}`}>
          <Bookmark size={13} className={`mr-1.5 ${post.saved_by_me ? "fill-blue-600" : ""}`} /> {post.saved_by_me ? "Saved" : "Save"}
        </Button>
      </footer>

      {showComments && (
        <CommentsSection
          post={post}
          currentUser={currentUser}
          onCountChange={async () => {
            const { data } = await api.get(`/feed/posts/${post.id}`);
            onUpdate?.(data);
          }}
        />
      )}
    </article>
  );
}

function Composer({ onPosted }) {
  const { user } = useAuth();
  const [body, setBody] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [showImg, setShowImg] = useState(false);
  const [posting, setPosting] = useState(false);
  if (!user || typeof user !== "object") {
    return (
      <div className="border border-dashed border-zinc-300 p-6 text-center mb-6">
        <p className="text-zinc-500 mb-3 text-sm">Sign in to start posting.</p>
        <Link to="/login"><Button className="rounded-none bg-blue-600 hover:bg-blue-700 text-white">Sign in</Button></Link>
      </div>
    );
  }
  const initials = user.name?.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();

  const send = async () => {
    if (!body.trim()) { toast.error("Write something first."); return; }
    setPosting(true);
    try {
      await api.post("/feed/posts", { body, image_url: imageUrl || null });
      setBody(""); setImageUrl(""); setShowImg(false);
      toast.success("Posted to your feed.");
      onPosted?.();
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    } finally { setPosting(false); }
  };

  return (
    <div className="border border-zinc-200 bg-white p-4 mb-6" data-testid="feed-composer">
      <div className="flex gap-3">
        <Avatar className="h-9 w-9 rounded-none flex-shrink-0">
          <AvatarImage src={user.avatar_url} />
          <AvatarFallback className="rounded-none bg-zinc-900 text-white text-xs">{initials}</AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            rows={3}
            className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-600"
            placeholder="Share something honest. Use #tags freely."
            data-testid="composer-body"
          />
          {showImg && (
            <div className="mt-2" data-testid="composer-image-uploader">
              <ImageUploader
                value={imageUrl}
                onChange={setImageUrl}
                aspect="aspect-video"
                testId="composer-image"
              />
            </div>
          )}
          <div className="flex items-center justify-between mt-2">
            <button onClick={() => setShowImg((v) => !v)} className="text-xs text-zinc-500 hover:text-zinc-900 flex items-center gap-1" data-testid="composer-toggle-image">
              <ImgIcon size={12} /> {showImg ? "Hide image" : "Add image"}
            </button>
            <Button onClick={send} disabled={posting} size="sm" className="rounded-none bg-blue-600 hover:bg-blue-700 text-white font-semibold uppercase tracking-[0.15em] text-xs" data-testid="composer-post-btn">
              {posting ? "Posting..." : "Post"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Feed() {
  const { user } = useAuth();
  const [posts, setPosts] = useState([]);
  const [sort, setSort] = useState("latest");
  const [trendingTags, setTrendingTags] = useState([]);
  const [activeTag, setActiveTag] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      params.set("sort", sort);
      if (activeTag) params.set("hashtag", activeTag);
      const { data } = await api.get(`/feed?${params.toString()}`);
      setPosts(data);
    } catch (e) {
      if (sort === "following") { setPosts([]); }
    } finally { setLoading(false); }
  };

  const loadTrending = () => api.get("/feed/hashtags/trending").then((r) => setTrendingTags(r.data));
  useEffect(() => { load(); loadTrending(); }, [sort, activeTag]); // eslint-disable-line

  const handleUpdate = (updated) => setPosts((ps) => ps.map((p) => p.id === updated.id ? { ...p, ...updated } : p));
  const handleDelete = async (post) => {
    if (!confirm("Delete this post?")) return;
    try {
      await api.delete(`/feed/posts/${post.id}`);
      setPosts((ps) => ps.filter((p) => p.id !== post.id));
      toast.success("Deleted");
    } catch (e) { toast.error(formatApiError(e.response?.data?.detail) || "Failed"); }
  };

  return (
    <div className="max-w-[1280px] mx-auto px-6 lg:px-10 py-10 grid lg:grid-cols-[1fr_280px] gap-8" data-testid="feed-page">
      <div>
        <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-600 mb-3">Feed</div>
        <h1 className="font-display font-black text-4xl tracking-tighter mb-8">What people are saying right now.</h1>

        <Composer onPosted={load} />

        <Tabs value={sort} onValueChange={(v) => { setSort(v); setActiveTag(null); }} className="w-full mb-6">
          <TabsList className="rounded-none bg-transparent border-b border-zinc-200 w-full justify-start gap-1 px-0 h-auto">
            <TabsTrigger value="latest" className="rounded-none data-[state=active]:bg-zinc-900 data-[state=active]:text-white px-5 py-2.5 text-xs uppercase tracking-[0.2em] font-bold" data-testid="feed-tab-latest">Latest</TabsTrigger>
            <TabsTrigger value="trending" className="rounded-none data-[state=active]:bg-zinc-900 data-[state=active]:text-white px-5 py-2.5 text-xs uppercase tracking-[0.2em] font-bold" data-testid="feed-tab-trending">Trending</TabsTrigger>
            <TabsTrigger value="following" disabled={!user || typeof user !== "object"} className="rounded-none data-[state=active]:bg-zinc-900 data-[state=active]:text-white px-5 py-2.5 text-xs uppercase tracking-[0.2em] font-bold" data-testid="feed-tab-following">Following</TabsTrigger>
          </TabsList>
          <TabsContent value={sort} className="mt-6">
            {activeTag && (
              <div className="text-xs font-mono uppercase tracking-[0.2em] text-blue-600 mb-3 flex items-center gap-2">
                Filtered by #{activeTag}
                <button onClick={() => setActiveTag(null)} className="text-zinc-400 hover:text-red-600"><X size={11} /></button>
              </div>
            )}
            {loading ? (
              <div className="text-zinc-400 text-xs uppercase tracking-[0.3em]">Loading...</div>
            ) : posts.length === 0 ? (
              <div className="border border-dashed border-zinc-300 p-12 text-center text-zinc-500">
                {sort === "following" ? "Follow other users to fill your feed." : "No posts yet."}
              </div>
            ) : (
              <div className="space-y-4" data-testid="feed-posts-list">
                {posts.map((p) => (
                  <PostCard key={p.id} post={p} currentUser={user} onUpdate={handleUpdate} onDelete={handleDelete} />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      <aside className="space-y-5 lg:sticky lg:top-24 self-start hidden lg:block">
        <div className="border border-zinc-200 bg-white p-5">
          <div className="text-xs font-bold uppercase tracking-[0.2em] mb-3 flex items-center gap-1.5"><Hash size={11} /> Trending hashtags</div>
          {trendingTags.length === 0 ? (
            <p className="text-xs text-zinc-400">Nothing trending yet.</p>
          ) : (
            <div className="space-y-2">
              {trendingTags.map((t) => (
                <button key={t.tag} onClick={() => { setActiveTag(t.tag); setSort("latest"); }} className="flex items-center justify-between w-full hover:bg-zinc-50 -mx-2 px-2 py-1.5 text-left" data-testid={`trending-tag-${t.tag}`}>
                  <span className="text-sm font-semibold text-zinc-900">#{t.tag}</span>
                  <span className="text-xs font-mono text-zinc-400">{t.count}</span>
                </button>
              ))}
            </div>
          )}
        </div>
        {user && typeof user === "object" && (
          <Link to="/profile" className="border border-zinc-200 bg-white p-5 block hover:border-zinc-900 transition-colors">
            <div className="text-xs font-bold uppercase tracking-[0.2em] mb-3">Your feed activity</div>
            <p className="text-sm text-zinc-600 mb-2">View saved posts, followers, and your full profile.</p>
            <span className="text-xs font-bold uppercase tracking-[0.15em] text-blue-600">Go to profile →</span>
          </Link>
        )}
      </aside>
    </div>
  );
}
