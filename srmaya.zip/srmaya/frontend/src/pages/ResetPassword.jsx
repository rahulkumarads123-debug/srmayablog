import { useState, useEffect } from "react";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Lock, CheckCircle2 } from "lucide-react";
import api, { formatApiError } from "@/lib/api";
import { toast } from "sonner";

export default function ResetPassword() {
  const location = useLocation();
  const navigate = useNavigate();
  const params = new URLSearchParams(location.search);
  const token = params.get("token");

  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (!token) toast.error("Missing or invalid reset link.");
  }, [token]);

  const strength = pwStrength(pw);
  const canSubmit = pw.length >= 8 && pw === pw2 && !!token && !busy;

  const submit = async (e) => {
    e.preventDefault();
    if (pw.length < 8) return toast.error("Password must be at least 8 characters.");
    if (pw !== pw2) return toast.error("Passwords don't match.");
    setBusy(true);
    try {
      await api.post("/auth/password/reset", { token, new_password: pw });
      setDone(true);
      setTimeout(() => navigate("/login"), 3500);
    } catch (err) {
      toast.error(formatApiError(err.response?.data?.detail) || "Failed to reset password");
    } finally {
      setBusy(false);
    }
  };

  if (done) {
    return (
      <div className="max-w-[520px] mx-auto px-6 lg:px-10 py-16" data-testid="reset-password-done">
        <div className="border border-zinc-200 bg-white p-8">
          <div className="flex items-center gap-3 mb-3">
            <CheckCircle2 size={24} className="text-green-600" />
            <div className="font-display font-black text-2xl tracking-tighter">Password updated</div>
          </div>
          <p className="text-zinc-600 mb-5">Sign in with your new password. Redirecting you now…</p>
          <Link to="/login" className="text-blue-600 hover:underline text-sm font-semibold">Go to sign in →</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-[520px] mx-auto px-6 lg:px-10 py-16" data-testid="reset-password-page">
      <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-600 mb-3">Account</div>
      <h1 className="font-display font-black text-4xl tracking-tighter mb-3">Set a new password</h1>
      <p className="text-zinc-600 mb-8">Pick something you'll remember. Minimum 8 characters.</p>
      <form onSubmit={submit} className="border border-zinc-200 bg-white p-8 space-y-5" data-testid="reset-form">
        <div>
          <label className="text-xs font-bold uppercase tracking-[0.2em] mb-2 block">New password</label>
          <div className="relative">
            <Lock size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
            <input
              type="password"
              required
              value={pw}
              onChange={(e) => setPw(e.target.value)}
              className="w-full bg-zinc-50 border border-zinc-200 rounded-none pl-10 pr-3 py-3 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
              placeholder="At least 8 characters"
              data-testid="reset-pw-input"
            />
          </div>
          {pw && (
            <div className="mt-2 flex items-center gap-2" data-testid="pw-strength">
              <div className="flex-1 h-1 bg-zinc-200 overflow-hidden">
                <div className={`h-full transition-all ${strength.color}`} style={{ width: `${strength.pct}%` }} />
              </div>
              <span className="text-[10px] font-mono uppercase tracking-[0.15em] text-zinc-500">{strength.label}</span>
            </div>
          )}
        </div>
        <div>
          <label className="text-xs font-bold uppercase tracking-[0.2em] mb-2 block">Confirm password</label>
          <div className="relative">
            <Lock size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
            <input
              type="password"
              required
              value={pw2}
              onChange={(e) => setPw2(e.target.value)}
              className={`w-full bg-zinc-50 border rounded-none pl-10 pr-3 py-3 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none ${pw2 && pw !== pw2 ? "border-red-400" : "border-zinc-200"}`}
              placeholder="Type it again"
              data-testid="reset-pw2-input"
            />
          </div>
          {pw2 && pw !== pw2 && (
            <p className="text-xs text-red-600 mt-1">Passwords don't match.</p>
          )}
        </div>
        <Button
          type="submit"
          disabled={!canSubmit}
          className="rounded-none bg-blue-600 hover:bg-blue-700 text-white font-semibold w-full py-6 text-sm uppercase tracking-[0.15em]"
          data-testid="reset-submit-btn"
        >
          {busy ? "Updating…" : "Update password"}
        </Button>
      </form>
    </div>
  );
}

function pwStrength(pw) {
  let score = 0;
  if (pw.length >= 8) score += 1;
  if (pw.length >= 12) score += 1;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score += 1;
  if (/\d/.test(pw)) score += 1;
  if (/[^A-Za-z0-9]/.test(pw)) score += 1;
  const map = [
    { label: "Too weak", color: "bg-red-500", pct: 15 },
    { label: "Weak", color: "bg-red-500", pct: 30 },
    { label: "Fair", color: "bg-amber-500", pct: 55 },
    { label: "Good", color: "bg-blue-500", pct: 75 },
    { label: "Strong", color: "bg-green-500", pct: 90 },
    { label: "Excellent", color: "bg-green-600", pct: 100 },
  ];
  return map[Math.min(score, 5)];
}
