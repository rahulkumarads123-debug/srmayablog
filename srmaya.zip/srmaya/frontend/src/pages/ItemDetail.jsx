import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import api, { formatApiError } from "@/lib/api";
import StarRating from "@/components/StarRating";
import RatingBreakdown from "@/components/RatingBreakdown";
import ReviewCard from "@/components/ReviewCard";
import ItemCard from "@/components/ItemCard";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useAuth } from "@/contexts/AuthContext";
import { Sparkles, Loader2, Plus, X, Edit3, Calendar, Building, User, MapPin, Tag, Play } from "lucide-react";
import { toast } from "sonner";
import VideoPlayer, { parseVideoUrl } from "@/components/VideoPlayer";

// Keys we render specially elsewhere in the page (video, gallery, ratings, cast cards…)
// so MetaList should hide them.
const SPECIAL_META_KEYS = new Set([
  "ratings", "specs", "video_url", "trailer_url", "gallery", "logo_url",
  "short_description", "cast_members",
]);

// Keys already shown in the entertainment IMDb strip — hide from MetaList for entertainment items.
const ENTERTAINMENT_STRIP_KEYS = new Set([
  "genre", "age_rating", "duration", "language", "country", "studio",
  "release_date", "subcategory",
]);

function filterEntertainmentMeta(metadata = {}) {
  const out = {};
  Object.entries(metadata).forEach(([k, v]) => {
    if (!ENTERTAINMENT_STRIP_KEYS.has(k)) out[k] = v;
  });
  return out;
}

function MetaList({ metadata = {} }) {
  const entries = Object.entries(metadata).filter(([k, v]) => v != null && !SPECIAL_META_KEYS.has(k));
  if (entries.length === 0) return null;
  const labelIcon = {
    genre: Tag, release_date: Calendar, duration: Calendar,
    director: User, cast: User, industry: Building, ceo: User,
    founded: Calendar, employees: Building, headquarters: MapPin,
    brand: Tag, price: Tag, type: Tag, city: MapPin, cuisine: Tag,
    price_range: Tag, hours: Calendar, stars: Tag, specialties: Tag,
    tuition: Tag, ranking: Tag, platform: Tag, developer: Building,
    pricing: Tag,
  };
  return (
    <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-3 text-sm">
      {entries.map(([k, v]) => {
        const Icon = labelIcon[k] || Tag;
        return (
          <div key={k} className="border-b border-zinc-100 pb-2">
            <dt className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500 mb-1 flex items-center gap-1.5">
              <Icon size={10} /> {k.replace(/_/g, " ")}
            </dt>
            <dd className="text-zinc-900 font-medium">
              {Array.isArray(v) ? v.join(", ") : typeof v === "object" ? JSON.stringify(v) : String(v)}
            </dd>
          </div>
        );
      })}
    </dl>
  );
}

function CastGrid({ members = [], castFallback = null }) {
  if (members && members.length > 0) {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4" data-testid="cast-grid">
        {members.slice(0, 12).map((c, i) => {
          const Wrapper = c.cast_slug ? Link : "div";
          const wrapperProps = c.cast_slug ? { to: `/cast/${c.cast_slug}` } : {};
          return (
            <Wrapper key={`${c.name}-${i}`} {...wrapperProps} className="border border-zinc-200 hover:border-zinc-900 transition-colors fade-up block" style={{ animationDelay: `${i * 40}ms` }} data-testid={`cast-card-${i}`}>
              <div className="aspect-square bg-zinc-100 overflow-hidden">
                {c.photo_url ? (
                  <img src={c.photo_url} alt={c.name} className="w-full h-full object-cover" onError={(e) => { e.currentTarget.style.display = "none"; }} />
                ) : (
                  <div className="w-full h-full grid place-items-center text-zinc-300 font-display font-black text-3xl tracking-tighter">
                    {c.name?.split(" ").map((p) => p[0]).slice(0, 2).join("")}
                  </div>
                )}
              </div>
              <div className="p-3">
                <div className="font-semibold text-sm leading-tight line-clamp-1">{c.name}</div>
                {(c.character || c.role) && (
                  <div className="text-[11px] text-zinc-500 line-clamp-1 mt-0.5">
                    {c.character ? `as ${c.character}` : c.role}
                  </div>
                )}
              </div>
            </Wrapper>
          );
        })}
      </div>
    );
  }
  if (Array.isArray(castFallback) && castFallback.length > 0) {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4" data-testid="cast-grid">
        {castFallback.map((name, i) => (
          <div key={`${name}-${i}`} className="border border-zinc-200 fade-up" style={{ animationDelay: `${i * 40}ms` }}>
            <div className="aspect-square bg-zinc-100 grid place-items-center text-zinc-300 font-display font-black text-3xl tracking-tighter">
              {String(name).split(" ").map((p) => p[0]).slice(0, 2).join("")}
            </div>
            <div className="p-3">
              <div className="font-semibold text-sm leading-tight line-clamp-1">{name}</div>
            </div>
          </div>
        ))}
      </div>
    );
  }
  return null;
}

function CompanyRatingPanel({ ratings = {} }) {
  const labels = { work_culture: "Work Culture", salary: "Salary & Benefits", growth: "Career Growth", management: "Management" };
  const order = Object.keys(labels);
  return (
    <div className="border border-zinc-200 p-6 bg-white">
      <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500 mb-4">Sub-ratings</div>
      <div className="space-y-3">
        {order.map((k) => {
          const val = ratings[k] ?? 0;
          return (
            <div key={k} className="flex items-center gap-3 text-sm">
              <span className="w-32 text-zinc-700">{labels[k]}</span>
              <StarRating value={val} size={14} />
              <span className="font-bold text-sm">{val.toFixed(1)}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function ItemDetail() {
  const { slug } = useParams();
  const [item, setItem] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [related, setRelated] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sort, setSort] = useState("helpful");
  const [reviewDialog, setReviewDialog] = useState(false);
  const [aiSummary, setAiSummary] = useState(null);
  const [aiLoading, setAiLoading] = useState(false);
  const { user } = useAuth();

  // form state
  const [form, setForm] = useState({ rating: 0, title: "", body: "", pros: [""], cons: [""] });
  const [submitting, setSubmitting] = useState(false);

  const load = () => {
    setLoading(true);
    Promise.all([
      api.get(`/items/${slug}`),
      api.get(`/items/${slug}/related?limit=4`),
    ])
      .then(async ([it, rel]) => {
        setItem(it.data);
        setRelated(rel.data);
        const rev = await api.get(`/items/${it.data.id}/reviews?sort=${sort}`);
        setReviews(rev.data);
      })
      .catch(() => setItem(null))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [slug]);

  useEffect(() => {
    if (!item) return;
    api.get(`/items/${item.id}/reviews?sort=${sort}`).then((r) => setReviews(r.data));
  }, [sort, item]);

  const handleHelpful = async (review) => {
    if (!user || typeof user !== "object") {
      toast.error("Sign in to mark reviews helpful.");
      return;
    }
    try {
      const { data } = await api.post(`/reviews/${review.id}/helpful`);
      setReviews((rs) => rs.map((r) => (r.id === review.id ? data : r)));
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  const handleReport = async (review) => {
    if (!user || typeof user !== "object") { toast.error("Sign in to report a review."); return; }
    try {
      await api.post(`/reviews/${review.id}/report`);
      toast.success("Review reported. Thanks for the heads up.");
      setReviews((rs) => rs.filter((r) => r.id !== review.id));
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  const handleDelete = async (review) => {
    if (!confirm("Delete this review?")) return;
    try {
      await api.delete(`/reviews/${review.id}`);
      toast.success("Review deleted.");
      setReviews((rs) => rs.filter((r) => r.id !== review.id));
      load();
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  const submitReview = async (e) => {
    e.preventDefault();
    if (form.rating === 0) { toast.error("Pick a star rating."); return; }
    if (form.body.length < 10) { toast.error("Review must be at least 10 characters."); return; }
    setSubmitting(true);
    try {
      const payload = {
        rating: form.rating,
        title: form.title.trim() || `${form.rating} star review`,
        body: form.body,
        pros: form.pros.filter((s) => s.trim()),
        cons: form.cons.filter((s) => s.trim()),
      };
      await api.post(`/items/${item.id}/reviews`, payload);
      toast.success("Review posted!");
      setReviewDialog(false);
      setForm({ rating: 0, title: "", body: "", pros: [""], cons: [""] });
      load();
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    } finally {
      setSubmitting(false);
    }
  };

  const generateSummary = async () => {
    if (!item) return;
    setAiLoading(true);
    try {
      const { data } = await api.post(`/ai/summary/${item.id}`);
      setAiSummary(data);
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "AI summary failed");
    } finally {
      setAiLoading(false);
    }
  };

  if (loading && !item) {
    return <div className="max-w-[1400px] mx-auto px-6 py-20 text-zinc-400 text-xs uppercase tracking-[0.3em]">Loading...</div>;
  }
  if (!item) {
    return (
      <div className="max-w-[1400px] mx-auto px-6 py-20">
        <h1 className="font-display font-black text-3xl mb-4">Item not found</h1>
        <Link to="/" className="text-blue-600 hover:underline">← Go home</Link>
      </div>
    );
  }

  const isCompany = item.category_slug === "business";
  const isEntertainment = item.category_slug === "entertainment";
  const meta = item.metadata || {};
  const year = (meta.release_date || "").slice(0, 4).match(/^\d{4}$/) ? meta.release_date.slice(0, 4) : null;
  const castMembers = Array.isArray(meta.cast_members) ? meta.cast_members.filter((c) => c && c.name) : [];

  return (
    <div data-testid="item-detail-page">
      <section className="border-b border-zinc-200 bg-white">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-10">
          <div className="text-xs font-bold uppercase tracking-[0.3em] text-zinc-500 mb-6 flex items-center gap-2">
            <Link to="/" className="hover:text-zinc-900">Home</Link>
            <span>/</span>
            <Link to={`/category/${item.category_slug}`} className="hover:text-zinc-900">{item.category_name}</Link>
            <span>/</span>
            <span className="text-zinc-900">{item.name}</span>
          </div>

          <div className="grid lg:grid-cols-12 gap-10">
            <div className="lg:col-span-4">
              <div className="border border-zinc-200 bg-zinc-100 aspect-[4/5] overflow-hidden">
                {item.image_url && (<img src={item.image_url} alt={item.name} className="w-full h-full object-cover" />)}
              </div>
            </div>
            <div className="lg:col-span-8">
              <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-blue-600 mb-3">
                {item.category_name}
                {isEntertainment && meta.subcategory && <span className="text-zinc-500"> · {meta.subcategory}</span>}
              </div>
              <h1 className="font-display font-black text-4xl sm:text-5xl lg:text-6xl tracking-tighter leading-[0.95] mb-5" data-testid="item-title">
                {item.name}
                {isEntertainment && year && (<span className="text-zinc-400 font-light"> ({year})</span>)}
              </h1>
              <div className="flex items-center gap-4 mb-6">
                <div className="flex items-center gap-2">
                  <StarRating value={item.avg_rating} size={20} />
                  <span className="font-display font-black text-2xl tracking-tighter">{item.avg_rating.toFixed(1)}</span>
                </div>
                <span className="text-zinc-300">|</span>
                <span className="text-sm text-zinc-500 font-mono">{item.review_count} review{item.review_count === 1 ? "" : "s"}</span>
                {item.featured && <span className="ml-2 bg-zinc-900 text-white text-[10px] font-bold uppercase tracking-[0.2em] px-2 py-1">Featured</span>}
              </div>

              {/* IMDb-style metadata strip — entertainment only */}
              {isEntertainment && (
                <div className="flex flex-wrap items-center gap-3 mb-6" data-testid="entertainment-meta-strip">
                  {meta.genre && <span className="bg-zinc-900 text-white px-2 py-1 text-[10px] font-bold uppercase tracking-[0.15em]">{meta.genre}</span>}
                  {meta.age_rating && <span className="border border-zinc-900 px-1.5 py-0.5 text-[10px] font-mono font-bold">{meta.age_rating}</span>}
                  {meta.duration && <span className="text-sm text-zinc-700 flex items-center gap-1"><Tag size={12} />{meta.duration}</span>}
                  {meta.language && <span className="text-sm text-zinc-700">· {meta.language}</span>}
                  {meta.country && <span className="text-sm text-zinc-700">· {meta.country}</span>}
                  {meta.studio && <span className="text-sm text-zinc-700">· {meta.studio}</span>}
                </div>
              )}

              <p className="text-lg text-zinc-700 leading-relaxed mb-8 max-w-3xl">{item.description}</p>

              <MetaList metadata={isEntertainment ? filterEntertainmentMeta(item.metadata) : item.metadata} />

              {item.tags?.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-6">
                  {item.tags.map((t) => (
                    <span key={t} className="bg-zinc-100 text-zinc-900 rounded-none px-2 py-1 text-xs font-semibold tracking-wide uppercase">{t}</span>
                  ))}
                </div>
              )}

              <div className="mt-8 flex flex-wrap gap-3">
                <Dialog open={reviewDialog} onOpenChange={setReviewDialog}>
                  <DialogTrigger asChild>
                    <Button
                      className="rounded-none bg-blue-600 hover:bg-blue-700 text-white font-semibold px-7 py-6 text-sm uppercase tracking-[0.15em]"
                      onClick={() => {
                        if (!user || typeof user !== "object") {
                          toast.error("Sign in to write a review.");
                        } else {
                          setReviewDialog(true);
                        }
                      }}
                      data-testid="write-review-btn"
                    >
                      <Edit3 size={14} className="mr-2" /> Write a review
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="rounded-none max-w-2xl">
                    <DialogHeader>
                      <DialogTitle className="font-display font-black text-2xl tracking-tighter">Review {item.name}</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={submitReview} className="space-y-5" data-testid="review-form">
                      <div>
                        <div className="text-xs font-bold uppercase tracking-[0.2em] mb-2">Your rating</div>
                        <StarRating value={form.rating} size={28} onChange={(v) => setForm({ ...form, rating: v })} testIdPrefix="form-star" />
                      </div>
                      <div>
                        <label className="text-xs font-bold uppercase tracking-[0.2em] mb-1.5 block">Title</label>
                        <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" placeholder="Sum it up" data-testid="review-title-input" />
                      </div>
                      <div>
                        <label className="text-xs font-bold uppercase tracking-[0.2em] mb-1.5 block">Your review</label>
                        <textarea value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} rows={5} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" placeholder="Tell others what you really think" data-testid="review-body-input" />
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                        {["pros", "cons"].map((field) => (
                          <div key={field}>
                            <div className="text-xs font-bold uppercase tracking-[0.2em] mb-2 flex items-center justify-between">
                              {field === "pros" ? "Pros" : "Cons"}
                              <button type="button" className="text-blue-600 hover:underline normal-case font-medium" onClick={() => setForm({ ...form, [field]: [...form[field], ""] })} data-testid={`add-${field}-btn`}>
                                <Plus size={11} className="inline" /> add
                              </button>
                            </div>
                            <div className="space-y-2">
                              {form[field].map((v, i) => (
                                <div key={i} className="flex gap-2">
                                  <input
                                    value={v}
                                    onChange={(e) => {
                                      const next = [...form[field]];
                                      next[i] = e.target.value;
                                      setForm({ ...form, [field]: next });
                                    }}
                                    className="flex-1 bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-600"
                                    placeholder={field === "pros" ? "Something you liked" : "Something to improve"}
                                  />
                                  {form[field].length > 1 && (
                                    <button type="button" onClick={() => setForm({ ...form, [field]: form[field].filter((_, j) => j !== i) })} className="text-zinc-400 hover:text-red-600 px-2">
                                      <X size={14} />
                                    </button>
                                  )}
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                      <Button type="submit" disabled={submitting} className="rounded-none bg-blue-600 hover:bg-blue-700 text-white font-semibold w-full py-6 text-sm uppercase tracking-[0.15em]" data-testid="submit-review-btn">
                        {submitting ? "Posting..." : "Post review"}
                      </Button>
                    </form>
                  </DialogContent>
                </Dialog>
                <Button
                  variant="outline"
                  className="rounded-none border-2 border-zinc-900 hover:bg-zinc-900 hover:text-white font-semibold px-7 py-6 text-sm uppercase tracking-[0.15em]"
                  onClick={generateSummary}
                  disabled={aiLoading}
                  data-testid="ai-summary-btn"
                >
                  {aiLoading ? <Loader2 size={14} className="mr-2 animate-spin" /> : <Sparkles size={14} className="mr-2" />}
                  {aiLoading ? "Summarizing..." : "AI Summary"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Body */}
      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-12 grid lg:grid-cols-12 gap-10">
        {/* Main column */}
        <div className="lg:col-span-8">
          {(() => {
            const videoUrl = item.metadata?.video_url || item.metadata?.trailer_url;
            const parsed = parseVideoUrl(videoUrl);
            if (!parsed) return null;
            const labelMap = { youtube: "YouTube", facebook: "Facebook", twitter: "X / Twitter" };
            return (
              <section className="mb-10 fade-up" data-testid="item-video-section">
                <div className="flex items-center justify-between mb-3">
                  <h2 className="font-display font-black text-2xl tracking-tighter flex items-center gap-2">
                    <Play size={18} className="text-blue-600 fill-blue-600" /> Watch
                  </h2>
                  <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-zinc-500">{labelMap[parsed.kind]}</span>
                </div>
                <VideoPlayer url={videoUrl} title={item.name} />
              </section>
            );
          })()}

          {/* Cast & Crew — entertainment only */}
          {isEntertainment && (castMembers.length > 0 || Array.isArray(meta.cast)) && (
            <section className="mb-10" data-testid="item-cast-section">
              <div className="flex items-baseline justify-between mb-4">
                <h2 className="font-display font-black text-2xl tracking-tighter">Cast &amp; Crew</h2>
                {castMembers.length > 0 && (
                  <span className="text-xs font-mono uppercase tracking-[0.2em] text-zinc-500">{castMembers.length} member{castMembers.length === 1 ? "" : "s"}</span>
                )}
              </div>
              <CastGrid members={castMembers} castFallback={Array.isArray(meta.cast) ? meta.cast : null} />
              {(meta.director || meta.writer) && (
                <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                  {meta.director && (
                    <div className="border-l-2 border-zinc-900 pl-4">
                      <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500 mb-1">Director</div>
                      <div className="font-semibold">{meta.director}</div>
                    </div>
                  )}
                  {meta.writer && (
                    <div className="border-l-2 border-zinc-900 pl-4">
                      <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500 mb-1">Writer{String(meta.writer).includes(",") ? "s" : ""}</div>
                      <div className="font-semibold">{meta.writer}</div>
                    </div>
                  )}
                </div>
              )}
            </section>
          )}

          {aiSummary && (
            <div className="border-2 border-blue-600 p-6 mb-10 bg-blue-50/30 fade-up" data-testid="ai-summary-card">
              <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-blue-600 mb-3 flex items-center gap-2">
                <Sparkles size={11} /> AI Summary · based on {aiSummary.based_on} reviews
              </div>
              <p className="text-zinc-800 leading-relaxed whitespace-pre-line">{aiSummary.summary}</p>
            </div>
          )}

          <div className="flex items-end justify-between mb-6">
            <h2 className="font-display font-black text-3xl tracking-tighter">Reviews</h2>
            <select value={sort} onChange={(e) => setSort(e.target.value)} className="bg-white border border-zinc-200 rounded-none px-3 py-2 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" data-testid="reviews-sort-select">
              <option value="helpful">Most helpful</option>
              <option value="newest">Newest</option>
              <option value="oldest">Oldest</option>
              <option value="highest">Highest rated</option>
              <option value="lowest">Lowest rated</option>
            </select>
          </div>

          {reviews.length === 0 ? (
            <div className="border border-dashed border-zinc-300 p-10 text-center">
              <p className="text-zinc-500 mb-2">No reviews yet — be the first.</p>
            </div>
          ) : (
            <div data-testid="reviews-list">
              {reviews.map((r) => (
                <ReviewCard key={r.id} review={r} onHelpful={handleHelpful} onReport={handleReport} onDelete={handleDelete} />
              ))}
            </div>
          )}
        </div>

        {/* Right column */}
        <aside className="lg:col-span-4 space-y-6 lg:sticky lg:top-24 self-start">
          <RatingBreakdown avg={item.avg_rating} count={item.review_count} breakdown={item.rating_breakdown} />
          {isCompany && item.metadata?.ratings && (<CompanyRatingPanel ratings={item.metadata.ratings} />)}
          {related.length > 0 && (
            <div className="border border-zinc-200 bg-white p-6">
              <div className="text-xs font-bold uppercase tracking-[0.2em] mb-4">Related</div>
              <div className="space-y-4">
                {related.map((r) => (
                  <Link to={`/item/${r.slug}`} key={r.id} className="flex gap-3 hover:bg-zinc-50 -m-2 p-2 transition-colors">
                    <div className="w-16 h-16 flex-shrink-0 bg-zinc-100 overflow-hidden">
                      {r.image_url && <img src={r.image_url} alt="" className="w-full h-full object-cover" />}
                    </div>
                    <div className="min-w-0">
                      <h4 className="font-semibold text-sm leading-tight line-clamp-2">{r.name}</h4>
                      <div className="flex items-center gap-1.5 mt-1.5">
                        <StarRating value={r.avg_rating} size={11} />
                        <span className="text-xs text-zinc-500 font-mono">{r.avg_rating.toFixed(1)}</span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </aside>
      </section>
    </div>
  );
}
