import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api, { formatApiError } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Save, Eye } from "lucide-react";
import ImageUploader from "@/components/ImageUploader";

const TAG_OPTIONS = ["General", "Guides", "News", "Product", "Reviews", "Opinion", "Announcement"];

function slugify(s) { return (s || "").toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, ""); }

export default function BlogEditor() {
  const { slug } = useParams(); // optional — when present, we are editing
  const navigate = useNavigate();
  const [form, setForm] = useState({
    id: null,
    title: "",
    slug: "",
    excerpt: "",
    body: "",
    cover_url: "",
    tag: "General",
    published: true,
  });
  const [loading, setLoading] = useState(false);
  const [previewOn, setPreviewOn] = useState(false);
  const isEditing = !!slug;

  // Auto-slug
  useEffect(() => {
    if (isEditing) return; // don't auto-rewrite during edit
    setForm((p) => ({ ...p, slug: p.slug && p.slug !== slugify(p.slug) ? p.slug : slugify(p.title) }));
  }, [form.title, isEditing]);

  // Load existing post if editing
  useEffect(() => {
    if (!isEditing) return;
    api.get(`/blog/${slug}`).then((r) => {
      const d = r.data;
      setForm({ id: d.id, title: d.title, slug: d.slug, excerpt: d.excerpt, body: d.body, cover_url: d.cover_url || "", tag: d.tag, published: !!d.published });
    });
  }, [slug, isEditing]);

  const save = async (e, asDraft = false) => {
    e?.preventDefault?.();
    setLoading(true);
    try {
      const payload = {
        title: form.title,
        slug: form.slug || undefined,
        excerpt: form.excerpt,
        body: form.body,
        cover_url: form.cover_url || undefined,
        tag: form.tag,
        published: asDraft ? false : !!form.published,
      };
      if (isEditing) {
        const { data } = await api.patch(`/blog/${form.id}`, payload);
        toast.success("Saved.");
        navigate(`/blog/${data.slug}`);
      } else {
        const { data } = await api.post("/blog", payload);
        toast.success("Published.");
        navigate(`/blog/${data.slug}`);
      }
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-[1100px] mx-auto px-6 lg:px-10 py-12" data-testid="blog-editor-page">
      <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-600 mb-3">Blog · {isEditing ? "Edit" : "New post"}</div>
      <h1 className="font-display font-black text-4xl tracking-tighter mb-8">{isEditing ? form.title || "Editing…" : "Write a new blog post"}</h1>

      <form onSubmit={save} className="grid lg:grid-cols-[1fr_320px] gap-8" data-testid="blog-editor-form">
        <div className="space-y-5">
          <div>
            <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">Title <span className="text-red-500">*</span></label>
            <input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-3 text-lg font-display font-bold tracking-tight focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" placeholder="Sharp, specific, declarative" data-testid="blog-title-input" />
          </div>
          <div>
            <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">URL slug</label>
            <div className="flex">
              <span className="border border-r-0 border-zinc-200 bg-zinc-100 px-3 py-3 text-xs font-mono text-zinc-500 flex items-center">/blog/</span>
              <input value={form.slug} onChange={(e) => setForm({ ...form, slug: slugify(e.target.value) })} className="flex-1 bg-zinc-50 border border-zinc-200 rounded-none px-3 py-3 text-sm font-mono focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" placeholder="auto-from-title" data-testid="blog-slug-input" />
            </div>
          </div>
          <div>
            <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">Excerpt <span className="text-red-500">*</span></label>
            <textarea required rows={2} maxLength={300} value={form.excerpt} onChange={(e) => setForm({ ...form, excerpt: e.target.value })} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-3 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" placeholder="One-paragraph summary (max 300 chars)" data-testid="blog-excerpt-input" />
            <p className="text-xs text-zinc-400 mt-1 font-mono">{form.excerpt.length}/300</p>
          </div>
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-sm font-semibold text-zinc-900">Body <span className="text-red-500">*</span></label>
              <button type="button" onClick={() => setPreviewOn((p) => !p)} className="text-xs text-blue-600 hover:underline" data-testid="toggle-blog-preview">
                <Eye size={11} className="inline mr-1" /> {previewOn ? "Edit" : "Preview"}
              </button>
            </div>
            {previewOn ? (
              <div className="border border-zinc-200 bg-white p-6 prose max-w-none min-h-[280px] text-zinc-800 leading-relaxed space-y-4" data-testid="blog-body-preview">
                {form.body.split("\n\n").map((para, i) => {
                  const m = para.match(/^\*\*([^*]+)\*\*\s(.*)$/s);
                  if (m) return <div key={i}><h3 className="font-display font-bold text-xl mt-4 mb-1">{m[1]}</h3><p>{m[2]}</p></div>;
                  return <p key={i}>{para}</p>;
                })}
              </div>
            ) : (
              <textarea required rows={14} value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-3 text-sm leading-relaxed font-mono focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" placeholder={'Use blank lines between paragraphs.\nMark subheadings as **Subheading** then text on same line.\nNumbered lists are auto-styled — start lines with "1.", "2." etc.'} data-testid="blog-body-input" />
            )}
          </div>
        </div>

        <aside className="space-y-5 lg:sticky lg:top-24 self-start">
          <div className="border border-zinc-200 bg-white p-5">
            <div className="text-xs font-bold uppercase tracking-[0.2em] mb-3">Cover image</div>
            <ImageUploader
              value={form.cover_url}
              onChange={(url) => setForm({ ...form, cover_url: url })}
              aspect="aspect-video"
              testId="blog-cover-uploader"
            />
          </div>
          <div className="border border-zinc-200 bg-white p-5">
            <div className="text-xs font-bold uppercase tracking-[0.2em] mb-3">Tag</div>
            <select value={form.tag} onChange={(e) => setForm({ ...form, tag: e.target.value })} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" data-testid="blog-tag-select">
              {TAG_OPTIONS.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div className="border border-zinc-200 bg-white p-5">
            <label className="flex items-center gap-2 text-sm font-semibold">
              <input type="checkbox" checked={form.published} onChange={(e) => setForm({ ...form, published: e.target.checked })} data-testid="blog-published-check" />
              Publish immediately
            </label>
            <p className="text-xs text-zinc-500 mt-2">Uncheck to save as a draft (visible only to admins).</p>
          </div>
          <Button type="submit" disabled={loading} className="rounded-none bg-blue-600 hover:bg-blue-700 text-white font-semibold w-full py-6 text-sm uppercase tracking-[0.15em]" data-testid="blog-save-btn">
            <Save size={13} className="mr-1.5" /> {loading ? "Saving..." : isEditing ? "Save changes" : (form.published ? "Publish post" : "Save draft")}
          </Button>
          {!isEditing && (
            <Button type="button" onClick={(e) => save(e, true)} disabled={loading} variant="outline" className="rounded-none w-full py-6 text-sm uppercase tracking-[0.15em] border-zinc-200 hover:border-zinc-900" data-testid="blog-save-draft-btn">
              Save as draft
            </Button>
          )}
        </aside>
      </form>
    </div>
  );
}
