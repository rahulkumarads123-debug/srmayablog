import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Mail, CheckCircle2 } from "lucide-react";
import api, { formatApiError } from "@/lib/api";
import { toast } from "sonner";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [devLink, setDevLink] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      const { data } = await api.post("/auth/password/forgot", { email });
      setSent(true);
      if (data.token) {
        setDevLink(`${window.location.origin}/reset-password?token=${encodeURIComponent(data.token)}`);
      }
    } catch (err) {
      toast.error(formatApiError(err.response?.data?.detail) || "Failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="max-w-[520px] mx-auto px-6 lg:px-10 py-16" data-testid="forgot-password-page">
      <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-600 mb-3">Account</div>
      <h1 className="font-display font-black text-4xl tracking-tighter mb-3">Forgot password?</h1>
      <p className="text-zinc-600 leading-relaxed mb-8">
        Enter your account email and we'll send a single-use magic link to reset your password. It expires in one hour.
      </p>
      {sent ? (
        <div className="border border-zinc-200 bg-white p-8" data-testid="forgot-password-sent">
          <div className="flex items-center gap-3 mb-3">
            <CheckCircle2 size={24} className="text-green-600" />
            <div className="font-display font-black text-2xl tracking-tighter">Check your inbox</div>
          </div>
          <p className="text-zinc-600 leading-relaxed">
            If an account exists for <strong>{email}</strong>, you'll receive a password reset link shortly. Follow the link within one hour to set a new password.
          </p>
          {devLink && (
            <div className="mt-5 border border-blue-200 bg-blue-50 p-3 text-xs font-mono break-all" data-testid="reset-dev-link">
              Dev-mode link: <a href={devLink} className="text-blue-700 hover:underline">{devLink}</a>
            </div>
          )}
          <div className="mt-6">
            <Link to="/login" className="text-blue-600 hover:underline text-sm font-semibold">← Back to sign in</Link>
          </div>
        </div>
      ) : (
        <form onSubmit={submit} className="border border-zinc-200 bg-white p-8 space-y-5" data-testid="forgot-password-form">
          <div>
            <label className="text-xs font-bold uppercase tracking-[0.2em] mb-2 block">Email address</label>
            <div className="relative">
              <Mail size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-zinc-50 border border-zinc-200 rounded-none pl-10 pr-3 py-3 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                placeholder="you@example.com"
                data-testid="forgot-email-input"
              />
            </div>
          </div>
          <Button
            type="submit"
            disabled={busy}
            className="rounded-none bg-blue-600 hover:bg-blue-700 text-white font-semibold w-full py-6 text-sm uppercase tracking-[0.15em]"
            data-testid="forgot-submit-btn"
          >
            {busy ? "Sending…" : "Send reset link"}
          </Button>
          <div className="text-center text-sm">
            <Link to="/login" className="text-zinc-500 hover:text-blue-600">Back to sign in</Link>
          </div>
        </form>
      )}
    </div>
  );
}
