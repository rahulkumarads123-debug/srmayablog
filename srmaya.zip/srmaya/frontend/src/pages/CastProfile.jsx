import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import api from "@/lib/api";
import StarRating from "@/components/StarRating";
import { User, Calendar, MapPin, ExternalLink } from "lucide-react";

export default function CastProfile() {
  const { slug } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api.get(`/cast/${slug}`)
      .then((r) => setData(r.data))
      .catch(() => setData(null))
      .finally(() => setLoading(false));
    // SEO: set the tab title
    return () => { document.title = "Rateverse"; };
  }, [slug]);

  useEffect(() => {
    if (data?.person?.name) document.title = `${data.person.name} · Cast · Rateverse`;
  }, [data]);

  if (loading) return <div className="max-w-[1400px] mx-auto px-6 py-20 text-zinc-400 text-xs uppercase tracking-[0.3em]">Loading…</div>;
  if (!data) return (
    <div className="max-w-[1400px] mx-auto px-6 py-20">
      <h1 className="font-display font-black text-3xl mb-4">Person not found</h1>
      <Link to="/" className="text-blue-600 hover:underline">← Go home</Link>
    </div>
  );

  const { person, filmography } = data;
  const socials = person.social_links || {};

  return (
    <div data-testid="cast-profile-page">
      <section className="bg-white border-b border-zinc-200">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-12 grid lg:grid-cols-[280px_1fr] gap-10">
          <div className="aspect-square bg-zinc-100 overflow-hidden border border-zinc-200">
            {person.photo_url ? (
              <img src={person.photo_url} alt={person.name} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full grid place-items-center text-zinc-300">
                <User size={80} />
              </div>
            )}
          </div>
          <div>
            <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-600 mb-3">Cast &amp; Crew</div>
            <h1 className="font-display font-black text-5xl lg:text-6xl tracking-tighter leading-none mb-4" data-testid="cast-name">{person.name}</h1>
            {person.profession && (
              <div className="text-xl text-zinc-700 mb-6">{person.profession}</div>
            )}
            <div className="flex flex-wrap items-center gap-4 text-sm text-zinc-600 mb-6">
              {person.date_of_birth && (
                <span className="flex items-center gap-1.5"><Calendar size={13} /> {person.date_of_birth}</span>
              )}
              {person.place_of_birth && (
                <span className="flex items-center gap-1.5"><MapPin size={13} /> {person.place_of_birth}</span>
              )}
              {Object.entries(socials).filter(([, v]) => v).map(([k, v]) => (
                <a key={k} href={v} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 hover:text-blue-600 uppercase tracking-wide text-xs">
                  <ExternalLink size={11} /> {k}
                </a>
              ))}
            </div>
            {person.bio && (
              <p className="text-zinc-700 leading-relaxed max-w-2xl" data-testid="cast-bio">{person.bio}</p>
            )}
          </div>
        </div>
      </section>
      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-12">
        <div className="flex items-baseline justify-between mb-6">
          <h2 className="font-display font-black text-3xl tracking-tighter">Filmography</h2>
          <span className="text-xs font-mono uppercase tracking-[0.2em] text-zinc-500">{filmography.length} title{filmography.length === 1 ? "" : "s"}</span>
        </div>
        {filmography.length === 0 ? (
          <div className="border border-dashed border-zinc-300 p-12 text-center text-zinc-500">
            No films linked yet.
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5" data-testid="filmography-grid">
            {filmography.map((f) => (
              <Link key={f.item_id} to={`/item/${f.item_slug}`} className="border border-zinc-200 hover:border-zinc-900 transition-colors group fade-up" data-testid={`filmo-${f.item_id}`}>
                <div className="aspect-[3/4] bg-zinc-100 overflow-hidden">
                  {f.item_image && <img src={f.item_image} alt="" loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition-transform" />}
                </div>
                <div className="p-3">
                  <h3 className="font-semibold text-sm leading-tight line-clamp-2 mb-1">{f.item_name}</h3>
                  {(f.role || f.character) && (
                    <div className="text-[10px] font-mono uppercase tracking-[0.15em] text-zinc-500 line-clamp-1">
                      {f.character ? `as ${f.character}` : f.role}
                    </div>
                  )}
                  <div className="flex items-center gap-1.5 mt-1.5">
                    <StarRating value={f.item_rating || 0} size={11} />
                    <span className="text-xs text-zinc-500 font-mono">{(f.item_rating || 0).toFixed(1)}</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
