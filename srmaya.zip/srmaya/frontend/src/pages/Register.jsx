import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth, formatApiError } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await register(email.trim(), password, name.trim());
      toast.success(`Welcome to Rateverse, ${name.split(" ")[0]}.`);
      navigate("/");
    } catch (e) {
      const msg = formatApiError(e.response?.data?.detail) || "Registration failed";
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] grid lg:grid-cols-2" data-testid="register-page">
      <div className="flex items-center justify-center p-6 lg:p-12 order-2 lg:order-1">
        <form onSubmit={onSubmit} className="w-full max-w-md space-y-6" data-testid="register-form">
          <div>
            <div className="text-xs font-bold uppercase tracking-[0.3em] text-zinc-500 mb-3">Sign up</div>
            <h2 className="font-display font-black text-4xl tracking-tighter">Join Rateverse</h2>
          </div>
          {error && <div className="border border-red-200 bg-red-50 text-red-800 text-sm px-4 py-3" data-testid="register-error">{error}</div>}
          <div>
            <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">Full name</label>
            <input type="text" required value={name} onChange={(e) => setName(e.target.value)} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-3 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" data-testid="register-name-input" />
          </div>
          <div>
            <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">Email</label>
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-3 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" data-testid="register-email-input" />
          </div>
          <div>
            <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">Password</label>
            <input type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-3 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" data-testid="register-password-input" />
            <p className="text-xs text-zinc-500 mt-1.5">Min 6 characters.</p>
          </div>
          <Button type="submit" disabled={loading} className="rounded-none bg-blue-600 hover:bg-blue-700 text-white font-semibold w-full py-6 text-sm uppercase tracking-[0.15em]" data-testid="register-submit-btn">
            {loading ? "Creating account..." : "Create account"}
          </Button>
          <p className="text-sm text-zinc-500 text-center">
            Already have an account?{" "}
            <Link to="/login" className="text-blue-600 hover:underline font-semibold" data-testid="register-go-login">Sign in</Link>
          </p>
        </form>
      </div>
      <div className="hidden lg:block bg-zinc-900 text-white p-12 relative overflow-hidden order-1 lg:order-2">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, rgba(255,255,255,0.4) 1px, transparent 0)", backgroundSize: "24px 24px" }} />
        <div className="relative max-w-md">
          <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-400 mb-6">New here</div>
          <h1 className="font-display font-black text-5xl tracking-tighter leading-none mb-6">
            Five minutes to<br />join the truth squad.
          </h1>
          <p className="text-zinc-400 leading-relaxed">
            Free forever. Rate movies, companies, gadgets, restaurants — your honest opinion is the product.
          </p>
        </div>
      </div>
    </div>
  );
}
