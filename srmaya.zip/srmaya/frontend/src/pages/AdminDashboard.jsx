import { useEffect, useState } from "react";
import api, { formatApiError } from "@/lib/api";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { toast } from "sonner";
import StarRating from "@/components/StarRating";
import { Trash2, ShieldCheck, ShieldOff, Star, AlertTriangle, Users, Tags, MessageSquare, Inbox, Check, X, Edit3 } from "lucide-react";
import { Link } from "react-router-dom";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

function StatBlock({ label, value, icon: Icon }) {
  return (
    <div className="border border-zinc-200 bg-white p-6">
      <div className="flex items-center justify-between mb-3">
        <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500">{label}</div>
        <Icon size={16} className="text-zinc-400" />
      </div>
      <div className="font-display font-black text-4xl tracking-tighter">{value}</div>
    </div>
  );
}

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [items, setItems] = useState([]);
  const [allReviews, setAllReviews] = useState([]);
  const [reportedReviews, setReportedReviews] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [editSub, setEditSub] = useState(null);

  const load = () => {
    Promise.all([
      api.get("/admin/stats").then((r) => setStats(r.data)),
      api.get("/admin/users").then((r) => setUsers(r.data)),
      api.get("/items?limit=200&sort=newest").then((r) => setItems(r.data.items)),
      api.get("/admin/reviews").then((r) => setAllReviews(r.data)),
      api.get("/admin/reviews?reported=true").then((r) => setReportedReviews(r.data)),
      api.get("/submissions/admin/all").then((r) => setSubmissions(r.data)),
    ]).catch(() => {});
  };

  useEffect(() => { load(); }, []);

  const updateUserRole = async (id, role) => {
    try {
      await api.patch(`/admin/users/${id}`, { role });
      toast.success(`Role updated to ${role}.`);
      load();
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  const deleteUser = async (id) => {
    if (!confirm("Delete this user and all their reviews?")) return;
    try {
      await api.delete(`/admin/users/${id}`);
      toast.success("User deleted.");
      load();
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  const deleteReview = async (id) => {
    if (!confirm("Delete this review?")) return;
    try {
      await api.delete(`/admin/reviews/${id}`);
      toast.success("Review deleted.");
      load();
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  const restoreReview = async (id) => {
    try {
      await api.post(`/admin/reviews/${id}/unreport`);
      toast.success("Review restored.");
      load();
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  const toggleFeature = async (id) => {
    try {
      await api.patch(`/admin/items/${id}/feature`);
      load();
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  const deleteItem = async (id) => {
    if (!confirm("Delete this item and all its reviews?")) return;
    try {
      await api.delete(`/items/${id}`);
      toast.success("Item deleted.");
      load();
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  const approveSubmission = async (id) => {
    try {
      await api.post(`/submissions/admin/${id}/approve`);
      toast.success("Submission approved & published.");
      load();
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  const rejectSubmission = async (id) => {
    const notes = prompt("Reason for rejection (optional):") || "";
    try {
      await api.post(`/submissions/admin/${id}/reject`, { notes });
      toast.success("Submission rejected.");
      load();
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  const deleteSubmission = async (id) => {
    if (!confirm("Delete this submission permanently?")) return;
    try {
      await api.delete(`/submissions/admin/${id}`);
      toast.success("Submission deleted.");
      load();
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  const saveSubmissionEdits = async (sub, edits) => {
    try {
      await api.patch(`/submissions/admin/${sub.id}`, edits);
      toast.success("Submission updated.");
      setEditSub(null);
      load();
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  return (
    <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-10" data-testid="admin-dashboard">
      <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-600 mb-3">Admin · Control Room</div>
      <h1 className="font-display font-black text-4xl lg:text-5xl tracking-tighter mb-8">Dashboard</h1>

      {stats && (
        <section className="grid grid-cols-2 lg:grid-cols-6 gap-0 border-l border-t border-zinc-200 mb-10">
          <div className="border-r border-b border-zinc-200 -ml-px -mt-px"><StatBlock label="Users" value={stats.users} icon={Users} /></div>
          <div className="border-r border-b border-zinc-200 -ml-px -mt-px"><StatBlock label="Items" value={stats.items} icon={Tags} /></div>
          <div className="border-r border-b border-zinc-200 -ml-px -mt-px"><StatBlock label="Reviews" value={stats.reviews} icon={MessageSquare} /></div>
          <div className="border-r border-b border-zinc-200 -ml-px -mt-px"><StatBlock label="Submissions (pending)" value={submissions.filter((s) => s.status === "pending").length} icon={Inbox} /></div>
          <div className="border-r border-b border-zinc-200 -ml-px -mt-px"><StatBlock label="Reported" value={stats.reported} icon={AlertTriangle} /></div>
          <div className="border-r border-b border-zinc-200 -ml-px -mt-px"><StatBlock label="Avg Rating" value={stats.average_rating?.toFixed?.(1) || "0.0"} icon={Star} /></div>
        </section>
      )}

      <Tabs defaultValue="submissions" className="w-full">
        <TabsList className="rounded-none bg-transparent border-b border-zinc-200 w-full justify-start gap-1 px-0 mb-6 h-auto flex-wrap">
          <TabsTrigger value="submissions" className="rounded-none data-[state=active]:bg-zinc-900 data-[state=active]:text-white px-5 py-2.5 text-xs uppercase tracking-[0.2em] font-bold" data-testid="tab-submissions">
            <Inbox size={12} className="mr-2" /> Submissions ({submissions.filter((s) => s.status === "pending").length})
          </TabsTrigger>
          <TabsTrigger value="reviews" className="rounded-none data-[state=active]:bg-zinc-900 data-[state=active]:text-white px-5 py-2.5 text-xs uppercase tracking-[0.2em] font-bold" data-testid="tab-reviews">Reviews</TabsTrigger>
          <TabsTrigger value="reported" className="rounded-none data-[state=active]:bg-zinc-900 data-[state=active]:text-white px-5 py-2.5 text-xs uppercase tracking-[0.2em] font-bold" data-testid="tab-reported">Reported ({reportedReviews.length})</TabsTrigger>
          <TabsTrigger value="users" className="rounded-none data-[state=active]:bg-zinc-900 data-[state=active]:text-white px-5 py-2.5 text-xs uppercase tracking-[0.2em] font-bold" data-testid="tab-users">Users</TabsTrigger>
          <TabsTrigger value="items" className="rounded-none data-[state=active]:bg-zinc-900 data-[state=active]:text-white px-5 py-2.5 text-xs uppercase tracking-[0.2em] font-bold" data-testid="tab-items">Items</TabsTrigger>
          <TabsTrigger value="analytics" className="rounded-none data-[state=active]:bg-zinc-900 data-[state=active]:text-white px-5 py-2.5 text-xs uppercase tracking-[0.2em] font-bold" data-testid="tab-analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="submissions">
          {submissions.length === 0 ? (
            <div className="border border-dashed border-zinc-300 p-12 text-center text-zinc-500">No user submissions yet.</div>
          ) : (
            <div className="border border-zinc-200" data-testid="admin-submissions-list">
              {submissions.map((s) => (
                <div key={s.id} className="grid lg:grid-cols-[100px_1fr_auto] gap-5 p-5 border-b last:border-b-0 border-zinc-200" data-testid={`admin-submission-${s.id}`}>
                  <div className="aspect-[4/3] bg-zinc-100 overflow-hidden hidden lg:block">
                    {s.featured_image ? <img src={s.featured_image} alt="" className="w-full h-full object-cover" /> : <div className="w-full h-full grid place-items-center text-zinc-400 text-[10px] uppercase">No img</div>}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500">{s.category_name}{s.subcategory ? ` · ${s.subcategory}` : ""}</span>
                      <span className={`text-[10px] font-bold uppercase tracking-[0.15em] px-2 py-0.5 ${s.status === "pending" ? "bg-amber-100 text-amber-800" : s.status === "approved" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-700"}`}>
                        {s.status}
                      </span>
                    </div>
                    <h3 className="font-display font-bold text-lg tracking-tight leading-tight mb-1">{s.title}</h3>
                    <p className="text-sm text-zinc-600 line-clamp-2 mb-2">{s.short_description}</p>
                    <p className="text-xs text-zinc-400 font-mono">By {s.user_name} · {new Date(s.created_at).toLocaleDateString()}</p>
                  </div>
                  <div className="flex flex-wrap gap-2 self-start">
                    {s.status === "pending" && (
                      <>
                        <Button size="sm" className="rounded-none bg-blue-600 hover:bg-blue-700" onClick={() => approveSubmission(s.id)} data-testid={`approve-sub-${s.id}`}>
                          <Check size={13} className="mr-1.5" /> Approve
                        </Button>
                        <Button size="sm" variant="outline" className="rounded-none" onClick={() => setEditSub(s)} data-testid={`edit-sub-${s.id}`}>
                          <Edit3 size={13} className="mr-1.5" /> Edit
                        </Button>
                        <Button size="sm" variant="outline" className="rounded-none border-red-300 text-red-600 hover:bg-red-50" onClick={() => rejectSubmission(s.id)} data-testid={`reject-sub-${s.id}`}>
                          <X size={13} className="mr-1.5" /> Reject
                        </Button>
                      </>
                    )}
                    {s.status === "approved" && (
                      <Link to={`/item/${s.slug}`}><Button size="sm" variant="outline" className="rounded-none">View live</Button></Link>
                    )}
                    <Button size="sm" variant="ghost" className="rounded-none text-red-600 hover:bg-red-50" onClick={() => deleteSubmission(s.id)} data-testid={`delete-sub-${s.id}`}>
                      <Trash2 size={13} />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
          {editSub && (
            <EditSubmissionDialog
              submission={editSub}
              onClose={() => setEditSub(null)}
              onSave={(edits) => saveSubmissionEdits(editSub, edits)}
              onApprove={async (edits) => {
                await saveSubmissionEdits(editSub, edits);
                await approveSubmission(editSub.id);
              }}
            />
          )}
        </TabsContent>

        <TabsContent value="reviews">
          <div className="border border-zinc-200">
            <table className="w-full text-sm">
              <thead className="bg-zinc-50 text-xs uppercase tracking-wide">
                <tr>
                  <th className="text-left p-3">Reviewer</th>
                  <th className="text-left p-3">Item</th>
                  <th className="text-left p-3">Rating</th>
                  <th className="text-left p-3">Title</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {allReviews.slice(0, 50).map((r) => (
                  <tr key={r.id} className="border-t border-zinc-200">
                    <td className="p-3 font-medium">{r.user_name}</td>
                    <td className="p-3"><Link to={`/item/${r.item_slug}`} className="text-blue-600 hover:underline">{r.item_name}</Link></td>
                    <td className="p-3"><StarRating value={r.rating} size={12} /></td>
                    <td className="p-3 text-zinc-600 line-clamp-1">{r.title}</td>
                    <td className="p-3 text-right">
                      <Button size="sm" variant="ghost" onClick={() => deleteReview(r.id)} className="rounded-none text-red-600 hover:bg-red-50" data-testid={`admin-delete-review-${r.id}`}>
                        <Trash2 size={13} />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </TabsContent>

        <TabsContent value="reported">
          {reportedReviews.length === 0 ? (
            <div className="border border-dashed border-zinc-300 p-12 text-center text-zinc-500">No reported reviews.</div>
          ) : (
            <div className="border border-zinc-200">
              {reportedReviews.map((r) => (
                <div key={r.id} className="p-5 border-b last:border-b-0 border-zinc-200 grid lg:grid-cols-[1fr_auto] gap-4">
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <span className="font-semibold text-sm">{r.user_name}</span>
                      <span className="text-xs text-zinc-400">on</span>
                      <Link to={`/item/${r.item_slug}`} className="text-blue-600 hover:underline text-sm">{r.item_name}</Link>
                      <StarRating value={r.rating} size={12} />
                    </div>
                    <h4 className="font-bold mb-1">{r.title}</h4>
                    <p className="text-sm text-zinc-600 line-clamp-2">{r.body}</p>
                  </div>
                  <div className="flex gap-2 self-start">
                    <Button size="sm" variant="outline" onClick={() => restoreReview(r.id)} className="rounded-none" data-testid={`admin-restore-${r.id}`}>
                      <ShieldCheck size={13} className="mr-1.5" /> Restore
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => deleteReview(r.id)} className="rounded-none border-red-300 text-red-600 hover:bg-red-50" data-testid={`admin-confirm-delete-${r.id}`}>
                      <Trash2 size={13} className="mr-1.5" /> Delete
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="users">
          <div className="border border-zinc-200">
            <table className="w-full text-sm">
              <thead className="bg-zinc-50 text-xs uppercase tracking-wide">
                <tr>
                  <th className="text-left p-3">User</th>
                  <th className="text-left p-3">Email</th>
                  <th className="text-left p-3">Role</th>
                  <th className="text-left p-3">Joined</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id} className="border-t border-zinc-200">
                    <td className="p-3 flex items-center gap-2">
                      <Avatar className="h-7 w-7 rounded-none"><AvatarImage src={u.avatar_url} /><AvatarFallback className="rounded-none bg-zinc-900 text-white text-[10px]">{u.name?.[0]}</AvatarFallback></Avatar>
                      <span className="font-medium">{u.name}</span>
                    </td>
                    <td className="p-3 text-zinc-600">{u.email}</td>
                    <td className="p-3">
                      <span className={`text-[10px] font-bold uppercase tracking-[0.15em] px-2 py-1 ${u.role === "admin" ? "bg-blue-600 text-white" : "bg-zinc-100"}`}>{u.role}</span>
                    </td>
                    <td className="p-3 text-xs text-zinc-500 font-mono">{u.created_at?.slice(0, 10)}</td>
                    <td className="p-3 text-right">
                      {u.role !== "admin" ? (
                        <>
                          <Button size="sm" variant="ghost" onClick={() => updateUserRole(u.id, "admin")} className="rounded-none mr-1" data-testid={`make-admin-${u.id}`}><ShieldCheck size={13} /></Button>
                          <Button size="sm" variant="ghost" onClick={() => deleteUser(u.id)} className="rounded-none text-red-600" data-testid={`delete-user-${u.id}`}><Trash2 size={13} /></Button>
                        </>
                      ) : (
                        <Button size="sm" variant="ghost" onClick={() => updateUserRole(u.id, "user")} className="rounded-none" data-testid={`demote-user-${u.id}`}><ShieldOff size={13} /></Button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </TabsContent>

        <TabsContent value="items">
          <div className="border border-zinc-200">
            <table className="w-full text-sm">
              <thead className="bg-zinc-50 text-xs uppercase tracking-wide">
                <tr>
                  <th className="text-left p-3">Item</th>
                  <th className="text-left p-3">Category</th>
                  <th className="text-left p-3">Rating</th>
                  <th className="text-left p-3">Reviews</th>
                  <th className="text-left p-3">Featured</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {items.map((it) => (
                  <tr key={it.id} className="border-t border-zinc-200">
                    <td className="p-3"><Link to={`/item/${it.slug}`} className="font-medium hover:text-blue-600">{it.name}</Link></td>
                    <td className="p-3 text-zinc-600">{it.category_name}</td>
                    <td className="p-3"><span className="font-bold">{it.avg_rating.toFixed(1)}</span></td>
                    <td className="p-3 text-zinc-500 font-mono">{it.review_count}</td>
                    <td className="p-3">{it.featured ? <span className="bg-zinc-900 text-white text-[10px] font-bold uppercase tracking-[0.15em] px-2 py-1">Yes</span> : "—"}</td>
                    <td className="p-3 text-right">
                      <Button size="sm" variant="ghost" onClick={() => toggleFeature(it.id)} className="rounded-none mr-1" data-testid={`toggle-feature-${it.id}`}><Star size={13} /></Button>
                      <Button size="sm" variant="ghost" onClick={() => deleteItem(it.id)} className="rounded-none text-red-600" data-testid={`delete-item-${it.id}`}><Trash2 size={13} /></Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </TabsContent>

        <TabsContent value="analytics">
          {stats && (
            <div className="grid lg:grid-cols-2 gap-6">
              <div className="border border-zinc-200 p-6 bg-white">
                <div className="text-xs font-bold uppercase tracking-[0.2em] mb-4">Reviews by category</div>
                <div className="space-y-3">
                  {stats.by_category.map((row) => {
                    const max = Math.max(...stats.by_category.map((r) => r.count), 1);
                    const pct = Math.round((row.count / max) * 100);
                    return (
                      <div key={row.category} className="flex items-center gap-3">
                        <span className="w-32 text-sm text-zinc-700 truncate">{row.category}</span>
                        <div className="flex-1 h-2 bg-zinc-100 relative overflow-hidden">
                          <div className="absolute inset-y-0 left-0 bg-blue-600" style={{ width: `${pct}%` }} />
                        </div>
                        <span className="w-10 text-right text-xs text-zinc-500 font-mono">{row.count}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
              <div className="border border-zinc-200 p-6 bg-white">
                <div className="text-xs font-bold uppercase tracking-[0.2em] mb-4">Top items</div>
                <div className="space-y-3">
                  {stats.top_items.map((it, i) => (
                    <Link to={`/item/${it.slug}`} key={it.id} className="flex items-center gap-3 hover:bg-zinc-50 -mx-2 px-2 py-1.5 transition-colors">
                      <span className="font-mono text-xs w-6 text-zinc-400">#{i + 1}</span>
                      <span className="flex-1 text-sm font-medium truncate">{it.name}</span>
                      <StarRating value={it.avg_rating} size={11} />
                      <span className="text-xs font-bold w-8 text-right">{it.avg_rating.toFixed(1)}</span>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function EditSubmissionDialog({ submission, onClose, onSave, onApprove }) {
  const [form, setForm] = useState({
    title: submission.title || "",
    slug: submission.slug || "",
    short_description: submission.short_description || "",
    full_description: submission.full_description || "",
    featured_image: submission.featured_image || "",
    tags: (submission.tags || []).join(", "),
    admin_notes: submission.admin_notes || "",
  });

  const buildEdits = () => ({
    title: form.title,
    slug: form.slug,
    short_description: form.short_description,
    full_description: form.full_description,
    featured_image: form.featured_image,
    tags: form.tags.split(",").map((t) => t.trim()).filter(Boolean),
    admin_notes: form.admin_notes || null,
  });

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="rounded-none max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-display font-black text-2xl tracking-tighter">Edit submission</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2" data-testid="admin-edit-sub-form">
          <div>
            <label className="text-xs font-bold uppercase tracking-[0.2em] mb-1.5 block">Title</label>
            <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-600" />
          </div>
          <div>
            <label className="text-xs font-bold uppercase tracking-[0.2em] mb-1.5 block">Slug</label>
            <input value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2 text-sm font-mono outline-none focus:ring-2 focus:ring-blue-600" />
          </div>
          <div>
            <label className="text-xs font-bold uppercase tracking-[0.2em] mb-1.5 block">Short description</label>
            <input value={form.short_description} onChange={(e) => setForm({ ...form, short_description: e.target.value })} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-600" />
          </div>
          <div>
            <label className="text-xs font-bold uppercase tracking-[0.2em] mb-1.5 block">Full description</label>
            <textarea rows={5} value={form.full_description} onChange={(e) => setForm({ ...form, full_description: e.target.value })} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-600" />
          </div>
          <div>
            <label className="text-xs font-bold uppercase tracking-[0.2em] mb-1.5 block">Featured image URL</label>
            <input value={form.featured_image} onChange={(e) => setForm({ ...form, featured_image: e.target.value })} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2 text-sm font-mono outline-none focus:ring-2 focus:ring-blue-600" />
          </div>
          <div>
            <label className="text-xs font-bold uppercase tracking-[0.2em] mb-1.5 block">Tags</label>
            <input value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-600" placeholder="comma, separated" />
          </div>
          <div>
            <label className="text-xs font-bold uppercase tracking-[0.2em] mb-1.5 block">Admin notes (optional)</label>
            <input value={form.admin_notes} onChange={(e) => setForm({ ...form, admin_notes: e.target.value })} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-600" />
          </div>
        </div>
        <div className="flex flex-wrap gap-2 mt-4">
          <Button onClick={() => onSave(buildEdits())} className="rounded-none" data-testid="admin-save-edits-btn">Save edits</Button>
          <Button onClick={() => onApprove(buildEdits())} className="rounded-none bg-blue-600 hover:bg-blue-700" data-testid="admin-edit-then-approve-btn">
            <Check size={13} className="mr-1.5" /> Save & approve
          </Button>
          <Button variant="ghost" onClick={onClose} className="rounded-none ml-auto">Cancel</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

