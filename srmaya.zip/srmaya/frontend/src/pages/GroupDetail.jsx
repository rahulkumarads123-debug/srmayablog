import { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import api, { formatApiError } from "@/lib/api";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { toast } from "sonner";
import { Users, MessageSquare, Heart, Trash2, UserPlus, UserMinus, Sparkles, Calendar, Crown } from "lucide-react";
import StarRating from "@/components/StarRating";

function timeAgo(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  const s = Math.round((Date.now() - d.getTime()) / 1000);
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  if (s < 86400) return `${Math.round(s / 3600)}h ago`;
  return `${Math.round(s / 86400)}d ago`;
}

function PostCard({ post, currentUser, groupCreatorId, onLike, onDelete }) {
  const liked = currentUser && typeof currentUser === "object" && (post.liked_user_ids || []).includes(currentUser.id);
  const canDelete = currentUser && typeof currentUser === "object" && (
    post.user_id === currentUser.id || currentUser.id === groupCreatorId || currentUser.role === "admin"
  );
  const initials = post.user_name?.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();

  return (
    <article className="border border-zinc-200 bg-white p-6 fade-up" data-testid={`post-${post.id}`}>
      <header className="flex items-start justify-between gap-4 mb-3">
        <div className="flex items-center gap-3">
          <Avatar className="h-9 w-9 rounded-none">
            <AvatarImage src={post.user_avatar} />
            <AvatarFallback className="rounded-none bg-zinc-900 text-white text-xs">{initials}</AvatarFallback>
          </Avatar>
          <div>
            <div className="font-semibold text-sm">{post.user_name}</div>
            <div className="text-xs text-zinc-500 font-mono">{timeAgo(post.created_at)}</div>
          </div>
        </div>
        <span className={`text-[10px] font-bold uppercase tracking-[0.15em] px-2 py-1 ${post.type === "recommendation" ? "bg-blue-600 text-white" : "bg-zinc-100 text-zinc-700"}`}>
          {post.type === "recommendation" ? "Recommendation" : "Discussion"}
        </span>
      </header>
      <h3 className="font-display font-bold text-xl tracking-tight leading-tight mb-3">{post.title}</h3>
      <p className="text-zinc-700 leading-relaxed whitespace-pre-line mb-4">{post.body}</p>

      {post.type === "recommendation" && post.item_slug && (
        <Link to={`/item/${post.item_slug}`} className="flex gap-4 border border-zinc-200 hover:border-zinc-900 p-3 mb-4 transition-colors" data-testid={`post-recommendation-${post.id}`}>
          <div className="w-16 h-16 flex-shrink-0 bg-zinc-100 overflow-hidden">
            {post.item_image && <img src={post.item_image} alt="" className="w-full h-full object-cover" />}
          </div>
          <div className="min-w-0">
            <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-blue-600 mb-1">Recommended listing</div>
            <h4 className="font-semibold text-sm leading-tight line-clamp-1">{post.item_name}</h4>
            <div className="flex items-center gap-1.5 mt-1.5">
              <StarRating value={post.item_rating || 0} size={11} />
              <span className="text-xs text-zinc-500 font-mono">{(post.item_rating || 0).toFixed(1)}</span>
            </div>
          </div>
        </Link>
      )}

      <footer className="flex items-center gap-2">
        <Button size="sm" variant="outline" onClick={() => onLike(post)} className={`rounded-none border-zinc-200 hover:border-zinc-900 ${liked ? "bg-zinc-900 text-white border-zinc-900" : ""}`} data-testid={`post-like-${post.id}`}>
          <Heart size={12} className="mr-1.5" /> {post.likes_count || 0}
        </Button>
        {canDelete && (
          <Button size="sm" variant="ghost" onClick={() => onDelete(post)} className="rounded-none text-zinc-500 hover:text-red-600 ml-auto" data-testid={`post-delete-${post.id}`}>
            <Trash2 size={12} />
          </Button>
        )}
      </footer>
    </article>
  );
}

function PostComposer({ groupId, onPosted }) {
  const [type, setType] = useState("discussion");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [itemSlug, setItemSlug] = useState("");
  const [itemSearch, setItemSearch] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [posting, setPosting] = useState(false);

  useEffect(() => {
    if (type !== "recommendation" || itemSearch.length < 2) {
      setSearchResults([]);
      return;
    }
    const t = setTimeout(() => {
      api.get(`/items?q=${encodeURIComponent(itemSearch)}&limit=6`).then((r) => setSearchResults(r.data.items));
    }, 250);
    return () => clearTimeout(t);
  }, [itemSearch, type]);

  const post = async () => {
    if (!title || !body) { toast.error("Add a title and body."); return; }
    if (type === "recommendation" && !itemSlug) { toast.error("Pick the item you're recommending."); return; }
    setPosting(true);
    try {
      await api.post(`/groups/${groupId}/posts`, { type, title, body, item_slug: itemSlug || null });
      toast.success("Posted.");
      setTitle(""); setBody(""); setItemSlug(""); setItemSearch(""); setSearchResults([]);
      onPosted?.();
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    } finally {
      setPosting(false);
    }
  };

  return (
    <div className="border border-zinc-200 bg-white p-5 mb-6" data-testid="post-composer">
      <div className="flex items-center gap-2 mb-4">
        {[{ k: "discussion", label: "Discussion", Icon: MessageSquare }, { k: "recommendation", label: "Recommend a listing", Icon: Sparkles }].map(({ k, label, Icon }) => (
          <button key={k} onClick={() => setType(k)} className={`text-xs font-bold uppercase tracking-[0.15em] px-3 py-1.5 transition-colors ${type === k ? "bg-zinc-900 text-white" : "bg-zinc-100 hover:bg-zinc-200"}`} data-testid={`composer-type-${k}`}>
            <Icon size={11} className="inline mr-1.5" /> {label}
          </button>
        ))}
      </div>
      <input value={title} onChange={(e) => setTitle(e.target.value)} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2.5 text-sm font-semibold focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none mb-2" placeholder="Title" data-testid="composer-title" />
      <textarea value={body} onChange={(e) => setBody(e.target.value)} rows={3} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none mb-2" placeholder={type === "recommendation" ? "Why are you recommending this?" : "What's on your mind?"} data-testid="composer-body" />

      {type === "recommendation" && (
        <div className="relative mb-2">
          {itemSlug ? (
            <div className="flex items-center justify-between border border-blue-600 bg-blue-50/30 px-3 py-2 text-sm">
              <span>Linking: <strong>{itemSlug}</strong></span>
              <button onClick={() => { setItemSlug(""); setItemSearch(""); }} className="text-zinc-400 hover:text-red-600 text-xs">change</button>
            </div>
          ) : (
            <>
              <input value={itemSearch} onChange={(e) => setItemSearch(e.target.value)} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" placeholder="Search for the listing to link…" data-testid="composer-item-search" />
              {searchResults.length > 0 && (
                <div className="absolute z-10 left-0 right-0 mt-1 bg-white border border-zinc-900 max-h-72 overflow-y-auto" data-testid="composer-search-results">
                  {searchResults.map((it) => (
                    <button key={it.id} onClick={() => { setItemSlug(it.slug); setItemSearch(it.name); setSearchResults([]); }} className="w-full text-left p-2 hover:bg-zinc-100 flex items-center gap-2 text-sm border-b border-zinc-100 last:border-b-0">
                      <div className="w-9 h-9 bg-zinc-100 overflow-hidden flex-shrink-0">
                        {it.image_url && <img src={it.image_url} alt="" className="w-full h-full object-cover" />}
                      </div>
                      <div className="min-w-0">
                        <div className="font-semibold text-xs truncate">{it.name}</div>
                        <div className="text-[10px] text-zinc-500 truncate uppercase tracking-wide">{it.category_name}</div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      )}

      <Button onClick={post} disabled={posting} className="rounded-none bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs uppercase tracking-[0.15em]" data-testid="composer-post-btn">
        {posting ? "Posting..." : "Post"}
      </Button>
    </div>
  );
}

export default function GroupDetail() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [group, setGroup] = useState(null);
  const [posts, setPosts] = useState([]);
  const [members, setMembers] = useState([]);
  const [isMember, setIsMember] = useState(false);
  const [sort, setSort] = useState("newest");
  const [loading, setLoading] = useState(true);

  const loadAll = async () => {
    setLoading(true);
    try {
      const g = await api.get(`/groups/${slug}`);
      setGroup(g.data);
      const [p, m] = await Promise.all([
        api.get(`/groups/${g.data.id}/posts?sort=${sort}`),
        api.get(`/groups/${g.data.id}/members`),
      ]);
      setPosts(p.data);
      setMembers(m.data);
      if (user && typeof user === "object") {
        try {
          const st = await api.get(`/groups/${g.data.id}/is-member`);
          setIsMember(st.data.is_member);
        } catch { /* anon */ }
      }
    } catch {
      setGroup(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadAll(); }, [slug, user]);

  useEffect(() => {
    if (!group) return;
    api.get(`/groups/${group.id}/posts?sort=${sort}`).then((r) => setPosts(r.data));
  }, [sort, group]);

  const handleJoin = async () => {
    if (!user || typeof user !== "object") { navigate("/login"); return; }
    try {
      await api.post(`/groups/${group.id}/join`);
      toast.success(`Joined ${group.name}.`);
      loadAll();
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  const handleLeave = async () => {
    try {
      await api.post(`/groups/${group.id}/leave`);
      toast.success("Left group.");
      loadAll();
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  const handleLike = async (post) => {
    if (!user || typeof user !== "object") { toast.error("Sign in to like posts."); return; }
    try {
      const { data } = await api.post(`/groups/posts/${post.id}/like`);
      setPosts((ps) => ps.map((p) => (p.id === post.id ? data : p)));
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  const handleDeletePost = async (post) => {
    if (!confirm("Delete this post?")) return;
    try {
      await api.delete(`/groups/posts/${post.id}`);
      setPosts((ps) => ps.filter((p) => p.id !== post.id));
      toast.success("Post deleted.");
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  const handleDeleteGroup = async () => {
    if (!confirm(`Delete the group "${group.name}" and all its posts? This cannot be undone.`)) return;
    try {
      await api.delete(`/groups/${group.id}`);
      toast.success("Group deleted.");
      navigate("/groups");
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    }
  };

  if (loading && !group) {
    return <div className="max-w-[1400px] mx-auto px-6 py-20 text-zinc-400 text-xs uppercase tracking-[0.3em]">Loading...</div>;
  }
  if (!group) {
    return (
      <div className="max-w-[1400px] mx-auto px-6 py-20">
        <h1 className="font-display font-black text-3xl mb-4">Group not found</h1>
        <Link to="/groups" className="text-blue-600 hover:underline">← All groups</Link>
      </div>
    );
  }

  const isCreator = user && typeof user === "object" && user.id === group.creator_id;
  const isAdmin = user && typeof user === "object" && user.role === "admin";

  return (
    <div data-testid="group-detail-page">
      {/* Cover hero */}
      <section className="bg-zinc-900 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-40">
          {group.cover_url && <img src={group.cover_url} alt="" className="w-full h-full object-cover" />}
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-zinc-900/80 to-transparent" />
        </div>
        <div className="relative max-w-[1400px] mx-auto px-6 lg:px-10 py-14 grid lg:grid-cols-12 gap-8 items-end">
          <div className="lg:col-span-8">
            <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-400 mb-3 flex items-center gap-2">
              <Users size={12} /> Community {group.category_slug && <>· <Link to={`/category/${group.category_slug}`} className="hover:text-white">{group.category_slug}</Link></>}
            </div>
            <h1 className="font-display font-black text-5xl lg:text-6xl tracking-tighter leading-none mb-4">{group.name}</h1>
            <p className="text-zinc-300 leading-relaxed max-w-2xl mb-6">{group.description}</p>
            <div className="flex items-center gap-4 text-sm text-zinc-300">
              <span className="flex items-center gap-1.5"><Users size={13} /> {group.member_count} members</span>
              <span className="flex items-center gap-1.5"><MessageSquare size={13} /> {group.post_count} posts</span>
              <span className="flex items-center gap-1.5"><Calendar size={13} /> Created {new Date(group.created_at).toLocaleDateString()}</span>
            </div>
          </div>
          <div className="lg:col-span-4 flex lg:justify-end gap-2 flex-wrap">
            {isMember ? (
              <Button onClick={handleLeave} disabled={isCreator} variant="outline" className="rounded-none border-white/30 bg-transparent text-white hover:bg-white hover:text-zinc-900 px-6 py-5 text-xs uppercase tracking-[0.15em] font-bold disabled:opacity-50" data-testid="group-leave-btn">
                {isCreator ? <><Crown size={13} className="mr-1.5" /> Creator</> : <><UserMinus size={13} className="mr-1.5" /> Leave</>}
              </Button>
            ) : (
              <Button onClick={handleJoin} className="rounded-none bg-blue-600 hover:bg-blue-500 text-white px-7 py-5 text-xs uppercase tracking-[0.15em] font-bold" data-testid="group-join-btn">
                <UserPlus size={13} className="mr-1.5" /> Join group
              </Button>
            )}
            {(isCreator || isAdmin) && (
              <Button onClick={handleDeleteGroup} variant="outline" className="rounded-none border-red-300/40 text-red-300 hover:bg-red-600 hover:text-white px-4 py-5 text-xs uppercase tracking-[0.15em] font-bold" data-testid="group-delete-btn">
                <Trash2 size={13} />
              </Button>
            )}
          </div>
        </div>
      </section>

      {/* Body */}
      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-10 grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-8">
          <Tabs defaultValue="posts" className="w-full">
            <TabsList className="rounded-none bg-transparent border-b border-zinc-200 w-full justify-start gap-1 px-0 mb-6 h-auto">
              <TabsTrigger value="posts" className="rounded-none data-[state=active]:bg-zinc-900 data-[state=active]:text-white px-5 py-2.5 text-xs uppercase tracking-[0.2em] font-bold" data-testid="group-tab-posts">Posts ({posts.length})</TabsTrigger>
              <TabsTrigger value="about" className="rounded-none data-[state=active]:bg-zinc-900 data-[state=active]:text-white px-5 py-2.5 text-xs uppercase tracking-[0.2em] font-bold" data-testid="group-tab-about">About</TabsTrigger>
            </TabsList>

            <TabsContent value="posts">
              {isMember && <PostComposer groupId={group.id} onPosted={loadAll} />}
              {!isMember && (
                <div className="border border-dashed border-zinc-300 p-6 text-center mb-6">
                  <p className="text-zinc-500 text-sm mb-3">Join the group to start a discussion or recommend a listing.</p>
                  <Button onClick={handleJoin} className="rounded-none bg-blue-600 hover:bg-blue-700 text-white font-semibold"><UserPlus size={13} className="mr-1.5" /> Join group</Button>
                </div>
              )}

              <div className="flex items-end justify-between mb-4">
                <h2 className="font-display font-black text-2xl tracking-tighter">Activity</h2>
                <select value={sort} onChange={(e) => setSort(e.target.value)} className="bg-white border border-zinc-200 rounded-none px-3 py-1.5 text-xs uppercase tracking-[0.15em] font-bold focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" data-testid="group-posts-sort">
                  <option value="newest">Newest</option>
                  <option value="popular">Most liked</option>
                </select>
              </div>

              {posts.length === 0 ? (
                <div className="border border-dashed border-zinc-300 p-12 text-center text-zinc-500">No posts yet — be the first.</div>
              ) : (
                <div className="space-y-4" data-testid="group-posts-list">
                  {posts.map((p) => (
                    <PostCard key={p.id} post={p} currentUser={user} groupCreatorId={group.creator_id} onLike={handleLike} onDelete={handleDeletePost} />
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="about">
              <div className="border border-zinc-200 bg-white p-8" data-testid="group-about">
                <h3 className="text-xs font-bold uppercase tracking-[0.2em] mb-3">About this group</h3>
                <p className="text-zinc-700 leading-relaxed whitespace-pre-line mb-6">{group.description}</p>
                <div className="grid sm:grid-cols-2 gap-6 border-t border-zinc-200 pt-6 text-sm">
                  <div>
                    <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500 mb-1">Created by</div>
                    <div className="font-semibold">{group.creator_name}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500 mb-1">Created on</div>
                    <div className="font-semibold">{new Date(group.created_at).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}</div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Members sidebar */}
        <aside className="lg:col-span-4 lg:sticky lg:top-24 self-start space-y-6">
          <div className="border border-zinc-200 bg-white p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="text-xs font-bold uppercase tracking-[0.2em] flex items-center gap-1.5"><Users size={11} /> Members</div>
              <span className="text-xs font-mono text-zinc-500">{members.length}</span>
            </div>
            <div className="space-y-3" data-testid="group-members">
              {members.slice(0, 20).map((m) => {
                const initials = m.user_name?.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();
                return (
                  <div key={m.id} className="flex items-center gap-3" data-testid={`member-${m.user_id}`}>
                    <Avatar className="h-8 w-8 rounded-none">
                      <AvatarImage src={m.user_avatar} />
                      <AvatarFallback className="rounded-none bg-zinc-900 text-white text-[10px]">{initials}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">{m.user_name}</div>
                      {m.role === "creator" && (
                        <div className="text-[10px] font-bold uppercase tracking-[0.15em] text-blue-600 flex items-center gap-1"><Crown size={10} /> Creator</div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </aside>
      </section>
    </div>
  );
}
