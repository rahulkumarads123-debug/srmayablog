import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api, { formatApiError } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useEffect } from "react";
import ImageUploader from "@/components/ImageUploader";

function slugify(s) {
  return (s || "").toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}

export default function CreateGroup() {
  const navigate = useNavigate();
  const [categories, setCategories] = useState([]);
  const [form, setForm] = useState({ name: "", slug: "", description: "", cover_url: "", category_slug: "" });
  const [loading, setLoading] = useState(false);

  useEffect(() => { api.get("/categories").then((r) => setCategories(r.data)); }, []);

  // Auto-slug from name (only while user hasn't overridden)
  useEffect(() => {
    setForm((prev) => {
      const auto = slugify(prev.name);
      if (!prev.slug || prev.slug === slugify(prev.slug)) return { ...prev, slug: auto };
      return prev;
    });
  }, [form.name]);

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || form.name.length < 3) { toast.error("Name must be at least 3 characters."); return; }
    if (!form.description || form.description.length < 10) { toast.error("Add a description (min 10 chars)."); return; }
    setLoading(true);
    try {
      const { data } = await api.post("/groups", {
        name: form.name,
        slug: form.slug || undefined,
        description: form.description,
        cover_url: form.cover_url || undefined,
        category_slug: form.category_slug || undefined,
      });
      toast.success("Group created.");
      navigate(`/groups/${data.slug}`);
    } catch (e) {
      toast.error(formatApiError(e.response?.data?.detail) || "Failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-[900px] mx-auto px-6 lg:px-10 py-12" data-testid="create-group-page">
      <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-600 mb-3">Create</div>
      <h1 className="font-display font-black text-4xl lg:text-5xl tracking-tighter mb-3">Start a group</h1>
      <p className="text-zinc-600 leading-relaxed mb-8 max-w-2xl">
        Groups are open by default — anyone can join. Pick a focused topic so the right people show up.
      </p>
      <form onSubmit={onSubmit} className="space-y-6" data-testid="create-group-form">
        <div>
          <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">Group name <span className="text-red-500">*</span></label>
          <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-3 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" placeholder="e.g. Korean Drama Connoisseurs" data-testid="group-name-input" />
        </div>
        <div>
          <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">URL slug</label>
          <div className="flex">
            <span className="border border-r-0 border-zinc-200 bg-zinc-100 px-3 py-3 text-xs font-mono text-zinc-500 flex items-center">/groups/</span>
            <input value={form.slug} onChange={(e) => setForm({ ...form, slug: slugify(e.target.value) })} className="flex-1 bg-zinc-50 border border-zinc-200 rounded-none px-3 py-3 text-sm font-mono focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" placeholder="auto-from-name" data-testid="group-slug-input" />
          </div>
        </div>
        <div>
          <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">Description <span className="text-red-500">*</span></label>
          <textarea required rows={4} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-3 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" placeholder="Who is this group for? What will members talk about?" data-testid="group-desc-input" />
        </div>
        <div className="grid sm:grid-cols-2 gap-5">
          <div>
            <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">Anchor category (optional)</label>
            <select value={form.category_slug} onChange={(e) => setForm({ ...form, category_slug: e.target.value })} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-3 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" data-testid="group-category-select">
              <option value="">No specific category</option>
              {categories.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}
            </select>
          </div>
          <div>
            <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">Cover image (optional)</label>
            <ImageUploader
              value={form.cover_url}
              onChange={(url) => setForm({ ...form, cover_url: url })}
              aspect="aspect-video"
              testId="group-cover-uploader"
            />
          </div>
        </div>
        <Button type="submit" disabled={loading} className="rounded-none bg-blue-600 hover:bg-blue-700 text-white font-semibold py-6 px-8 text-sm uppercase tracking-[0.15em]" data-testid="create-group-submit">
          {loading ? "Creating..." : "Create group"}
        </Button>
      </form>
    </div>
  );
}
