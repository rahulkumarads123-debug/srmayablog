import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "@/lib/api";
import ItemCard from "@/components/ItemCard";
import CategoryCard from "@/components/CategoryCard";
import { Button } from "@/components/ui/button";
import { Search, ArrowRight, Sparkles, TrendingUp, Award, Quote } from "lucide-react";
import StarRating from "@/components/StarRating";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

function formatDate(iso) {
  try { return new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric" }); } catch { return ""; }
}

export default function Home() {
  const [categories, setCategories] = useState([]);
  const [trending, setTrending] = useState([]);
  const [topRated, setTopRated] = useState([]);
  const [latestReviews, setLatestReviews] = useState([]);
  const [q, setQ] = useState("");
  const [stats, setStats] = useState({ items: 0, reviews: 0 });
  const navigate = useNavigate();

  useEffect(() => {
    Promise.all([
      api.get("/categories"),
      api.get("/items/trending?limit=8"),
      api.get("/items/top?limit=6"),
    ]).then(async ([cats, trend, top]) => {
      setCategories(cats.data);
      setTrending(trend.data);
      setTopRated(top.data);
      // latest reviews — pull from a few items
      const ids = trend.data.slice(0, 4).map((i) => i.id);
      const reviewsBuckets = await Promise.all(ids.map((id) => api.get(`/items/${trend.data.find((x) => x.id === id).slug}/related`).catch(() => ({ data: [] }))));
      // Just hit reviews endpoint of top items
      const allReviews = await Promise.all(
        trend.data.slice(0, 6).map((it) => api.get(`/items/${it.id}/reviews?sort=newest`).then((r) => r.data.slice(0, 1)).catch(() => []))
      );
      const flat = allReviews.flat().sort((a, b) => (b.created_at || "").localeCompare(a.created_at || "")).slice(0, 4);
      setLatestReviews(flat);
      const totalItems = cats.data.reduce((s, c) => s + (c.item_count || 0), 0);
      const totalReviews = trend.data.reduce((s, i) => s + (i.review_count || 0), 0);
      setStats({ items: totalItems, reviews: totalReviews });
      // suppress unused var lint
      void reviewsBuckets;
    }).catch(() => {});
  }, []);

  const onSearch = (e) => {
    e.preventDefault();
    if (q.trim()) navigate(`/search?q=${encodeURIComponent(q.trim())}`);
  };

  return (
    <div data-testid="home-page">
      {/* Hero */}
      <section className="border-b border-zinc-200 bg-white">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 pt-16 lg:pt-24 pb-20 grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-7">
            <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-600 mb-6 flex items-center gap-2">
              <span className="w-8 h-px bg-blue-600 inline-block" />
              An honest review platform · est. 2026
            </div>
            <h1 className="font-display font-black text-5xl sm:text-6xl lg:text-7xl tracking-tighter leading-[0.95] mb-8">
              Rate everything.
              <br />
              <span className="text-blue-600">Trust nothing</span> by default.
            </h1>
            <p className="text-lg text-zinc-600 leading-relaxed max-w-xl mb-10">
              Movies, companies, gadgets, restaurants, apps, hospitals, colleges — search any of them, read what real people say, and contribute reviews of your own.
            </p>

            <form onSubmit={onSearch} className="flex border border-zinc-900 max-w-xl" data-testid="hero-search-form">
              <div className="flex-1 flex items-center pl-5">
                <Search size={18} className="text-zinc-400 mr-3" />
                <input
                  type="search"
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder='Try "headphones", "Tartine", or "AI startup"'
                  className="flex-1 py-4 outline-none text-sm bg-transparent"
                  data-testid="hero-search-input"
                />
              </div>
              <button
                type="submit"
                className="bg-zinc-900 hover:bg-blue-600 text-white px-6 lg:px-8 font-semibold text-sm uppercase tracking-[0.15em] transition-colors"
                data-testid="hero-search-submit"
              >
                Search
              </button>
            </form>
            <div className="mt-6 flex items-center gap-5 text-xs text-zinc-500 font-mono uppercase tracking-[0.2em]">
              <span>{stats.items}+ listings</span>
              <span className="w-1 h-1 bg-zinc-300 rounded-full" />
              <span>{stats.reviews}+ reviews</span>
              <span className="w-1 h-1 bg-zinc-300 rounded-full" />
              <span>5 categories</span>
            </div>
          </div>

          <div className="lg:col-span-5 hidden lg:block">
            <div className="border border-zinc-900 p-1 bg-white">
              <div className="bg-zinc-50 p-6 h-full">
                <div className="flex items-center justify-between mb-6">
                  <span className="text-xs font-bold uppercase tracking-[0.2em] text-zinc-900">Featured Listing</span>
                  <span className="font-mono text-xs text-zinc-400">#001</span>
                </div>
                {trending[0] && (
                  <Link to={`/item/${trending[0].slug}`} className="block group" data-testid="hero-featured-card">
                    <div className="aspect-video bg-zinc-200 mb-5 overflow-hidden">
                      {trending[0].image_url && (
                        <img src={trending[0].image_url} alt={trending[0].name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                      )}
                    </div>
                    <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500 mb-2">
                      {trending[0].category_name}
                    </div>
                    <h3 className="font-display font-bold text-2xl tracking-tighter mb-3 group-hover:text-blue-600 transition-colors">
                      {trending[0].name}
                    </h3>
                    <div className="flex items-center justify-between border-t border-zinc-200 pt-4">
                      <StarRating value={trending[0].avg_rating} size={16} />
                      <span className="font-bold text-lg">{trending[0].avg_rating?.toFixed(1)}</span>
                    </div>
                  </Link>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="border-b border-zinc-200">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-20">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-12">
            <div>
              <div className="text-xs font-bold uppercase tracking-[0.3em] text-zinc-500 mb-3">01 — Browse</div>
              <h2 className="font-display font-black text-3xl sm:text-4xl lg:text-5xl tracking-tighter">
                Five categories, every opinion that matters
              </h2>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-0 border border-zinc-200" data-testid="categories-grid">
            {categories.map((c, i) => (
              <div key={c.id} className="border-r last:border-r-0 border-b lg:border-b-0 sm:[&:nth-child(2)]:border-r-0 lg:[&:nth-child(2)]:border-r border-zinc-200">
                <CategoryCard category={c} index={i} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trending */}
      <section className="border-b border-zinc-200">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-20">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10">
            <div>
              <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-600 mb-3 flex items-center gap-2">
                <TrendingUp size={12} /> 02 — Trending now
              </div>
              <h2 className="font-display font-black text-3xl sm:text-4xl lg:text-5xl tracking-tighter">
                What people are reviewing this week
              </h2>
            </div>
            <Button variant="ghost" className="rounded-none self-start md:self-auto" onClick={() => navigate("/search?sort=trending")}>
              View all <ArrowRight size={16} className="ml-2" />
            </Button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-0 border-l border-t border-zinc-200" data-testid="trending-grid">
            {trending.map((it, i) => (
              <div key={it.id} className="border-r border-b border-zinc-200 -ml-px -mt-px">
                <ItemCard item={it} index={i} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Top rated */}
      <section className="border-b border-zinc-200 bg-zinc-50">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-20">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10">
            <div>
              <div className="text-xs font-bold uppercase tracking-[0.3em] text-zinc-500 mb-3 flex items-center gap-2">
                <Award size={12} /> 03 — Top rated
              </div>
              <h2 className="font-display font-black text-3xl sm:text-4xl lg:text-5xl tracking-tighter">
                Highest rated, across everything
              </h2>
            </div>
            <Button variant="ghost" className="rounded-none" onClick={() => navigate("/top10")}>
              See full Top 10 <ArrowRight size={16} className="ml-2" />
            </Button>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-0 border border-zinc-200 bg-white" data-testid="top-rated-list">
            {topRated.map((it, i) => (
              <Link
                key={it.id}
                to={`/item/${it.slug}`}
                className="group flex gap-5 p-5 border-b lg:[&:nth-last-child(-n+2)]:border-b-0 [&:last-child]:border-b-0 lg:odd:border-r border-zinc-200 hover:bg-zinc-50 transition-colors fade-up"
                style={{ animationDelay: `${i * 60}ms` }}
                data-testid={`top-rated-row-${it.slug}`}
              >
                <div className="font-display font-black text-4xl tracking-tighter w-12 text-zinc-300 group-hover:text-blue-600 transition-colors leading-none">
                  {String(i + 1).padStart(2, "0")}
                </div>
                <div className="w-24 h-20 flex-shrink-0 bg-zinc-100 overflow-hidden">
                  {it.image_url && (<img src={it.image_url} alt={it.name} className="w-full h-full object-cover" />)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500 mb-1">{it.category_name}</div>
                  <h3 className="font-display font-bold text-lg tracking-tight leading-tight group-hover:text-blue-600 transition-colors line-clamp-1">{it.name}</h3>
                  <div className="flex items-center gap-2 mt-2">
                    <StarRating value={it.avg_rating} size={13} />
                    <span className="text-sm font-semibold">{it.avg_rating.toFixed(1)}</span>
                    <span className="text-xs text-zinc-500 font-mono">· {it.review_count} reviews</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Latest reviews */}
      <section className="border-b border-zinc-200">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-20">
          <div className="text-xs font-bold uppercase tracking-[0.3em] text-zinc-500 mb-3 flex items-center gap-2">
            <Quote size={12} /> 04 — Fresh from the community
          </div>
          <h2 className="font-display font-black text-3xl sm:text-4xl lg:text-5xl tracking-tighter mb-10">
            Latest reviews
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-0 border-l border-t border-zinc-200" data-testid="latest-reviews">
            {latestReviews.map((r, i) => (
              <Link to={`/item/${r.item_slug}`} key={r.id} className="border-r border-b border-zinc-200 -ml-px -mt-px p-7 bg-white hover:bg-zinc-50 transition fade-up" style={{ animationDelay: `${i * 60}ms` }}>
                <div className="flex items-center justify-between mb-4">
                  <StarRating value={r.rating} size={14} />
                  <span className="text-xs text-zinc-400 font-mono">{formatDate(r.created_at)}</span>
                </div>
                <h3 className="font-display font-bold text-xl tracking-tight leading-tight mb-2">{r.title}</h3>
                <p className="text-sm text-zinc-600 leading-relaxed line-clamp-3 mb-5">{r.body}</p>
                <div className="flex items-center justify-between border-t border-zinc-100 pt-4">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-7 w-7 rounded-none"><AvatarImage src={r.user_avatar} /><AvatarFallback className="rounded-none bg-zinc-900 text-white text-[10px]">{r.user_name?.[0]}</AvatarFallback></Avatar>
                    <span className="text-xs text-zinc-500">{r.user_name} · <span className="text-zinc-900 font-semibold">{r.item_name}</span></span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-zinc-900 text-white">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-20 grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-7">
            <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-400 mb-4 flex items-center gap-2">
              <Sparkles size={12} /> Join the platform
            </div>
            <h2 className="font-display font-black text-4xl sm:text-5xl lg:text-6xl tracking-tighter leading-none mb-6">
              Have an opinion?<br />Make it count.
            </h2>
            <p className="text-lg text-zinc-300 max-w-xl leading-relaxed mb-8">
              Rateverse is free forever for reviewers. Join the platform and help build the most honest review database online.
            </p>
            <div className="flex gap-4 flex-wrap">
              <Button onClick={() => navigate("/register")} className="rounded-none bg-blue-600 hover:bg-blue-500 text-white font-semibold px-8 py-6 text-sm uppercase tracking-[0.15em]" data-testid="cta-register">
                Create free account
              </Button>
              <Button onClick={() => navigate("/search")} variant="outline" className="rounded-none border-zinc-600 bg-transparent text-white hover:bg-white hover:text-zinc-900 font-semibold px-8 py-6 text-sm uppercase tracking-[0.15em]" data-testid="cta-explore">
                Explore listings
              </Button>
            </div>
          </div>
          <div className="lg:col-span-5 grid grid-cols-2 gap-6 content-center">
            <div className="border-l-2 border-blue-500 pl-4">
              <div className="font-display font-black text-4xl tracking-tighter">1–5★</div>
              <div className="text-xs font-mono uppercase tracking-[0.2em] text-zinc-400 mt-1">Honest scoring</div>
            </div>
            <div className="border-l-2 border-blue-500 pl-4">
              <div className="font-display font-black text-4xl tracking-tighter">AI</div>
              <div className="text-xs font-mono uppercase tracking-[0.2em] text-zinc-400 mt-1">Auto-summaries</div>
            </div>
            <div className="border-l-2 border-blue-500 pl-4">
              <div className="font-display font-black text-4xl tracking-tighter">Pros / Cons</div>
              <div className="text-xs font-mono uppercase tracking-[0.2em] text-zinc-400 mt-1">Structured</div>
            </div>
            <div className="border-l-2 border-blue-500 pl-4">
              <div className="font-display font-black text-4xl tracking-tighter">Free</div>
              <div className="text-xs font-mono uppercase tracking-[0.2em] text-zinc-400 mt-1">Forever</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
