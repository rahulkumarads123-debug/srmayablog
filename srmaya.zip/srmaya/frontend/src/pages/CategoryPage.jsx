import { useEffect, useState, useMemo } from "react";
import { useParams, Link } from "react-router-dom";
import api from "@/lib/api";
import ItemCard from "@/components/ItemCard";
import StarRating from "@/components/StarRating";
import { Button } from "@/components/ui/button";
import * as Icons from "lucide-react";
import { Play, Film, Calendar, Clock } from "lucide-react";

const ENTERTAINMENT_SUBCATS = ["Movie", "Web Series", "TV Show", "Documentary", "Podcast", "Game"];

function pickYear(item) {
  const d = item?.metadata?.release_date;
  if (!d) return null;
  const y = String(d).slice(0, 4);
  return /^\d{4}$/.test(y) ? y : null;
}

export default function CategoryPage() {
  const { slug } = useParams();
  const [category, setCategory] = useState(null);
  const [items, setItems] = useState([]);
  const [sort, setSort] = useState("rating");
  const [loading, setLoading] = useState(true);

  // Entertainment-specific filters
  const [subcat, setSubcat] = useState("all");
  const [genre, setGenre] = useState("all");
  const [language, setLanguage] = useState("all");
  const [year, setYear] = useState("all");

  const isEntertainment = slug === "entertainment";

  useEffect(() => {
    setLoading(true);
    setSubcat("all"); setGenre("all"); setLanguage("all"); setYear("all");
    Promise.all([
      api.get(`/categories/${slug}`),
      api.get(`/items?category=${slug}&sort=${sort}&limit=200`),
    ])
      .then(([c, i]) => {
        setCategory(c.data);
        setItems(i.data.items);
      })
      .catch(() => setCategory(null))
      .finally(() => setLoading(false));
  }, [slug, sort]);

  // Derive entertainment filter option lists
  const genres = useMemo(() => {
    const s = new Set();
    items.forEach((it) => it.metadata?.genre && s.add(it.metadata.genre));
    return ["all", ...Array.from(s).sort()];
  }, [items]);

  const languages = useMemo(() => {
    const s = new Set();
    items.forEach((it) => it.metadata?.language && s.add(it.metadata.language));
    return ["all", ...Array.from(s).sort()];
  }, [items]);

  const years = useMemo(() => {
    const s = new Set();
    items.forEach((it) => { const y = pickYear(it); if (y) s.add(y); });
    return ["all", ...Array.from(s).sort().reverse()];
  }, [items]);

  // Apply entertainment filters
  const filtered = useMemo(() => {
    if (!isEntertainment) return items;
    return items.filter((it) => {
      if (subcat !== "all" && it.metadata?.subcategory !== subcat) return false;
      if (genre !== "all" && it.metadata?.genre !== genre) return false;
      if (language !== "all" && it.metadata?.language !== language) return false;
      if (year !== "all" && pickYear(it) !== year) return false;
      return true;
    });
  }, [items, isEntertainment, subcat, genre, language, year]);

  const featured = useMemo(() => {
    if (!isEntertainment) return null;
    return [...items].sort((a, b) => (b.avg_rating || 0) - (a.avg_rating || 0))[0] || null;
  }, [items, isEntertainment]);

  if (loading && !category) {
    return <div className="max-w-[1400px] mx-auto px-6 py-20 text-zinc-500 text-xs uppercase tracking-[0.3em]">Loading...</div>;
  }
  if (!category) {
    return (
      <div className="max-w-[1400px] mx-auto px-6 py-20">
        <h1 className="font-display font-black text-3xl mb-4">Category not found</h1>
        <Link to="/" className="text-blue-600 hover:underline">← Go home</Link>
      </div>
    );
  }

  const Icon = Icons[category.icon] || Icons.Layers;

  // ENTERTAINMENT — IMDb-style hub
  if (isEntertainment) {
    return (
      <div data-testid="category-page-entertainment">
        {/* Featured hero */}
        {featured && (
          <section className="bg-zinc-900 text-white relative overflow-hidden">
            <div className="absolute inset-0 opacity-30">
              {featured.image_url && (<img src={featured.image_url} alt="" className="w-full h-full object-cover" />)}
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-zinc-900/80 to-zinc-900/40" />
            </div>
            <div className="relative max-w-[1400px] mx-auto px-6 lg:px-10 py-16 lg:py-24 grid lg:grid-cols-12 gap-10 items-end">
              <div className="lg:col-span-8">
                <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-400 mb-4 flex items-center gap-2">
                  <Film size={12} /> Featured in Entertainment
                </div>
                <h1 className="font-display font-black text-5xl lg:text-7xl tracking-tighter leading-none mb-5">
                  {featured.name}
                  {pickYear(featured) && <span className="text-zinc-400 font-light"> ({pickYear(featured)})</span>}
                </h1>
                <div className="flex flex-wrap items-center gap-3 mb-5 text-sm text-zinc-300">
                  {featured.metadata?.genre && <span className="bg-white/10 px-2 py-1 text-[10px] font-bold uppercase tracking-[0.15em]">{featured.metadata.genre}</span>}
                  {featured.metadata?.duration && <span className="flex items-center gap-1"><Clock size={12} />{featured.metadata.duration}</span>}
                  {featured.metadata?.age_rating && <span className="border border-white/30 px-1.5 py-0.5 text-[10px] font-mono">{featured.metadata.age_rating}</span>}
                  <span className="flex items-center gap-1">
                    <StarRating value={featured.avg_rating} size={14} />
                    <span className="font-bold">{featured.avg_rating.toFixed(1)}</span>
                  </span>
                </div>
                <p className="text-zinc-300 leading-relaxed max-w-2xl mb-7 line-clamp-3">{featured.description}</p>
                <div className="flex gap-3">
                  <Link to={`/item/${featured.slug}`}>
                    <Button className="rounded-none bg-blue-600 hover:bg-blue-500 text-white font-semibold px-7 py-6 text-sm uppercase tracking-[0.15em]" data-testid="entertainment-hero-view-btn">
                      <Play size={14} className="mr-2 fill-white" /> View details
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="lg:col-span-4 hidden lg:block">
                <div className="border-2 border-white/20 p-1 bg-black/40">
                  <div className="aspect-[3/4] overflow-hidden">
                    {featured.image_url && (<img src={featured.image_url} alt={featured.name} className="w-full h-full object-cover" />)}
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* Filter chips */}
        <section className="border-b border-zinc-200 bg-white sticky top-16 z-20 backdrop-blur-xl bg-white/90">
          <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-4 flex flex-wrap items-center gap-3" data-testid="entertainment-filters">
            <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500 mr-2">Type</div>
            {[{ k: "all", label: "All" }, ...ENTERTAINMENT_SUBCATS.map((s) => ({ k: s, label: s }))].map((s) => (
              <button
                key={s.k}
                onClick={() => setSubcat(s.k)}
                className={`text-xs font-bold uppercase tracking-[0.15em] px-3 py-1.5 transition-colors ${subcat === s.k ? "bg-zinc-900 text-white" : "bg-zinc-100 hover:bg-zinc-200"}`}
                data-testid={`entertainment-filter-subcat-${s.k.toLowerCase().replace(/\s+/g, "-")}`}
              >
                {s.label}
              </button>
            ))}
            <div className="border-l border-zinc-200 h-6 mx-2 hidden lg:inline-block" />
            <select value={genre} onChange={(e) => setGenre(e.target.value)} className="bg-white border border-zinc-200 rounded-none px-3 py-1.5 text-xs uppercase tracking-[0.15em] font-bold focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" data-testid="entertainment-filter-genre">
              <option value="all">All genres</option>
              {genres.filter((g) => g !== "all").map((g) => <option key={g} value={g}>{g}</option>)}
            </select>
            <select value={language} onChange={(e) => setLanguage(e.target.value)} className="bg-white border border-zinc-200 rounded-none px-3 py-1.5 text-xs uppercase tracking-[0.15em] font-bold focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" data-testid="entertainment-filter-language">
              <option value="all">All languages</option>
              {languages.filter((l) => l !== "all").map((l) => <option key={l} value={l}>{l}</option>)}
            </select>
            <select value={year} onChange={(e) => setYear(e.target.value)} className="bg-white border border-zinc-200 rounded-none px-3 py-1.5 text-xs uppercase tracking-[0.15em] font-bold focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" data-testid="entertainment-filter-year">
              <option value="all">All years</option>
              {years.filter((y) => y !== "all").map((y) => <option key={y} value={y}>{y}</option>)}
            </select>
            <div className="ml-auto">
              <select value={sort} onChange={(e) => setSort(e.target.value)} className="bg-white border border-zinc-200 rounded-none px-3 py-1.5 text-xs uppercase tracking-[0.15em] font-bold focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" data-testid="entertainment-sort">
                <option value="rating">Top rated</option>
                <option value="trending">Trending</option>
                <option value="newest">Newest</option>
                <option value="reviews">Most reviewed</option>
              </select>
            </div>
          </div>
        </section>

        {/* Items grid */}
        <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-16">
          <div className="flex items-baseline justify-between mb-6">
            <h2 className="font-display font-black text-2xl tracking-tighter">
              {subcat === "all" ? "All entertainment" : `All ${subcat}s`}
            </h2>
            <span className="text-xs font-mono uppercase tracking-[0.2em] text-zinc-500">{filtered.length} title{filtered.length === 1 ? "" : "s"}</span>
          </div>
          {filtered.length === 0 ? (
            <div className="border border-dashed border-zinc-300 p-16 text-center">
              <p className="text-zinc-500 mb-3">Nothing matches those filters.</p>
              <button onClick={() => { setSubcat("all"); setGenre("all"); setLanguage("all"); setYear("all"); }} className="text-blue-600 hover:underline text-sm" data-testid="reset-filters-btn">Reset filters</button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-0 border-l border-t border-zinc-200" data-testid="entertainment-grid">
              {filtered.map((it, i) => (
                <div key={it.id} className="border-r border-b border-zinc-200 -ml-px -mt-px">
                  <ItemCard item={it} index={i} />
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    );
  }

  // DEFAULT (non-entertainment) layout
  return (
    <div data-testid={`category-page-${slug}`}>
      <section className="border-b border-zinc-200 bg-white">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-16 grid lg:grid-cols-12 gap-8 items-end">
          <div className="lg:col-span-8">
            <div className="text-xs font-bold uppercase tracking-[0.3em] text-zinc-500 mb-4 flex items-center gap-2">
              <Link to="/" className="hover:text-zinc-900">Home</Link>
              <span>/</span>
              <span>Category</span>
            </div>
            <div className="flex items-center gap-5 mb-6">
              <div className="w-16 h-16 grid place-items-center" style={{ backgroundColor: category.color, color: "#fff" }}>
                <Icon size={28} />
              </div>
              <div>
                <h1 className="font-display font-black text-5xl lg:text-6xl tracking-tighter leading-none">
                  {category.name}
                </h1>
                <div className="text-xs font-mono uppercase tracking-[0.2em] text-zinc-400 mt-2">
                  {category.item_count} listings
                </div>
              </div>
            </div>
            <p className="text-lg text-zinc-600 leading-relaxed max-w-2xl">{category.description}</p>
          </div>
          <div className="lg:col-span-4 flex lg:justify-end">
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value)}
              className="bg-white border border-zinc-200 rounded-none px-4 py-2.5 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
              data-testid="category-sort-select"
            >
              <option value="rating">Sort: Highest rated</option>
              <option value="trending">Sort: Trending</option>
              <option value="newest">Sort: Newest</option>
              <option value="reviews">Sort: Most reviewed</option>
            </select>
          </div>
        </div>
      </section>
      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-16">
        {items.length === 0 ? (
          <div className="border border-zinc-200 p-16 text-center">
            <p className="text-zinc-500">No items in this category yet.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-0 border-l border-t border-zinc-200" data-testid="category-items-grid">
            {items.map((it, i) => (
              <div key={it.id} className="border-r border-b border-zinc-200 -ml-px -mt-px">
                <ItemCard item={it} index={i} />
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
