import { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useAuth, formatApiError } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await login(email.trim(), password);
      toast.success("Welcome back.");
      navigate(location.state?.from || "/");
    } catch (e) {
      const msg = formatApiError(e.response?.data?.detail) || "Login failed";
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] grid lg:grid-cols-2" data-testid="login-page">
      <div className="hidden lg:block bg-zinc-900 text-white p-12 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, rgba(255,255,255,0.4) 1px, transparent 0)", backgroundSize: "24px 24px" }} />
        <div className="relative max-w-md">
          <div className="text-xs font-bold uppercase tracking-[0.3em] text-blue-400 mb-6">Welcome back</div>
          <h1 className="font-display font-black text-5xl tracking-tighter leading-none mb-6">
            Sign in to keep<br />the truth flowing.
          </h1>
          <p className="text-zinc-400 leading-relaxed">
            Pick up where you left off — your reviews, your saved items, your honest take on everything.
          </p>
        </div>
      </div>
      <div className="flex items-center justify-center p-6 lg:p-12">
        <form onSubmit={onSubmit} className="w-full max-w-md space-y-6" data-testid="login-form">
          <div>
            <div className="text-xs font-bold uppercase tracking-[0.3em] text-zinc-500 mb-3">Sign in</div>
            <h2 className="font-display font-black text-4xl tracking-tighter">Welcome back</h2>
          </div>
          {error && <div className="border border-red-200 bg-red-50 text-red-800 text-sm px-4 py-3" data-testid="login-error">{error}</div>}
          <div>
            <label className="text-sm font-semibold text-zinc-900 mb-1.5 block">Email</label>
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-3 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" data-testid="login-email-input" />
          </div>
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-sm font-semibold text-zinc-900">Password</label>
              <Link to="/forgot-password" className="text-xs text-blue-600 hover:underline font-semibold" data-testid="login-forgot-password">
                Forgot?
              </Link>
            </div>
            <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} className="w-full bg-zinc-50 border border-zinc-200 rounded-none px-3 py-3 text-sm focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none" data-testid="login-password-input" />
          </div>
          <Button type="submit" disabled={loading} className="rounded-none bg-blue-600 hover:bg-blue-700 text-white font-semibold w-full py-6 text-sm uppercase tracking-[0.15em]" data-testid="login-submit-btn">
            {loading ? "Signing in..." : "Sign in"}
          </Button>
          <p className="text-sm text-zinc-500 text-center">
            Don't have an account?{" "}
            <Link to="/register" className="text-blue-600 hover:underline font-semibold" data-testid="login-go-register">Create one</Link>
          </p>
          <p className="text-xs text-zinc-400 text-center font-mono uppercase tracking-[0.15em] border-t border-zinc-200 pt-6">
            Demo member: ava.matthews@demo.com / Demo@12345
          </p>
        </form>
      </div>
    </div>
  );
}
