import "@/App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { Toaster } from "sonner";

import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProtectedRoute from "@/components/ProtectedRoute";
import VerificationBanner from "@/components/VerificationBanner";

import Home from "@/pages/Home";
import CategoryPage from "@/pages/CategoryPage";
import SearchPage from "@/pages/SearchPage";
import ItemDetail from "@/pages/ItemDetail";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import Profile from "@/pages/Profile";
import AdminDashboard from "@/pages/AdminDashboard";
import Top10 from "@/pages/Top10";
import SubmitPost from "@/pages/SubmitPost";
import Groups from "@/pages/Groups";
import GroupDetail from "@/pages/GroupDetail";
import CreateGroup from "@/pages/CreateGroup";
import Blog from "@/pages/Blog";
import BlogPost from "@/pages/BlogPost";
import BlogEditor from "@/pages/BlogEditor";
import Feed from "@/pages/Feed";
import UserProfile from "@/pages/UserProfile";
import VerifyEmail from "@/pages/VerifyEmail";
import ForgotPassword from "@/pages/ForgotPassword";
import ResetPassword from "@/pages/ResetPassword";
import NotificationsPage from "@/pages/Notifications";
import CastProfile from "@/pages/CastProfile";

function Layout({ children }) {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <VerificationBanner />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <div className="App">
      <AuthProvider>
        <BrowserRouter>
          <Toaster position="top-right" toastOptions={{ unstyled: false, classNames: { toast: "rounded-none border border-zinc-900" } }} />
          <Routes>
            <Route path="/" element={<Layout><Home /></Layout>} />
            <Route path="/category/:slug" element={<Layout><CategoryPage /></Layout>} />
            <Route path="/item/:slug" element={<Layout><ItemDetail /></Layout>} />
            <Route path="/search" element={<Layout><SearchPage /></Layout>} />
            <Route path="/top10" element={<Layout><Top10 /></Layout>} />
            <Route path="/groups" element={<Layout><Groups /></Layout>} />
            <Route path="/groups/new" element={<ProtectedRoute><Layout><CreateGroup /></Layout></ProtectedRoute>} />
            <Route path="/groups/:slug" element={<Layout><GroupDetail /></Layout>} />
            <Route path="/blog" element={<Layout><Blog /></Layout>} />
            <Route path="/blog/new" element={<ProtectedRoute adminOnly><Layout><BlogEditor /></Layout></ProtectedRoute>} />
            <Route path="/blog/:slug/edit" element={<ProtectedRoute adminOnly><Layout><BlogEditor /></Layout></ProtectedRoute>} />
            <Route path="/blog/:slug" element={<Layout><BlogPost /></Layout>} />
            <Route path="/feed" element={<Layout><Feed /></Layout>} />
            <Route path="/u/:user_id" element={<Layout><UserProfile /></Layout>} />
            <Route path="/cast/:slug" element={<Layout><CastProfile /></Layout>} />
            <Route path="/login" element={<Layout><Login /></Layout>} />
            <Route path="/register" element={<Layout><Register /></Layout>} />
            <Route path="/verify-email" element={<Layout><VerifyEmail /></Layout>} />
            <Route path="/forgot-password" element={<Layout><ForgotPassword /></Layout>} />
            <Route path="/reset-password" element={<Layout><ResetPassword /></Layout>} />
            <Route path="/notifications" element={<ProtectedRoute><Layout><NotificationsPage /></Layout></ProtectedRoute>} />
            <Route
              path="/profile"
              element={
                <ProtectedRoute>
                  <Layout><Profile /></Layout>
                </ProtectedRoute>
              }
            />
            <Route
              path="/submit-post"
              element={
                <ProtectedRoute>
                  <Layout><SubmitPost /></Layout>
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin"
              element={
                <ProtectedRoute adminOnly>
                  <Layout><AdminDashboard /></Layout>
                </ProtectedRoute>
              }
            />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </div>
  );
}

export default App;
