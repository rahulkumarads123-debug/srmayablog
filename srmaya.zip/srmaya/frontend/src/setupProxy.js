const { createProxyMiddleware, fixRequestBody } = require("http-proxy-middleware");

module.exports = function setupProxy(app) {
  app.use(
    "/api",
    createProxyMiddleware({
      target: "http://127.0.0.1:8000",
      changeOrigin: true,
      onProxyReq: fixRequestBody,
    }),
  );
};