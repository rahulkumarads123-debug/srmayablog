#!/usr/bin/env bash
set -euo pipefail

python scripts/apply_dev_schema.py