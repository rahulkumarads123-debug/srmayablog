"""Apply the checked-in schema to Replit's development PostgreSQL database."""

import asyncio
import os
from pathlib import Path

import asyncpg


async def main():
    database_url = os.environ.get("DATABASE_URL")
    if not database_url:
        raise RuntimeError("DATABASE_URL is missing; Replit PostgreSQL must be enabled.")
    schema = Path("backend/schema.sql").read_text()
    connection = await asyncpg.connect(database_url)
    try:
        await connection.execute(schema)
    finally:
        await connection.close()


if __name__ == "__main__":
    asyncio.run(main())