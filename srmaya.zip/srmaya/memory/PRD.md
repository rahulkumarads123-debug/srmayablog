# Rateverse — Product Requirements

## Original Problem Statement
Modern, scalable multi-category rating & review platform inspired by Trustpilot + IMDb + Glassdoor. Users search, rate, and review movies, web series, companies, products, gadgets, restaurants, hotels, colleges, hospitals, apps, etc. Includes admin moderation and AI-powered review summaries.

## Architecture
- **Backend**: FastAPI + Motor (async MongoDB) at `/app/backend`
- **Frontend**: React 19 + Tailwind + shadcn/ui at `/app/frontend`
- **DB**: MongoDB (`test_database`) — collections: `users`, `items`, `categories`, `reviews`, `user_submissions`, `ai_summaries`, `password_reset_tokens`, `login_attempts`
- **Auth**: JWT in httpOnly cookies (samesite=none, secure) via PyJWT + bcrypt
- **AI**: Claude Sonnet 4.5 (`anthropic/claude-sonnet-4-5-20250929`) via `emergentintegrations` + Emergent LLM Key
- **Design**: Swiss & High-Contrast — Cabinet Grotesk display, Inter body, blue #0055FF accent on white, rounded-none, dotted background, fade-up animations.

## User Personas
1. **Reviewer** — registered user contributing reviews and (now) new listings.
2. **Visitor** — anonymous browser of items, ratings, AI summaries.
3. **Admin** — site moderator approving submissions, removing reported reviews, managing users.

## Core Requirements (static)
- Search across everything; filter by category; sort by rating/trending/newest/most-reviewed.
- 1–5 star ratings + breakdown chart + helpful votes + report abuse + verified badge.
- Reviews include text, pros[], cons[], helpful_count.
- Per-category metadata (movies = genre/cast/director, companies = ceo/work_culture/salary/growth/management, etc.).
- AI review summary (cached per `review_count`).
- Top 10 rankings overall and per category.
- Admin dashboard with stats, user/item/review management, submission moderation.
- Submit New Post: registered users propose listings → admin reviews (approve/reject/edit-then-approve/delete) → approved becomes public item.

## Implemented
### Phase 1 (Feb 28 2026) — Core MVP
- Auth (register/login/logout/me/refresh) with httpOnly cookies, brute-force-safe password hashing.
- 5 seeded categories + 22 seeded items + ~30 seeded reviews + 6 demo users + admin.
- Item routes (list/trending/top/featured/get/related/admin CRUD).
- Reviews (CRUD, helpful toggle with re-aggregation, report).
- Admin dashboard endpoints (stats, users, items, reviews, feature toggle).
- AI summary endpoint with caching.
- **Submit New Post feature**: captcha (math), rate-limit 5/hour, auto-slug, debounced uniqueness check, auto-saved draft, preview tab, dynamic fields per category, admin approve/reject/edit/delete.
- Pages: Home, Category, Item Detail, Search, Top10, Login, Register, Profile, AdminDashboard, SubmitPost.

### Phase 2 (Mar–Jun 2026) — Community Hub additions
- IMDb-style entertainment detail: hero with poster + video embed (YouTube/FB/X iframes), cast & crew repeater.
- Communities/Groups: list, detail, create — discussion + recommendation posts with comments.
- Editorial Blog (admin-authored): list, post, editor (`/blog`, `/blog/new`, `/blog/:slug`, `/blog/:slug/edit`).
- Social Feed (`/feed`): Latest / Trending / Following tabs, create post with image_url+link_url, likes, comments, saves, reposts.
- Follows: `/api/follows/{user_id}/toggle`, followers/following lists, follow button on public profile.
- Public user profile (`/u/:user_id`): bio + stats + reviews + feed posts.
- Header redesign (Jun 2026): Discover dropdown groups Movies/Companies/Products/Services/Digital/Top 10; primary links Feed/Community/Blog; sectioned mobile hamburger menu.
- Testing: 45/45 backend tests pass (28 regression + 17 new features), full frontend flow validation.

### Phase 3 (Jun 2026) — File & media storage
- **Emergent Object Storage** integration for image uploads (JPG/PNG/WEBP/GIF, ≤ 10 MB).
- New backend routes: `POST /api/uploads/image` (auth-gated multipart) and `GET /api/uploads/file/{path:path}` (public read proxy, cache-friendly).
- `X-Forwarded-Host` respected so returned URLs use the public preview host, not the internal cluster.
- New `PATCH /api/auth/me` so users can update avatar/name/bio.
- Reusable `<ImageUploader>` component with drag-and-drop + preview + optional URL paste fallback.
- Wired into: SubmitPost (featured image, logo, gallery, cast photos), BlogEditor (cover), CreateGroup (cover), Feed composer (post image), Profile (avatar hover-to-upload).
- Testing: 55/55 backend tests pass (45 regression + 10 new for uploads and PATCH /auth/me). All frontend surfaces verified.

## Backlog
### P1
- Email verification & forgot password UI (backend partially stubbed).
- Real-time notifications (likes, comments, follows, group invites).
- Google Maps + opening hours integration for business listings.
- File uploads via object storage for featured/gallery/logo (currently URL inputs).
- Google OAuth (Emergent-managed) login alongside JWT.
- Compare two items page (`/compare`).
- Sitemap + JSON-LD structured data (SEO).

### P2
- Real-time 1:1 and group messaging.
- Polls & Events inside Community Groups.
- User badges + review points / gamification.
- Sponsored listings / monetization UI.
- Sub-rating sliders during review submission for company items.

### P3
- AdSense + premium memberships + sponsored posts.
- Per-category leaderboards beyond Top 10.
- Multi-language support.
- ErrorBoundary at App level (suggested by test agent).

## Test Credentials
- Admin: `admin@rateverse.com` / `Admin@12345`
- Demo users (password `Demo@12345`): ava.matthews, noah.bennett, lara.kim, samir.adwani, emma.dubois, kenji.tanaka @ demo.com
